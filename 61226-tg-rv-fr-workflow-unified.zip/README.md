# Remarketing Airflow Automation (Unified)

Production Airflow + local-test project for the analyst-refreshed Remarketing/Repossessions XLSX workflow,
**plus** the France inventory reporting continuation that produces two additional output reports (R2/R3).

The automation treats the uploaded XLSX as the only business-data runtime input and never connects to external linked files itself.

## Repository structure

```text
remarketing_airflow_automation/
├── astro/
│   ├── config/
│   │   ├── workbook.yml
│   │   ├── report_template.xlsx
│   │   └── reference/
│   │       ├── chart_definitions.json
│   │       ├── pivot_definitions.json
│   │       └── report_layout.json
│   ├── dags/
│   │   ├── remarketing_file_watcher_dag.py      # daily watcher (original flow)
│   │   ├── remarketing_processing_dag.py        # trigger-only processing (original flow)
│   │   ├── fr_inventory_file_watcher.py         # daily 8h Paris watcher (France flow)
│   │   └── fr_inventory_monthly_processing.py   # trigger-only monthly processing (France flow)
│   ├── include/
│   │   └── remarketing/
│   │       ├── ...                             # original pipeline package
│   │       └── france/                         # France continuation subpackage
│   │           ├── config.py
│   │           ├── workbook.py
│   │           ├── calculs_remarketing.py       # report 1
│   │           ├── calculs_era.py               # report 2
│   │           ├── calculs_portefeuille.py      # report 3
│   │           ├── pipeline.py
│   │           ├── storage.py
│   │           └── notifications.py
│   ├── requirements.txt
│   ├── requirements-airflow.txt
│   └── Dockerfile
├── local/
│   ├── input/
│   ├── output/
│   └── run_local.py                             # unified runner (main + france stages)
├── local_test/                                  # France fixtures (input + output)
├── generer_donnees_test.py                      # generates synthetic France test data
├── tests/
├── .gitignore
└── README.md
```

## Quick start — run the whole project with one command

Python 3.11+:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r astro/requirements.txt
```

Then run everything (original stage + France stage) on one workbook:

```bash
python local/run_local.py --input <workbook.xlsx> --processing-date YYYY-MM-DD --stages all
```

Full France run with optional inputs:

```bash
python local/run_local.py \
  --input local_test/input/remarketing_2026-06.xlsx \
  --processing-date 2026-06-30 \
  --portefeuille local_test/input/portefeuille_2026-06.xlsx \
  --taux 1.08 \
  --stages all
```

Run only one stage:

```bash
python local/run_local.py --input <workbook.xlsx> --processing-date YYYY-MM-DD --stages main    # original flow only
python local/run_local.py --input <workbook.xlsx> --processing-date YYYY-MM-DD --stages france  # France reports only
```

All original CLI flags (`--input`, `--input-dir`, `--output-dir`, `--processing-date`, `--config`, `--full-fidelity`) behave exactly as before when `--stages main` is used. New flags: `--stages {main,france,all}` (default `all`), `--portefeuille PATH` (optional), `--taux FLOAT` (optional EUR→USD rate).

Note on `--stages all`: the main stage always runs strictly. The France stage runs strictly when requested explicitly (`--stages france`, non-zero exit on failure), but in `all` mode a workbook that is not a France workbook only produces a clear "France stage skipped" message instead of failing the whole run.

## Stages

### Stage `main` (original remarketing workflow)

`remarketing_file_watcher_dag` polls `gs://<input-bucket>/input/` every five minutes by default.

- 0 XLSX files: successful no-op.
- 1 XLSX file: trigger `remarketing_processing_dag` with bucket, object name, exact GCS generation, size, and detection timestamp.
- More than 1 XLSX file: fail because the approved business contract permits one logical client workbook per processing day.

The watcher never moves, deletes, downloads, or processes the workbook.

`remarketing_processing_dag` is trigger-only (`schedule=None`) and calls the shared pipeline.
Triggering it manually with no configuration is also supported: it then discovers the single
XLSX under `input/` in the configured input bucket exactly as the watcher would. The pipeline:

1. downloads the exact observed GCS generation from the input bucket;
2. computes SHA-256;
3. checks prior SUCCESS manifests for duplicate bytes in the output bucket;
4. rejects a different input after a same-day SUCCESS;
5. generation-safely archives the input into the dated run folder in the input bucket;
6. validates and processes the analyst workbook;
7. generates the analyst-equivalent report;
8. generates reconciliation and requires zero unexplained mismatches;
9. uploads report and reconciliation to the output bucket;
10. writes `run_summary_YYYYMMDD.json` last as the authoritative SUCCESS marker.

#### GCS layout (main flow)

Input bucket:

```text
gs://<input-bucket>/
├── input/
│   └── <client-file>.xlsx
└── output/
    └── <processing-date>/
        └── input/
            └── <client-file>.xlsx
```

Output bucket:

```text
gs://<output-bucket>/
└── output/
    └── <processing-date>/
        └── output/
            ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
            ├── reconciliation.xlsx
            └── run_summary_YYYYMMDD.json
```

Canonical dated paths are `output/<processing-date>/input/` and `output/<processing-date>/output/`.

### Stage `france` (France inventory reports — continuation: 2 additional output reports)

The France stage runs `remarketing.france.pipeline` on the **same staged input workbook** and produces the reports that were developed as a separate follow-on project. It generates three report families:

- **R1 — Remarketing** (`R1 Canaux`, `R1 Mouvements`, `R1 Ageing`, `R1 KPIs`): sales by channel, inventory movements with a self-checking control column, ageing in 8 buckets, KPIs. All sheets, columns and values stay in French — nothing is translated.
- **R2 — ERA** (`R2 ERA INPUT (EUR)`): the Ford TCM ERA model-line × 16-metrics table. With `--taux` (EUR→USD) an additional `R2 ERA OUTPUT (USD)` sheet is produced.
- **R3 — Portefeuille** (`R3 Comptes a echeance`): accounts expiring per model; also feeds the "Accounts Expiring" column of R2. Without a portefeuille file, R2 falls back to the DateMaturite (Remarketing) approximation and this is flagged in the `Resume` sheet.

The stage also writes `Exceptions` (data-quality rows) and a `Resume` summary sheet.

Locally the stage prints every table to the console. When the processing month is `2026-06` it additionally prints the line-by-line validation against the June 2026 reference report (`P.valider(tables)`). Output files:

```text
local/output/
├── resultats_france_YYYY-MM.xlsx   # one tab per table (R1/R2/R3 prefixes)
└── exceptions.csv                  # data-quality exceptions (; separated)
```

In Airflow, the France flow is its own two-DAG family (monthly, Paris time):

- `fr_inventory_file_watcher` (daily `0 8 * * *` Europe/Paris): if `_processed/<month>.done` exists it skips in ~1 s ("sleeps" the rest of the month); otherwise a `GCSObjectExistenceSensor` (reschedule, 15-min pokes, give up after 6 h as skip) waits for `remarketing_YYYY-MM.xlsx` for the *previous* month, then `TriggerDagRun`s the processing DAG with `{"gcs_path", "month"}`.
- `fr_inventory_monthly_processing` (trigger-only): extract (move input to output bucket with verified copy+delete) → validate → calculate (report + `exceptions.csv`, June-2026 validation logged) → output_reports (`latest/` copy + `_processed/<month>.done` marker) → notify (SMTP e-mail, subject `France Remarketing workbook reconciliation <month> - SUCCESS|FAILED`).

Expected files in the France input bucket (manual uploads):

| File | Required | Used for |
|------|----------|----------|
| `remarketing_YYYY-MM.xlsx` | yes | reports 1 and 2 (Remarketing, Repossession, FSA-UPDATE*, colour-code sheets) |
| `portefeuille_YYYY-MM.xlsx` | no | report 3 + ERA "Accounts Expiring" column |
| `taux_YYYY-MM.xlsx` | no | cell A1 = EUR→USD rate; produces the ERA USD output sheet |

Both DAG families share one `remarketing` package (`astro/include/remarketing/`, with France under `astro/include/remarketing/france/`).

#### Business rules confirmed (Soraya, 15/09)

Restituable ≠ NON · Dealer/SICA = Franchised Dealers · VP Auto/BCA/Autorola/Concilian = Physical Auctions ·
empty Vendeur = unsold · Performance = average of Valeur revente TTC ÷ Cote ARGUS prof ·
2% Return Fees = 2 % × VFMG · Excess Km = Kilométrage − COUVERT × quotos ·
Perte/Profit Remarketing = 2% fees + Montant à facturer · Perte/Profit Repossession = Balance US − Valeur revente ·
Ageing = cut-off date − Date de retour, 8 buckets, "statut L" read from the row colour.

## Airflow configuration

Bucket configuration is hardcoded in `astro/include/remarketing/config.py`:

```text
DEFAULT_GCS_INPUT_BUCKET=<input bucket>
DEFAULT_GCS_OUTPUT_BUCKET=<output bucket>
```

The France subpackage has its own settings in `astro/include/remarketing/france/config.py` (`BUCKET_INPUT`, `BUCKET_OUTPUT`, `MODELE_FICHIER_*`, e-mail addresses). `FR_INVENTORY_ENV=dev|prod` selects the environment; if unset it is inferred from the Airflow URL (`astrodev` → dev).

The workload should authenticate to GCS with Application Default Credentials / Workload Identity. Do not package service-account key files.

Airflow core is expected to be provided by the managed Airflow runtime. Additional provider dependencies are declared in `astro/requirements-airflow.txt`. Expected connections: `google_cloud_default`, `smtp_default`.

Deploy/sync at minimum:

- `astro/dags/`
- `astro/include/`
- `astro/config/`
- `astro/requirements.txt`
- `astro/requirements-airflow.txt`
- `astro/Dockerfile`

## Local testing (original flags still valid)

Place one refreshed client XLSX in:

```text
local/input/
```

Run:

```bash
python local/run_local.py
```

For a deterministic test date:

```bash
python local/run_local.py --processing-date 2026-09-17
```

Or process an explicit XLSX without deleting the original source file:

```bash
python local/run_local.py --input /path/to/client.xlsx --processing-date 2026-09-17
```

Local output mirrors production paths under:

```text
local/output/<processing-date>/
├── input/
│   └── <client-file>.xlsx
└── output/
    ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
    ├── reconciliation.xlsx
    └── run_summary_YYYYMMDD.json
```

`local/run_local.py` imports the same `remarketing` package from `astro/include/remarketing/` and does not import Airflow.

### Local testing (France)

Synthetic fixtures ship in `local_test/input/`; `generer_donnees_test.py` regenerates them:

```bash
python generer_donnees_test.py          # optional: regenerate local_test/input fixtures
python local/run_local.py \
  --input local_test/input/remarketing_2026-06.xlsx \
  --processing-date 2026-06-30 \
  --portefeuille local_test/input/portefeuille_2026-06.xlsx \
  --taux 1.08 \
  --stages france
```

## Tests

```bash
pip install -r astro/requirements.txt pytest
python -m pytest tests/ -q
```

This runs the full original suite plus `tests/test_france_pipeline.py` (France smoke tests on synthetic data, no Airflow required).

## Idempotency and reconciliation

Duplicate prevention is content-based. SHA-256 from exact workbook bytes is compared to prior successful manifests, so renaming the same file does not cause a second run.

A different workbook cannot overwrite an already successful processing date. A failed run has no SUCCESS manifest, so a corrected re-upload remains retryable.

## Exact Excel visual fidelity (main flow)

The client-facing workbook exposes exactly six visible analyst-facing sheets:

- `Pivot Pierre`
- `Feuil2`
- `Pivot Soraya`
- `VENTES`
- `Feuil3`
- `KPIs`

`Remarketing` is veryHidden in the final workbook so retained native pivot tables and KPI formulas continue to reference their original source sheet.

The final workbook is built from the uploaded XLSX OOXML package. Native worksheet XML, styles, color definitions, theme data, pivot tables, pivot caches, charts, drawings, anchors, conditional formatting, dimensions, merged ranges, filters, and print/page settings are reused from the analyst workbook rather than recreated from a Python style palette.

`openpyxl` is not used to serialize the final client workbook. It remains in the project for independent calculated workbook generation and reconciliation audit.

Publication requires two independent gates: business reconciliation and visual fidelity must both PASS. The SUCCESS manifest is written only after both gates pass.

The workbook is a snapshot supplied after the analyst has refreshed upstream data. External links are never refreshed or dereferenced by Airflow, local testing, or the shared Python pipeline.
