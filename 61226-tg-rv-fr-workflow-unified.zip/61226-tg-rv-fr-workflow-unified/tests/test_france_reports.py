"""Tests for the France ERA/Portefeuille report stage (2-DAG design)."""
from __future__ import annotations

import dataclasses
import importlib.util
import sys
from datetime import date
from pathlib import Path

import pytest
from openpyxl import Workbook, load_workbook

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from remarketing.config import load_config  # noqa: E402
from remarketing.france_reports import (  # noqa: E402
    FranceReportsResult,
    generate_france_reports,
    has_france_sheets,
)
from remarketing.pipeline import _run_france_stage  # noqa: E402


@pytest.fixture(scope="module")
def france_workbooks(tmp_path_factory):
    """Build the synthetic June-2026 fixtures with the repo generator."""
    try:
        import generer_donnees_test as generator

        target = tmp_path_factory.mktemp("france")
        remarketing = target / "remarketing_2026-06.xlsx"
        portefeuille = target / "portefeuille_2026-06.xlsx"
        generator.generer(str(remarketing))
        generator.generer_portefeuille(str(portefeuille))
        return remarketing, portefeuille
    except Exception as exc:
        raise RuntimeError(f"Unable to build France fixtures: {exc}") from exc


def _blank_workbook(path: Path, sheets: list[str]) -> Path:
    try:
        workbook = Workbook()
        workbook.active.title = sheets[0]
        for name in sheets[1:]:
            workbook.create_sheet(name)
        workbook.save(path)
        workbook.close()
        return path
    except Exception as exc:
        raise RuntimeError(f"Unable to write synthetic workbook: {exc}") from exc


def test_has_france_sheets_detects_french_workbook(tmp_path):
    try:
        path = _blank_workbook(tmp_path / "fr.xlsx", ["Remarketing", "Repossession"])
        assert has_france_sheets(path) is True
    except Exception:
        raise


def test_has_france_sheets_rejects_other_workbooks(tmp_path):
    try:
        assert has_france_sheets(_blank_workbook(tmp_path / "a.xlsx", ["Data"])) is False
        assert (
            has_france_sheets(_blank_workbook(tmp_path / "b.xlsx", ["Remarketing"]))
            is False
        )
        assert has_france_sheets(tmp_path / "missing.xlsx") is False
    except Exception:
        raise


def test_generate_france_reports_writes_two_workbooks(france_workbooks, tmp_path):
    try:
        remarketing, portefeuille = france_workbooks
        result = generate_france_reports(
            input_path=remarketing,
            output_dir=tmp_path,
            processing_date=date(2026, 6, 30),
            portefeuille_path=portefeuille,
            taux=1.08,
        )
        assert isinstance(result, FranceReportsResult)
        assert result.skipped is False
        assert result.era_path is not None and result.era_path.exists()
        assert result.portefeuille_path is not None and result.portefeuille_path.exists()
        assert result.era_path.name == "france_era_2026-06.xlsx"
        assert result.portefeuille_path.name == "france_portefeuille_2026-06.xlsx"

        era_names = load_workbook(result.era_path, read_only=True).sheetnames
        assert any(name.startswith("R2") for name in era_names), era_names
        assert not any(name.startswith("R3") for name in era_names), era_names
        assert not any(name.startswith("R1") for name in era_names), era_names

        pf_names = load_workbook(result.portefeuille_path, read_only=True).sheetnames
        assert any(name.startswith("R3") for name in pf_names), pf_names
        assert not any(name.startswith("R2") for name in pf_names), pf_names
    except Exception:
        raise


def test_france_stage_skips_gracefully_without_french_sheets(tmp_path):
    try:
        config = load_config()
        assert config.france_reports_enabled is True
        plain = _blank_workbook(tmp_path / "plain.xlsx", ["Pivot Pierre"])
        result = _run_france_stage(
            config=config,
            input_path=plain,
            workspace=tmp_path / "out",
            processing_date=date(2026, 6, 30),
        )
        assert result.skipped is True
        assert result.era_path is None
        assert result.portefeuille_path is None
    except Exception:
        raise


def test_france_stage_skips_when_disabled(tmp_path, france_workbooks):
    try:
        remarketing, _ = france_workbooks
        config = dataclasses.replace(load_config(), france_reports_enabled=False)
        result = _run_france_stage(
            config=config,
            input_path=remarketing,
            workspace=tmp_path / "out",
            processing_date=date(2026, 6, 30),
        )
        assert result.skipped is True
    except Exception:
        raise


def test_dags_directory_contains_exactly_two_dags():
    try:
        names = sorted(path.name for path in (ROOT / "astro" / "dags").glob("*.py"))
        assert names == [
            "remarketing_file_watcher_dag.py",
            "remarketing_processing_dag.py",
        ]
    except Exception:
        raise


def test_processing_dag_imports_without_airflow_and_threads_conf():
    try:
        path = ROOT / "astro" / "dags" / "remarketing_processing_dag.py"
        spec = importlib.util.spec_from_file_location(
            "remarketing_processing_dag_probe", path
        )
        assert spec is not None and spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        assert module.dag is None  # Airflow is not installed here
        request = module.resolve_processing_request(
            {
                "bucket_name": "input-bucket",
                "object_name": "input/workbook.xlsx",
                "generation": 123,
                "size": 456,
                "detection_timestamp": "2026-09-21T10:00:00+00:00",
                "portefeuille_object": "input/portefeuille_2026-06.xlsx",
                "portefeuille_generation": 789,
                "taux_eur_usd": "1.08",
            }
        )
        assert request["portefeuille_object"] == "input/portefeuille_2026-06.xlsx"
        assert request["portefeuille_generation"] == 789
        assert request["taux_eur_usd"] == 1.08
        minimal = module.resolve_processing_request(
            {
                "bucket_name": "input-bucket",
                "object_name": "input/workbook.xlsx",
                "generation": 123,
                "detection_timestamp": "2026-09-21T10:00:00+00:00",
            }
        )
        assert minimal["taux_eur_usd"] is None
        assert "portefeuille_object" not in minimal
    except Exception:
        raise
