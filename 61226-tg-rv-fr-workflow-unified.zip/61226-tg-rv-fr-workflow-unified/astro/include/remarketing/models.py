"""Typed domain models shared by Airflow and local execution."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from datetime import date, datetime
from enum import StrEnum
from pathlib import Path
import re
from typing import TypeAlias

from .errors import ManifestError, ProcessingError


@dataclass(frozen=True, slots=True)
class ExcelError:
    """Cached Excel error value preserved from the source workbook."""

    code: str


CellScalar: TypeAlias = str | int | float | bool | date | datetime | None
CellValue: TypeAlias = CellScalar | ExcelError


@dataclass(slots=True)
class Dataset:
    """Normalized tabular dataset used by the calculation engine."""

    headers: tuple[str, ...]
    original_headers: dict[str, str]
    rows: list[dict[str, CellValue]]


@dataclass(slots=True)
class ReportBlock:
    """Rendered report block metadata retained for compatibility tests."""

    block_id: str
    sheet: str
    start_cell: str
    rows: list[list[CellValue]]
    number_formats: list[list[str | None]] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class RunConfig:
    """Compatibility configuration for direct report generation tests."""

    input_path: Path
    output_dir: Path
    as_of_date: date | None
    use_system_date: bool
    full_fidelity: bool

    @classmethod
    def from_values(
        cls,
        *,
        input_path: Path | str,
        output_dir: Path | str,
        as_of_date: date | None,
        use_system_date: bool,
        full_fidelity: bool,
    ) -> "RunConfig":
        """Build a validated compatibility run configuration."""
        try:
            if as_of_date is not None and use_system_date:
                raise ValueError("--as-of-date and --use-system-date are mutually exclusive")
            return cls(
                Path(input_path),
                Path(output_dir),
                as_of_date,
                use_system_date,
                full_fidelity,
            )
        except Exception:
            raise


@dataclass(slots=True)
class RunResult:
    """Compatibility result returned by direct generation helpers."""

    report_path: Path
    reconciliation_path: Path | None
    summary_path: Path
    warnings: list[str]


class RunStatus(StrEnum):
    """Supported end-to-end processing outcomes."""

    SUCCESS = "SUCCESS"
    DUPLICATE_SKIPPED = "DUPLICATE_SKIPPED"
    NO_INPUT = "NO_INPUT"


@dataclass(frozen=True, slots=True)
class GCSObjectIdentity:
    """Stable identity of one exact GCS object generation."""

    bucket_name: str
    object_name: str
    generation: int
    size: int = 0


@dataclass(frozen=True, slots=True)
class ProcessingPaths:
    """Canonical dated GCS/local paths for one processing day."""

    archived_input: str
    report: str
    reconciliation: str
    manifest: str
    france_era_report: str = ""
    france_portefeuille_report: str = ""

    @classmethod
    def for_run(
        cls,
        *,
        output_prefix: str,
        processing_date: date,
        source_filename: str,
    ) -> "ProcessingPaths":
        """Build the approved dated input/output path contract."""
        try:
            if not re.fullmatch(r"[\w .()-]+\.xlsx", source_filename, re.IGNORECASE):
                raise ProcessingError("Source filename must be a plain XLSX filename")
            day = processing_date.isoformat()
            compact = processing_date.strftime("%Y%m%d")
            month = processing_date.strftime("%Y-%m")
            prefix = output_prefix.strip("/")
            base = f"{prefix}/" if prefix else ""
            return cls(
                archived_input=f"{base}{day}/input/{source_filename}",
                report=(
                    f"{base}{day}/output/"
                    f"REMARKETING_REPOSSESSION_REPORT_{compact}.xlsx"
                ),
                reconciliation=f"{base}{day}/output/reconciliation.xlsx",
                manifest=f"{base}{day}/output/run_summary_{compact}.json",
                france_era_report=f"{base}{day}/output/france_era_{month}.xlsx",
                france_portefeuille_report=(
                    f"{base}{day}/output/france_portefeuille_{month}.xlsx"
                ),
            )
        except Exception as exc:
            raise ProcessingError("Unable to build processing paths") from exc


@dataclass(frozen=True, slots=True)
class ReconciliationSummary:
    """Small reconciliation summary safe for pipeline metadata."""

    mismatch_count: int
    unexplained_mismatch_count: int
    output_path: str | None = None


@dataclass(frozen=True, slots=True)
class ReportArtifact:
    """Generated report metadata returned by the report engine."""

    path: Path
    pivot_count: int
    chart_count: int
    warnings: tuple[str, ...] = ()
    report_as_of_date: str | None = None




@dataclass(frozen=True, slots=True)
class FidelityBuildResult:
    """Metadata returned after creating the final OOXML-preserved workbook."""

    path: Path
    retained_sheets: tuple[str, ...]
    removed_sheet_count: int


@dataclass(frozen=True, slots=True)
class VisualFidelityCheck:
    """One deterministic structural fidelity assertion."""

    name: str
    status: str
    detail: str


@dataclass(frozen=True, slots=True)
class VisualFidelityResult:
    """Aggregate structural fidelity verdict for the client workbook."""

    status: str
    checks: tuple[VisualFidelityCheck, ...]
    patched_cells: tuple[str, ...] = ()

    @property
    def is_pass(self) -> bool:
        """Return whether every required fidelity check passed."""
        try:
            return self.status == "PASS"
        except Exception:
            raise


@dataclass(frozen=True, slots=True)
class RunManifest:
    """Authoritative successful-run manifest stored in the dated output folder."""

    status: RunStatus
    processing_date: str
    source_file: str
    source_sha256: str
    archived_input: str
    report: str
    reconciliation: str
    unexplained_mismatch_count: int
    report_as_of_date: str = ""
    source_object: str = ""
    source_generation: int = 0
    pivots_generated: int = 0
    charts_generated: int = 0
    completed_at_utc: str = ""
    warnings: tuple[str, ...] = ()
    business_reconciliation: str = ""
    visual_fidelity: str = ""
    france_era_report: str = ""
    france_portefeuille_report: str = ""
    france_reports_skipped: bool = False

    @classmethod
    def from_json(cls, text: str) -> "RunManifest":
        """Parse and validate a stored run manifest."""
        try:
            payload = json.loads(text)
            payload["status"] = RunStatus(payload["status"])
            payload["warnings"] = tuple(payload.get("warnings", ()))
            if "unexplained_mismatch_count" not in payload:
                payload["unexplained_mismatch_count"] = int(
                    payload.get("mismatch_count", 0)
                )
            allowed = {item.name for item in fields(cls)}
            values = {key: value for key, value in payload.items() if key in allowed}
            return cls(**values)
        except Exception as exc:
            raise ManifestError("Invalid run manifest JSON") from exc

    def to_json(self) -> str:
        """Serialize the manifest as stable, human-readable JSON."""
        try:
            payload = asdict(self)
            payload["status"] = self.status.value
            payload["warnings"] = list(self.warnings)
            payload["mismatch_count"] = self.unexplained_mismatch_count
            return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        except Exception as exc:
            raise ManifestError("Unable to serialize run manifest") from exc

    @property
    def is_success(self) -> bool:
        """Return whether this manifest is the authoritative SUCCESS marker."""
        try:
            return self.status == RunStatus.SUCCESS
        except Exception:
            raise


@dataclass(frozen=True, slots=True)
class PipelineResult:
    """Small pipeline result suitable for Airflow XCom or local logging."""

    status: RunStatus
    processing_date: str
    source_file: str
    source_sha256: str
    archived_input: str | None = None
    report: str | None = None
    reconciliation: str | None = None
    manifest: str | None = None
    pivot_count: int = 0
    chart_count: int = 0
    mismatch_count: int = 0
    business_reconciliation: str = ""
    visual_fidelity: str = ""
    france_era_report: str | None = None
    france_portefeuille_report: str | None = None
    france_reports_skipped: bool = False

    def to_dict(self) -> dict[str, object]:
        """Convert the result into small JSON-compatible metadata."""
        try:
            payload = asdict(self)
            payload["status"] = self.status.value
            return payload
        except Exception as exc:
            raise ProcessingError("Unable to serialize pipeline result") from exc
