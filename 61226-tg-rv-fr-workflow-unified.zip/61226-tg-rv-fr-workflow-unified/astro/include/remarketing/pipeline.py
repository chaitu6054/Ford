"""Shared production/local orchestration for remarketing reporting."""
from __future__ import annotations

import json
import logging
from collections.abc import Iterable
from datetime import UTC, date, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

from .audit import build_success_manifest, sha256_file
from .calculate import build_pivot_results
from .config import AppConfig, load_config
from .errors import (
    AlreadyProcessedError,
    ProcessingError,
    ReconciliationError,
    RemarketingError,
    StorageError,
    VisualFidelityError,
)
from .france_reports import (
    FranceReportsResult,
    generate_france_reports,
    has_france_sheets,
    skipped_france_reports,
)
from .models import (
    GCSObjectIdentity,
    PipelineResult,
    ProcessingPaths,
    ReconciliationSummary,
    ReportArtifact,
    RunConfig,
    RunManifest,
    RunResult,
    RunStatus,
    VisualFidelityResult,
)
from .fidelity import build_fidelity_workbook
from .fidelity_validate import validate_visual_fidelity
from .notify import LoggingNotifier, Notifier
from .reconcile import append_visual_fidelity_sheet, reconcile_report
from .report import generate_report_artifact
from .storage import GCSObjectInfo, GCSStorage, LocalStorage
from .validate import validate_workbook_contract

LOGGER = logging.getLogger(__name__)


def _duplicate_manifest(manifests: Iterable[RunManifest], digest: str) -> RunManifest | None:
    try:
        for manifest in manifests:
            if manifest.is_success and manifest.source_sha256 == digest:
                return manifest
        return None
    except Exception as exc:
        raise ProcessingError("Unable to evaluate duplicate history") from exc


def _same_day_manifest(
    manifests: Iterable[RunManifest],
    processing_date: date,
) -> RunManifest | None:
    try:
        expected = processing_date.isoformat()
        for manifest in manifests:
            if manifest.is_success and manifest.processing_date == expected:
                return manifest
        return None
    except Exception as exc:
        raise ProcessingError("Unable to evaluate same-day history") from exc


def _notify_safe(notifier: Notifier, event: str, message: str, context: dict[str, object]) -> None:
    try:
        notifier.notify(event, message, context)
    except Exception:
        # Notification failures must never replace the primary processing result/error.
        return


def _execute_reporting(
    *,
    input_path: Path,
    workspace: Path,
    config: AppConfig,
    processing_date: date,
    explicit_as_of: date | None = None,
    use_system_date: bool = False,
) -> tuple[ReportArtifact, ReconciliationSummary, Path, VisualFidelityResult]:
    try:
        workspace.mkdir(parents=True, exist_ok=True)
        inspection = validate_workbook_contract(
            input_path,
            required_sheets=config.required_sheets,
            explicit_as_of=explicit_as_of,
            use_system_date=use_system_date,
        )
        with TemporaryDirectory(prefix="calculated-", dir=workspace) as calculated_temp:
            calculated_artifact = generate_report_artifact(
                input_path=input_path,
                output_dir=Path(calculated_temp),
                report_as_of_date=inspection.report_as_of_date,
                processing_date=processing_date,
                reference_dir=config.reference_dir,
                template_path=config.template_path,
                full_fidelity=False,
            )
            reconciliation_path = workspace / config.reconciliation_filename
            reconciliation = reconcile_report(
                analyst_workbook=input_path,
                generated_workbook=calculated_artifact.path,
                reconciliation_output=reconciliation_path,
                reference_dir=config.reference_dir,
            )
            if reconciliation.unexplained_mismatch_count != 0:
                raise ReconciliationError(
                    "Report reconciliation failed with "
                    f"{reconciliation.unexplained_mismatch_count} mismatches"
                )
            report_name = config.report_filename_pattern.format(
                date=processing_date.strftime("%Y%m%d")
            )
            final_path = workspace / report_name
            fidelity_build = build_fidelity_workbook(
                input_path,
                final_path,
                visible_sheets=config.report_sheets,
                technical_sheets=config.technical_sheets,
            )
            visual_result = validate_visual_fidelity(
                input_path,
                fidelity_build.path,
                visible_sheets=config.report_sheets,
                technical_sheets=config.technical_sheets,
            )
            append_visual_fidelity_sheet(
                reconciliation_path,
                visual_result,
                source_name=input_path.name,
                generated_name=fidelity_build.path.name,
            )
            if not visual_result.is_pass:
                failed = "; ".join(
                    f"{check.name}: {check.detail}"
                    for check in visual_result.checks
                    if check.status != "PASS"
                )
                raise VisualFidelityError(
                    f"Final workbook failed exact visual-fidelity validation [{failed}]"
                )
            final_artifact = ReportArtifact(
                path=fidelity_build.path,
                pivot_count=calculated_artifact.pivot_count,
                chart_count=calculated_artifact.chart_count,
                warnings=calculated_artifact.warnings,
                report_as_of_date=calculated_artifact.report_as_of_date,
            )
            return final_artifact, reconciliation, reconciliation_path, visual_result
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Shared reporting execution failed") from exc


def _run_france_stage(
    *,
    config: AppConfig,
    input_path: Path,
    workspace: Path,
    processing_date: date,
    portefeuille_path: Path | None = None,
    taux_eur_usd: float | None = None,
) -> FranceReportsResult:
    """Run the France ERA/Portefeuille stage after the main report succeeds.

    The stage is skipped (never raised) when disabled in configuration or when
    the workbook does not carry the French Remarketing/Repossession sheets, so
    synthetic or non-French workbooks keep flowing through the main pipeline.
    """
    try:
        if not config.france_reports_enabled:
            LOGGER.info("France report stage disabled by configuration; skipping.")
            return skipped_france_reports()
        if not has_france_sheets(input_path):
            LOGGER.warning(
                "France report stage skipped: workbook %s lacks the French "
                "Remarketing/Repossession sheets.",
                Path(input_path).name,
            )
            return skipped_france_reports()
        return generate_france_reports(
            input_path=Path(input_path),
            output_dir=Path(workspace),
            processing_date=processing_date,
            portefeuille_path=portefeuille_path,
            taux=taux_eur_usd,
        )
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("France report stage failed") from exc


def _delete_gcs_identity(storage: GCSStorage, source: GCSObjectIdentity) -> None:
    try:
        storage.delete_exact(GCSObjectInfo(source.object_name, source.generation, source.size))
    except Exception as exc:
        raise ProcessingError(f"Unable to delete input object {source.object_name}") from exc



def _destination_generation(storage: GCSStorage, object_name: str) -> int:
    try:
        existing = storage.exists(object_name)
        return 0 if existing is None else existing.generation
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError(f"Unable to inspect destination {object_name!r}") from exc

def process_gcs_object(
    *,
    config: AppConfig,
    source: GCSObjectIdentity,
    storage: GCSStorage | None = None,
    notifier: Notifier | None = None,
    processing_date: date | None = None,
    portefeuille_source: GCSObjectIdentity | None = None,
    taux_eur_usd: float | None = None,
) -> PipelineResult:
    """Process one exact GCS object generation through the production pipeline."""
    try:
        if not config.bucket_name:
            raise ProcessingError("GCS bucket is not configured")
        resolved_date = processing_date or datetime.now(UTC).date()
        input_client = storage or GCSStorage(config.bucket_name)
        output_bucket = config.output_bucket_name or config.bucket_name
        output_client = (
            input_client
            if output_bucket == input_client.bucket_name
            else GCSStorage(output_bucket)
        )
        sink = notifier or LoggingNotifier()
        source_file = Path(source.object_name).name
        paths = ProcessingPaths.for_run(
            output_prefix=config.output_prefix,
            processing_date=resolved_date,
            source_filename=source_file,
        )
        with TemporaryDirectory(prefix="remarketing-airflow-") as temp_dir:
            temp_root = Path(temp_dir)
            local_input = temp_root / source_file
            source_info = GCSObjectInfo(
                source.object_name,
                source.generation,
                source.size,
            )
            downloaded_from_source = True
            try:
                input_client.download_exact(source_info, local_input)
            except StorageError:
                current_source = input_client.exists(source.object_name)
                if (
                    current_source is not None
                    and current_source.generation == source.generation
                ):
                    raise
                archived_info = input_client.exists(paths.archived_input)
                if archived_info is None:
                    raise
                input_client.download_exact(archived_info, local_input)
                downloaded_from_source = False

            digest = sha256_file(local_input)
            manifests = output_client.list_success_manifests(config.output_prefix)
            duplicate = _duplicate_manifest(manifests, digest)
            if duplicate is not None:
                if downloaded_from_source:
                    _delete_gcs_identity(input_client, source)
                _notify_safe(
                    sink,
                    "DUPLICATE_SKIPPED",
                    "Exact workbook was already processed",
                    {"source": source.object_name, "sha256": digest},
                )
                return PipelineResult(
                    status=RunStatus.DUPLICATE_SKIPPED,
                    processing_date=resolved_date.isoformat(),
                    source_file=source_file,
                    source_sha256=digest,
                    manifest=duplicate.report,
                )
            same_day = _same_day_manifest(manifests, resolved_date)
            if same_day is not None:
                raise AlreadyProcessedError(
                    f"Processing date {resolved_date.isoformat()} already completed "
                    "with a different XLSX"
                )
            if downloaded_from_source:
                input_client.archive_exact(source, paths.archived_input)
            work_output = temp_root / "generated"
            artifact, reconciliation, reconciliation_path, visual_result = _execute_reporting(
                input_path=local_input,
                workspace=work_output,
                config=config,
                processing_date=resolved_date,
            )
            output_client.upload_file(
                artifact.path,
                paths.report,
                if_generation_match=_destination_generation(output_client, paths.report),
            )
            output_client.upload_file(
                reconciliation_path,
                paths.reconciliation,
                if_generation_match=_destination_generation(output_client, paths.reconciliation),
            )
            local_portefeuille: Path | None = None
            if portefeuille_source is not None:
                local_portefeuille = temp_root / Path(portefeuille_source.object_name).name
                input_client.download_exact(
                    GCSObjectInfo(
                        portefeuille_source.object_name,
                        portefeuille_source.generation,
                        portefeuille_source.size,
                    ),
                    local_portefeuille,
                )
            france_result = _run_france_stage(
                config=config,
                input_path=local_input,
                workspace=work_output,
                processing_date=resolved_date,
                portefeuille_path=local_portefeuille,
                taux_eur_usd=taux_eur_usd,
            )
            if france_result.era_path is not None:
                output_client.upload_file(
                    france_result.era_path,
                    paths.france_era_report,
                    if_generation_match=_destination_generation(
                        output_client, paths.france_era_report
                    ),
                )
            if france_result.portefeuille_path is not None:
                output_client.upload_file(
                    france_result.portefeuille_path,
                    paths.france_portefeuille_report,
                    if_generation_match=_destination_generation(
                        output_client, paths.france_portefeuille_report
                    ),
                )
            manifest = build_success_manifest(
                processing_date=resolved_date,
                source_file=source_file,
                source_sha256=digest,
                paths=paths,
                reconciliation=reconciliation,
                business_reconciliation="PASS",
                visual_fidelity=visual_result.status,
            )
            manifest = RunManifest(
                status=manifest.status,
                processing_date=manifest.processing_date,
                source_file=manifest.source_file,
                source_sha256=manifest.source_sha256,
                archived_input=manifest.archived_input,
                report=manifest.report,
                reconciliation=manifest.reconciliation,
                unexplained_mismatch_count=manifest.unexplained_mismatch_count,
                report_as_of_date=artifact.report_as_of_date or "",
                source_object=source.object_name,
                source_generation=source.generation,
                pivots_generated=artifact.pivot_count,
                charts_generated=artifact.chart_count,
                completed_at_utc=manifest.completed_at_utc,
                warnings=artifact.warnings,
                business_reconciliation="PASS",
                visual_fidelity=visual_result.status,
                france_era_report=(
                    paths.france_era_report if not france_result.skipped else ""
                ),
                france_portefeuille_report=(
                    paths.france_portefeuille_report if not france_result.skipped else ""
                ),
                france_reports_skipped=france_result.skipped,
            )
            # SUCCESS marker is deliberately the final publish action.
            output_client.upload_text(manifest.to_json(), paths.manifest, if_generation_match=0)
            _notify_safe(
                sink,
                "SUCCESS",
                "Remarketing workbook processed",
                {
                    "source": source.object_name,
                    "report": paths.report,
                    "france_era_report": paths.france_era_report,
                    "france_portefeuille_report": paths.france_portefeuille_report,
                    "france_reports_skipped": france_result.skipped,
                },
            )
            return PipelineResult(
                status=RunStatus.SUCCESS,
                processing_date=resolved_date.isoformat(),
                source_file=source_file,
                source_sha256=digest,
                archived_input=paths.archived_input,
                report=paths.report,
                reconciliation=paths.reconciliation,
                manifest=paths.manifest,
                pivot_count=artifact.pivot_count,
                chart_count=artifact.chart_count,
                mismatch_count=reconciliation.unexplained_mismatch_count,
                business_reconciliation="PASS",
                visual_fidelity=visual_result.status,
                france_era_report=(
                    paths.france_era_report if not france_result.skipped else None
                ),
                france_portefeuille_report=(
                    paths.france_portefeuille_report if not france_result.skipped else None
                ),
                france_reports_skipped=france_result.skipped,
            )
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError(f"Production processing failed for {source.object_name}") from exc


def process_local_file(
    *,
    config: AppConfig,
    input_path: Path,
    output_root: Path,
    processing_date: date | None = None,
    notifier: Notifier | None = None,
    portefeuille_path: Path | None = None,
    taux_eur_usd: float | None = None,
) -> PipelineResult:
    """Process one staged local workbook using production-equivalent semantics."""
    try:
        resolved_date = processing_date or datetime.now(UTC).date()
        sink = notifier or LoggingNotifier()
        source = Path(input_path).resolve(strict=True)
        if not source.is_file() or source.suffix.lower() != ".xlsx":
            raise ProcessingError("Local input must be an existing XLSX file")
        digest = sha256_file(source)
        storage = LocalStorage(input_dir=source.parent, output_root=Path(output_root))
        manifests = storage.list_success_manifests()
        duplicate = _duplicate_manifest(manifests, digest)
        if duplicate is not None:
            _notify_safe(
                sink,
                "DUPLICATE_SKIPPED",
                "Exact local workbook was already processed",
                {"source": source.name, "sha256": digest},
            )
            return PipelineResult(
                status=RunStatus.DUPLICATE_SKIPPED,
                processing_date=resolved_date.isoformat(),
                source_file=source.name,
                source_sha256=digest,
                manifest=duplicate.report,
            )
        if _same_day_manifest(manifests, resolved_date) is not None:
            raise AlreadyProcessedError(
                f"Processing date {resolved_date.isoformat()} already completed "
                "with a different XLSX"
            )
        paths = ProcessingPaths.for_run(
            output_prefix="",
            processing_date=resolved_date,
            source_filename=source.name,
        )
        archived = storage.archive_input(source, paths)
        with TemporaryDirectory(prefix="remarketing-local-") as temp_dir:
            artifact, reconciliation, reconciliation_path, visual_result = _execute_reporting(
                input_path=archived,
                workspace=Path(temp_dir),
                config=config,
                processing_date=resolved_date,
            )
            storage.publish_file(artifact.path, paths.report)
            storage.publish_file(reconciliation_path, paths.reconciliation)
            france_result = _run_france_stage(
                config=config,
                input_path=archived,
                workspace=Path(temp_dir),
                processing_date=resolved_date,
                portefeuille_path=portefeuille_path,
                taux_eur_usd=taux_eur_usd,
            )
            if france_result.era_path is not None:
                storage.publish_file(france_result.era_path, paths.france_era_report)
            if france_result.portefeuille_path is not None:
                storage.publish_file(
                    france_result.portefeuille_path, paths.france_portefeuille_report
                )
            manifest = build_success_manifest(
                processing_date=resolved_date,
                source_file=source.name,
                source_sha256=digest,
                paths=paths,
                reconciliation=reconciliation,
                business_reconciliation="PASS",
                visual_fidelity=visual_result.status,
            )
            manifest = RunManifest(
                status=manifest.status,
                processing_date=manifest.processing_date,
                source_file=manifest.source_file,
                source_sha256=manifest.source_sha256,
                archived_input=manifest.archived_input,
                report=manifest.report,
                reconciliation=manifest.reconciliation,
                unexplained_mismatch_count=manifest.unexplained_mismatch_count,
                report_as_of_date=artifact.report_as_of_date or "",
                pivots_generated=artifact.pivot_count,
                charts_generated=artifact.chart_count,
                completed_at_utc=manifest.completed_at_utc,
                warnings=artifact.warnings,
                business_reconciliation="PASS",
                visual_fidelity=visual_result.status,
                france_era_report=(
                    paths.france_era_report if not france_result.skipped else ""
                ),
                france_portefeuille_report=(
                    paths.france_portefeuille_report if not france_result.skipped else ""
                ),
                france_reports_skipped=france_result.skipped,
            )
            storage.publish_text(manifest.to_json(), paths.manifest)
        _notify_safe(
            sink,
            "SUCCESS",
            "Local remarketing workbook processed",
            {
                "source": source.name,
                "report": paths.report,
                "france_era_report": paths.france_era_report,
                "france_portefeuille_report": paths.france_portefeuille_report,
                "france_reports_skipped": france_result.skipped,
            },
        )
        return PipelineResult(
            status=RunStatus.SUCCESS,
            processing_date=resolved_date.isoformat(),
            source_file=source.name,
            source_sha256=digest,
            archived_input=paths.archived_input,
            report=paths.report,
            reconciliation=paths.reconciliation,
            manifest=paths.manifest,
            pivot_count=artifact.pivot_count,
            chart_count=artifact.chart_count,
            mismatch_count=reconciliation.unexplained_mismatch_count,
            business_reconciliation="PASS",
            visual_fidelity=visual_result.status,
            france_era_report=(
                paths.france_era_report if not france_result.skipped else None
            ),
            france_portefeuille_report=(
                paths.france_portefeuille_report if not france_result.skipped else None
            ),
            france_reports_skipped=france_result.skipped,
        )
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError(f"Local processing failed for {input_path}") from exc


def _write_compat_summary(
    *,
    output_dir: Path,
    report_date: date,
    input_path: Path,
    report_path: Path,
    reconciliation_path: Path | None,
    pivot_count: int,
    chart_count: int,
    warnings: list[str],
    mismatch_count: int | None = None,
    business_reconciliation: str = "",
    visual_fidelity: str = "",
) -> Path:
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        summary_path = output_dir / f"run_summary_{report_date:%Y%m%d}.json"
        payload = {
            "input": str(input_path),
            "report_as_of_date": report_date.isoformat(),
            "pivots_generated": pivot_count,
            "charts_generated": chart_count,
            "warnings": warnings,
            "output": str(report_path),
            "reconciliation": (
                None if reconciliation_path is None else str(reconciliation_path)
            ),
            "business_reconciliation": business_reconciliation,
            "visual_fidelity": visual_fidelity,
        }
        if mismatch_count is not None:
            payload["mismatch_count"] = mismatch_count
        summary_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return summary_path
    except Exception as exc:
        raise ProcessingError("Unable to write compatibility summary") from exc


def _run_compatibility(config: RunConfig) -> RunResult:
    try:
        app_config = load_config(overrides={"full_fidelity": config.full_fidelity})
        processing_date = config.as_of_date or datetime.now(UTC).date()
        artifact, reconciliation, reconciliation_path, visual_result = _execute_reporting(
            input_path=config.input_path,
            workspace=Path(config.output_dir),
            config=app_config,
            processing_date=processing_date,
            explicit_as_of=config.as_of_date,
            use_system_date=config.use_system_date,
        )
        report_date = (
            date.fromisoformat(artifact.report_as_of_date)
            if artifact.report_as_of_date
            else processing_date
        )
        summary = _write_compat_summary(
            output_dir=Path(config.output_dir),
            report_date=report_date,
            input_path=Path(config.input_path),
            report_path=artifact.path,
            reconciliation_path=reconciliation_path,
            pivot_count=artifact.pivot_count,
            chart_count=artifact.chart_count,
            warnings=list(artifact.warnings),
            mismatch_count=reconciliation.unexplained_mismatch_count,
            business_reconciliation="PASS",
            visual_fidelity=visual_result.status,
        )
        return RunResult(
            artifact.path,
            reconciliation_path,
            summary,
            list(artifact.warnings),
        )
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Compatibility reporting failed") from exc


def generate(config: RunConfig) -> RunResult:
    """Generate the exact-fidelity report using the shared compatibility workflow."""
    try:
        return _run_compatibility(config)
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Compatibility report generation failed") from exc


def validate(config: RunConfig) -> RunResult:
    """Generate and reconcile an exact-fidelity report using the shared workflow."""
    try:
        return _run_compatibility(config)
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Compatibility report validation failed") from exc


def generate_pivot_report(
    input_path: Path | str,
    template_path: Path | str,
    output_path: Path | str,
    *,
    sheets: set[str] | None = None,
) -> Path:
    """Generate selected pivot/report sheets for compatibility tests."""
    try:
        from .calculate import build_pivot_results, load_chart_definitions, load_pivot_definitions
        from .report import render_report_workbook

        specs = list(load_pivot_definitions())
        charts = list(load_chart_definitions())
        if sheets is not None:
            specs = [spec for spec in specs if spec.sheet in sheets]
            charts = [spec for spec in charts if spec.sheet in sheets]
        results = build_pivot_results(input_path, specs)
        return render_report_workbook(
            template_path,
            specs,
            results,
            output_path,
            chart_specs=charts,
            analyst_reference_path=input_path,
        )
    except Exception as exc:
        raise ProcessingError("Unable to generate pivot report") from exc
