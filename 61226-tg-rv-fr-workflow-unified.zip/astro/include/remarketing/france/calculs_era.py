"""Rapport 2 — ERA (France TCM Ford Returns Analysis), lignes de modèle × 16 métriques.

Sources :
  - fichier Remarketing (retours, cessions, produits, coûts, LEV) par modèle
  - Portefeuille (Accounts Expiring) si fourni, sinon approximation par
    DateMaturite du fichier Remarketing
  - taux de change EUR->USD pour la feuille OUTPUT (optionnel)

HYPOTHÈSES À CONFIRMER AVEC SORAYA (voir README) :
  Disposal/Remarketing Costs = Frais à la Vente + 2% Return Fees
  Excess Mileage Charges     = Montant à facturer le client
  Damage/Other Costs         = Frais remise en état
  Insurance Other            = 0
  Net Sales Proceeds         = Sales Proceeds + Excess Mileage + Damage − Disposal Costs
  Net Placement LEV (OFP)    = Σ Balance US (fallback VFMG)
  Total Profit               = Net Sales Proceeds − Net Placement LEV
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as C
from .calculs_remarketing import Prepare


def ligne_era(modele: str, bev: bool) -> str:
    """Ligne era."""
    try:
        m = (modele or "").strip().casefold()
        lib = C.ERA_MODELES.get(m)
        if lib is None:
            for cle, val in C.ERA_MODELES.items():
                if cle and cle in m:
                    lib = val
                    break
        if lib is None:
            return C.ERA_INCONNU
        if bev and lib == "Puma":
            return "Puma Gen-E"
        return lib
    except Exception:
        raise


def _somme(df: pd.DataFrame, col: str | None) -> pd.Series:
    try:
        if not col or col not in df:
            return pd.Series(0.0, index=df.index)
        return pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    except Exception:
        raise


def _bloc(
    df: pd.DataFrame, lignes: list[str], p: Prepare, comptes: pd.Series | None
) -> pd.DataFrame:
    """Un bloc ERA (ICE ou BEV).

    Toute ligne de modèle hors de `lignes` est comptée dans
    'Unknown/ Not recognised'.
    """
    try:
        df = df.copy()
        connues = set(lignes) - {C.ERA_INCONNU}
        df["_ligne_era"] = df["_ligne_era"].where(df["_ligne_era"].isin(connues), C.ERA_INCONNU)
        if C.ERA_INCONNU not in lignes:
            lignes = lignes + [C.ERA_INCONNU]
        c = p.colonnes
        fin = p.date_arrete + pd.offsets.MonthEnd(0)
        debut = fin - pd.offsets.MonthBegin(1)
        d_ret, d_rev = df[c["DATE_RETOUR"]], df[c["DATE_REVENTE"]]
        retourne_mois = (d_ret >= debut) & (d_ret <= fin)
        vendu_mois = df["_vendu"] & (d_rev >= debut) & (d_rev <= fin)
        v = df[vendu_mois]

        out = pd.DataFrame(index=lignes, columns=C.ERA_COLONNES, dtype=float)
        g_stock = df[df["_en_stock_a_date"]].groupby("_ligne_era").size()
        g_ret = df[retourne_mois].groupby("_ligne_era").size()
        g_vend = v.groupby("_ligne_era").size()
        out["Month End Inventory Position"] = g_stock.reindex(lignes).fillna(0)
        out["No. of vehicles returned to FCE"] = g_ret.reindex(lignes).fillna(0)
        if comptes is not None:
            out["Accounts Expiring"] = comptes.reindex(lignes).fillna(0)
        else:
            mat = (
                df[c["DATE_MATURITE"]]
                if c.get("DATE_MATURITE")
                else pd.Series(pd.NaT, index=df.index)
            )
            out["Accounts Expiring"] = (
                df[(mat >= debut) & (mat <= fin)]
                .groupby("_ligne_era")
                .size()
                .reindex(lignes)
                .fillna(0)
            )
        out["Return rate (%)"] = np.where(
            out["Accounts Expiring"] > 0,
            out["No. of vehicles returned to FCE"] / out["Accounts Expiring"],
            np.nan,
        )
        out["No. of vehicles disposed of in month"] = g_vend.reindex(lignes).fillna(0)

        grp = v.groupby("_ligne_era")
        out["Sales Proceeds"] = (
            grp[c["VALEUR_REVENTE"]].sum().reindex(lignes).fillna(0) if c["VALEUR_REVENTE"] else 0.0
        )
        couts = _somme(v, c["FRAIS_VENTE"]) + v["_frais_2pct"].fillna(0)
        out["Disposal / Remarketing Costs"] = (
            couts.groupby(v["_ligne_era"]).sum().reindex(lignes).fillna(0)
        )
        out["Excess Mileage Charges"] = (
            _somme(v, c["MONTANT_FACTURER"])
            .groupby(v["_ligne_era"])
            .sum()
            .reindex(lignes)
            .fillna(0)
        )
        out["Damage / Other Costs"] = (
            _somme(v, c["FRAIS_REMISE"]).groupby(v["_ligne_era"]).sum().reindex(lignes).fillna(0)
        )
        out["Insurance Other"] = 0.0
        out["Net Sales Proceeds"] = (
            out["Sales Proceeds"]
            + out["Excess Mileage Charges"]
            + out["Damage / Other Costs"]
            - out["Disposal / Remarketing Costs"]
        )
        lev = _somme(v, c["BALANCE_US"])
        if c["VFMG"]:
            lev = lev.where(lev != 0, _somme(v, c["VFMG"]))
        out["Net Placement LEV (OFP)"] = (
            lev.groupby(v["_ligne_era"]).sum().reindex(lignes).fillna(0)
        )
        n = out["No. of vehicles disposed of in month"].replace(0, np.nan)
        out["Average disposal price"] = out["Sales Proceeds"] / n
        out["Average placement LEV (OFP)"] = out["Net Placement LEV (OFP)"] / n
        out["Total Profit"] = out["Net Sales Proceeds"] - out["Net Placement LEV (OFP)"]
        out["Profit per Unit"] = out["Total Profit"] / n
        return out
    except Exception:
        raise


def _avec_total(bloc: pd.DataFrame, libelle: str) -> pd.DataFrame:
    try:
        tot = bloc.sum(numeric_only=True)
        n = tot["No. of vehicles disposed of in month"]
        tot["Return rate (%)"] = (
            tot["No. of vehicles returned to FCE"] / tot["Accounts Expiring"]
            if tot["Accounts Expiring"]
            else np.nan
        )
        tot["Average disposal price"] = tot["Sales Proceeds"] / n if n else np.nan
        tot["Average placement LEV (OFP)"] = tot["Net Placement LEV (OFP)"] / n if n else np.nan
        tot["Profit per Unit"] = tot["Total Profit"] / n if n else np.nan
        bloc.loc[libelle] = tot
        return bloc
    except Exception:
        raise


def rapport_era(
    remk: Prepare, comptes_echeance: pd.Series | None = None, taux_change: float | None = None
) -> dict[str, pd.DataFrame]:
    """Rapport era."""
    try:
        df = remk.df[~remk.df["_exclu_restituable"]].copy()
        df["_ligne_era"] = [ligne_era(m, b) for m, b in zip(df["_modele"].fillna(""), df["_bev"])]

        ice_lignes = [m for m in C.ERA_ICE]
        bev_lignes = [m for m in C.ERA_BEV]
        ice = _avec_total(
            _bloc(df[~df["_bev"]], ice_lignes + [C.ERA_INCONNU], remk, comptes_echeance),
            "Subtotal ICE",
        )
        bev = _avec_total(
            _bloc(df[df["_bev"]], bev_lignes + [C.ERA_INCONNU], remk, comptes_echeance),
            "Subtotal BEV",
        )
        total = pd.DataFrame([ice.loc["Subtotal ICE"] + bev.loc["Subtotal BEV"]], index=["Total"])
        n = total.at["Total", "No. of vehicles disposed of in month"]
        total.at["Total", "Return rate (%)"] = (
            total.at["Total", "No. of vehicles returned to FCE"]
            / total.at["Total", "Accounts Expiring"]
            if total.at["Total", "Accounts Expiring"]
            else np.nan
        )
        for col, num in (
            ("Average disposal price", "Sales Proceeds"),
            ("Average placement LEV (OFP)", "Net Placement LEV (OFP)"),
            ("Profit per Unit", "Total Profit"),
        ):
            total.at["Total", col] = total.at["Total", num] / n if n else np.nan

        entree = pd.concat([ice, bev, total])
        tables = {"R2 ERA INPUT (EUR)": entree}
        if taux_change:
            sortie = entree.copy()
            sortie[C.ERA_COLONNES_MONTANT] = sortie[C.ERA_COLONNES_MONTANT] * taux_change
            tables["R2 ERA OUTPUT (USD)"] = sortie
            tables["R2 ERA taux"] = pd.DataFrame(
                {"EUR->USD": [taux_change]}, index=[remk.date_arrete.date()]
            )
        return tables
    except Exception:
        raise
