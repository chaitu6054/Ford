"""Accès GCS (déplacement vérifié, marqueurs) — utilisé uniquement par les DAGs."""

from __future__ import annotations

import os

from airflow.providers.google.cloud.hooks.gcs import GCSHook

from . import config as C


def hook() -> GCSHook:
    """Hook."""
    try:
        return GCSHook(gcp_conn_id=C.GCP_CONN_ID)
    except Exception:
        raise


def separer(uri: str) -> tuple[str, str]:
    """Separer."""
    try:
        sans = uri.replace("gs://", "", 1)
        bucket, _, objet = sans.partition("/")
        return bucket, objet
    except Exception:
        raise


def deplacer_vers_sortie(gcs_path: str, prefixe: str) -> str:
    """Copie l'objet vers le bucket de sortie, vérifie,

    puis supprime la source (demande de la démo).
    """
    try:
        h = hook()
        bucket, objet = separer(gcs_path)
        destination = f"{prefixe}/input/{os.path.basename(objet)}"
        h.copy(
            source_bucket=bucket,
            source_object=objet,
            destination_bucket=C.BUCKET_OUTPUT,
            destination_object=destination,
        )
        if not h.exists(C.BUCKET_OUTPUT, destination):
            raise RuntimeError(f"copie non confirmée : gs://{C.BUCKET_OUTPUT}/{destination}")
        h.delete(bucket_name=bucket, object_name=objet)
        return f"gs://{C.BUCKET_OUTPUT}/{destination}"
    except Exception:
        raise


def telecharger(uri: str, dossier: str) -> str:
    """Telecharger."""
    try:
        bucket, objet = separer(uri)
        local = os.path.join(dossier, os.path.basename(objet))
        hook().download(bucket_name=bucket, object_name=objet, filename=local)
        return local
    except Exception:
        raise


def uploader(local: str, objet: str) -> str:
    """Uploader."""
    try:
        hook().upload(bucket_name=C.BUCKET_OUTPUT, object_name=objet, filename=local)
        return f"gs://{C.BUCKET_OUTPUT}/{objet}"
    except Exception:
        raise


def copier_latest(objet_source: str, nom_latest: str) -> str:
    """Copier latest."""
    try:
        hook().copy(
            source_bucket=C.BUCKET_OUTPUT,
            source_object=objet_source,
            destination_bucket=C.BUCKET_OUTPUT,
            destination_object=f"latest/{nom_latest}",
        )
        return f"gs://{C.BUCKET_OUTPUT}/latest/{nom_latest}"
    except Exception:
        raise


def marqueur(month: str) -> str:
    """Marqueur."""
    try:
        return f"{C.PREFIXE_MARQUEUR}/{month}.done"
    except Exception:
        raise


def mois_traite(month: str) -> bool:
    """Mois traite."""
    try:
        return hook().exists(C.BUCKET_OUTPUT, marqueur(month))
    except Exception:
        raise


def poser_marqueur(month: str, contenu: str) -> None:
    """Poser marqueur."""
    try:
        hook().upload(bucket_name=C.BUCKET_OUTPUT, object_name=marqueur(month), data=contenu)
    except Exception:
        raise


def existe_entree(objet: str) -> bool:
    """Existe entree."""
    try:
        return hook().exists(C.BUCKET_INPUT, objet)
    except Exception:
        raise
