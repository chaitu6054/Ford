"""Notifications e-mail (provider SMTP, Airflow 3).

Sujet : 'workbook reconciliation' comme le UK.
"""

from __future__ import annotations
from typing import Any

import pandas as pd
from airflow.providers.smtp.hooks.smtp import SmtpHook

from . import config as C


def _envoyer(sujet: str, html: str, destinataires: list[str]) -> None:
    try:
        with SmtpHook(smtp_conn_id=C.SMTP_CONN_ID) as smtp:
            smtp.send_email_smtp(
                to=destinataires, subject=sujet, html_content=html, from_email=C.MAIL_FROM
            )
    except Exception:
        raise


def notifier_succes(month: str, resume: pd.DataFrame, liens: dict[str, str]) -> None:
    """Notifier succes."""
    try:
        env = C.environnement()
        tableau = resume.to_html(header=False, border=1)
        liens_html = "<br/>".join(f"{k} : {v}" for k, v in liens.items())
        html = (
            f"<p>France Remarketing workbook reconciliation — "
            f"<b>{month}</b> ({env.upper()})</p>{tableau}"
            f"<p>{liens_html}</p><p>Tous les mois de l'année sont recalculés à chaque exécution "
            f"(les chiffres des mois précédents peuvent être restatés).</p>"
        )
        _envoyer(C.SUJET.format(month=month, statut="SUCCESS"), html, C.MAIL_TO[env])
    except Exception:
        raise


def notifier_echec(month: str, dag_id: str, task_id: str, erreur: str, log_url: str | None) -> None:
    """Notifier echec."""
    try:
        env = C.environnement()
        html = (
            f"<p>DAG <b>{dag_id}</b>, task <b>{task_id}</b> a échoué "
            f"pour le mois <b>{month}</b> ({env.upper()}).</p>"
            f"<pre>{erreur}</pre><p>Log : {log_url or 'n/a'}</p>"
        )
        _envoyer(
            C.SUJET.format(month=month, statut="FAILED"),
            html,
            C.MAIL_TO[env] + C.MAIL_TO_ECHEC_SUPPLEMENT,
        )
    except Exception:
        raise


def callback_echec(context: Any) -> None:
    """Callback echec."""
    try:
        ti = context["task_instance"]
        month = (
            (context.get("dag_run").conf or {}).get("month", "?") if context.get("dag_run") else "?"
        )
        notifier_echec(
            month,
            ti.dag_id,
            ti.task_id,
            str(context.get("exception")),
            getattr(ti, "log_url", None),
        )
    except Exception:
        raise
