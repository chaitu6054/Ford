"""France inventory reporting subpackage.

Continuation reports R1/R2/R3 (ERA, Remarketing, Portefeuille) built on top of
the remarketing workbook automation. Uses only relative imports.
"""
