"""
fr_inventory_file_watcher — surveille le bucket d'entrée une fois par jour (8h Paris).

Comportement demandé à la démo : le watcher "dort" le reste du mois.
  1. verifier_marqueur  : si _processed/<mois>.done existe -> skip immédiat (1 seconde)
  2. attendre_fichier   : sensor en mode reschedule, poke toutes les 15 min,
     abandon après 6 h (skip, pas échec)
  3. declencher         : TriggerDagRun de fr_inventory_monthly_processing
     avec conf {gcs_path, month}
Le mois cherché est le mois précédent (le fichier arrive la première semaine du mois suivant).
"""

from __future__ import annotations
from typing import Any

import sys
from datetime import timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = PROJECT_ROOT / "include"
if str(INCLUDE_ROOT) not in sys.path:
    sys.path.insert(0, str(INCLUDE_ROOT))

from remarketing.france import config as C  # noqa: E402

try:
    import pendulum  # noqa: E402
    from airflow import DAG  # noqa: E402
    from airflow.exceptions import AirflowSkipException  # noqa: E402
    from airflow.providers.google.cloud.sensors.gcs import GCSObjectExistenceSensor  # noqa: E402
    from airflow.providers.standard.operators.python import PythonOperator  # noqa: E402
    from airflow.providers.standard.operators.trigger_dagrun import (
        TriggerDagRunOperator,
    )  # noqa: E402
    from remarketing.france import storage as S  # noqa: E402
except ImportError:  # local unit tests without Airflow installed
    DAG = None
    pendulum = None
    AirflowSkipException = None
    GCSObjectExistenceSensor = None
    PythonOperator = None
    TriggerDagRunOperator = None
    S = None

DAG_CIBLE = "fr_inventory_monthly_processing"
default_args = {"owner": "data-eng", "retries": 0}


def _mois_cible(logical_date) -> str:
    try:
        return logical_date.subtract(months=1).format("YYYY-MM")
    except Exception:
        raise


def verifier_marqueur(**context: Any) -> dict:
    """Verifier marqueur."""
    try:
        month = _mois_cible(context["logical_date"])
        if S.mois_traite(month):
            raise AirflowSkipException(
                f"{month} déjà traité — le watcher dort jusqu'au mois prochain"
            )
        objet = C.MODELE_FICHIER_REMARKETING.format(month=month)
        return {"month": month, "objet": objet, "gcs_path": f"gs://{C.BUCKET_INPUT}/{objet}"}
    except Exception:
        raise


if DAG is not None:
    with DAG(
        dag_id="fr_inventory_file_watcher",
        description="Watcher quotidien du bucket d'entrée France Inventory",
        default_args=default_args,
        start_date=pendulum.datetime(2026, 1, 1, tz="Europe/Paris"),
        schedule="0 8 * * *",
        catchup=False,
        max_active_runs=1,
        tags=["france", "inventory", "watcher"],
    ) as dag:
        t_marqueur = PythonOperator(task_id="verifier_marqueur", python_callable=verifier_marqueur)
        t_attendre = GCSObjectExistenceSensor(
            task_id="attendre_fichier",
            bucket=C.BUCKET_INPUT,
            object="{{ ti.xcom_pull(task_ids='verifier_marqueur')['objet'] }}",
            google_cloud_conn_id=C.GCP_CONN_ID,
            mode="reschedule",
            poke_interval=15 * 60,
            timeout=6 * 3600,
            soft_fail=True,
        )
        t_declencher = TriggerDagRunOperator(
            task_id="declencher_traitement",
            trigger_dag_id=DAG_CIBLE,
            conf={
                "gcs_path": "{{ ti.xcom_pull(task_ids='verifier_marqueur')['gcs_path'] }}",
                "month": "{{ ti.xcom_pull(task_ids='verifier_marqueur')['month'] }}",
            },
            wait_for_completion=False,
            execution_timeout=timedelta(minutes=5),
        )
        t_marqueur >> t_attendre >> t_declencher
