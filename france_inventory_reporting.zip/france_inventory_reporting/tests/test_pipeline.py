"""Tests de fumée sur données fictives (pas de dépendance Airflow)."""
import sys
from datetime import date
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "astro"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from include.remarketing import config as C  # noqa: E402
from include.remarketing import pipeline as P  # noqa: E402
from include.remarketing import workbook as W  # noqa: E402
from include.remarketing.calculs_era import ligne_era  # noqa: E402


@pytest.fixture(scope="session")
def fichiers(tmp_path_factory):
    import generer_donnees_test as G
    d = tmp_path_factory.mktemp("data")
    remk, pf = d / "remarketing_2026-06.xlsx", d / "portefeuille_2026-06.xlsx"
    G.generer(str(remk)); G.generer_portefeuille(str(pf))
    return str(remk), str(pf)


def test_nettoyage_numerique_et_dates():
    import pandas as pd
    s = W.serie_numerique(pd.Series(["16317,49", "2,026.00 €", "4528100%", "-", None]))
    assert round(s.iloc[0], 2) == 16317.49 and s.iloc[1] == 2026.0 and s.iloc[2] == 4528100 and s.isna().iloc[3]
    d = W.serie_date(pd.Series([46106, "2026-06-15", "1900-01-01", None]))
    assert d.iloc[0].year == 2026 and d.iloc[1].month == 6 and d.isna().iloc[2]


def test_ligne_era():
    assert ligne_era("PUMA", False) == "Puma" and ligne_era("PUMA", True) == "Puma Gen-E"
    assert ligne_era("MACH-E", True) == "Mustang Mach-E" and ligne_era("???", False) == C.ERA_INCONNU


def test_pipeline_complet(fichiers):
    remk, pf = fichiers
    P.valider_classeur(remk)
    t = P.generer_rapports(remk, date(2026, 6, 30), pf, taux_change=1.08)
    for nom in ("R1 Canaux", "R1 Mouvements", "R1 Ageing", "R1 KPIs", "R2 ERA INPUT (EUR)", "R2 ERA OUTPUT (USD)",
                "R3 Comptes a echeance", "Exceptions", "Resume"):
        assert nom in t
    m = t["R1 Mouvements"]
    assert m.loc["Inventory End of Period", "contrôle"] == "OK"
    assert t["R1 Ageing"].loc["TCM", "Total units"] == m.loc["Inventory End of Period", "TCM"]
    assert (t["R1 Canaux"].loc[C.LIGNES_CANAUX, "Total (mois)"].sum()) == t["R1 Canaux"].loc["Total", "Total (mois)"]
    assert t["R1 Canaux"].loc[["Traders", "Others"], "Total (mois)"].sum() == 0   # sica/concilian remappés
    era = t["R2 ERA INPUT (EUR)"]
    assert era.loc["Total", "No. of vehicles disposed of in month"] == m.loc["Sold in Period", "TCM"]
    import math
    assert math.isclose(era.loc["Total", "Total Profit"], era.loc["Total", "Net Sales Proceeds"] - era.loc["Total", "Net Placement LEV (OFP)"], rel_tol=1e-9)
    assert era.loc["Total", "Month End Inventory Position"] == m.loc["Inventory End of Period", "TCM"]
    assert not P.valider(t).empty


def test_sans_portefeuille(fichiers):
    remk, _ = fichiers
    t = P.generer_rapports(remk, date(2026, 6, 30))
    assert "R3 Comptes a echeance" not in t and "R2 ERA OUTPUT (USD)" not in t
    assert "approximation" in t["Resume"].loc["ERA Accounts Expiring", "valeur"]
