"""Exécution locale sans Airflow.

    python run_local.py local_test/input/remarketing_2026-06.xlsx 2026-06-30 [portefeuille.xlsx] [taux_eur_usd]
"""
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "astro"))
from include.remarketing import pipeline as P  # noqa: E402

chemin = sys.argv[1]
d = datetime.strptime(sys.argv[2], "%Y-%m-%d").date()
pf = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3].lower() != "none" else None
taux = float(sys.argv[4]) if len(sys.argv) > 4 else None
P.valider_classeur(chemin)
tables = P.generer_rapports(chemin, d, pf, taux)
for nom, t in tables.items():
    print(f"\n=== {nom} ===\n{t}")
print("\n=== VALIDATION vs rapport juin 2026 ===")
print(P.valider(tables).to_string(index=False))
Path("local_test/output").mkdir(parents=True, exist_ok=True)
sortie = f"local_test/output/resultats_france_{d:%Y-%m}.xlsx"
P.ecrire_classeur(tables, sortie)
print(f"\n-> {sortie}")
