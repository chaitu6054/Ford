# France Inventory Reporting — Remarketing / ERA / Portefeuille

Automatisation des rapports France à partir du fichier `REMARKETING_ET_REPOSSESSION_*.xlsx`.
**Aucune colonne n'est traduite** : feuilles, colonnes et valeurs restent en français.

```
astro/
  dags/
    fr_inventory_file_watcher.py        # 8h Paris chaque jour ; dort le reste du mois après traitement
    fr_inventory_monthly_processing.py  # extract -> validate -> calculate -> output_reports -> notify
  include/remarketing/
    config.py                 # buckets, e-mails, règles métier (Soraya 15/09), lignes ERA
    workbook.py               # lecture openpyxl (valeurs en cache), nettoyage, couleurs, FSA
    calculs_remarketing.py    # RAPPORT 1 : canaux, mouvements, ageing, KPIs, pivots, exceptions
    calculs_era.py            # RAPPORT 2 : ERA TCM Ford (lignes de modèle × 16 métriques, EUR + USD)
    calculs_portefeuille.py   # RAPPORT 3 : comptes à échéance par modèle (alimente ERA)
    pipeline.py               # orchestration pure pandas + validation juin 2026 + écriture xlsx
    storage.py                # GCS : déplacement vérifié vers le bucket de sortie, marqueurs
    notifications.py          # e-mails SMTP (Airflow 3), sujet "workbook reconciliation"
  requirements.txt
tests/test_pipeline.py        # pytest, données fictives
run_local.py                  # exécution locale sans Airflow
generer_donnees_test.py       # génère local_test/input/remarketing_2026-06.xlsx + portefeuille_2026-06.xlsx
```

## Lancer en local
```bash
pip install -r astro/requirements.txt pytest
python generer_donnees_test.py                      # données fictives (optionnel)
python run_local.py local_test/input/remarketing_2026-06.xlsx 2026-06-30 [portefeuille.xlsx] [taux_eur_usd]
python -m pytest tests -q
```
Avec le vrai fichier : `python run_local.py REMARKETING_ET_REPOSSESSION_copy24072026.xlsx 2026-06-30`
→ affiche chaque tableau, la **validation ligne par ligne contre le rapport de juin 2026**, et écrit
`local_test/output/resultats_france_2026-06.xlsx` (un onglet par tableau, préfixes R1/R2/R3).

## Fichiers d'entrée (bucket input, uploads manuels uniquement)
| Fichier | Obligatoire | Usage |
|---|---|---|
| `remarketing_YYYY-MM.xlsx` | oui | rapports 1 et 2 (feuilles Remarketing, Repossession, FSA-UPDATE*, code couleur) |
| `portefeuille_YYYY-MM.xlsx` | non | rapport 3 + colonne "Accounts Expiring" du rapport 2 (sinon approximation DateMaturite) |
| `taux_YYYY-MM.xlsx` | non | cellule A1 = taux EUR→USD ; produit la feuille ERA OUTPUT (USD) |

Les trois sont **déplacés** (copie vérifiée puis suppression) vers `gs://<output>/<mois>/<horodatage>/input/`.

## Comportement des DAGs (retours de la démo du 18/09)
- Watcher : `0 8 * * *` Europe/Paris. `verifier_marqueur` skippe en 1 s si `_processed/<mois>.done` existe ;
  sinon `GCSObjectExistenceSensor` (reschedule, 15 min, abandon après 6 h en *skip*) puis `TriggerDagRun`.
  Pour rejouer un mois : supprimer le marqueur ou déclencher le traitement à la main avec la conf.
- Traitement : entrée déplacée vers le bucket de sortie, exceptions.csv, résultats + copie `latest/`, marqueur, e-mail.
- E-mails : `EURVSMTP@FORD.COM` → `EURV_FR_OPERATIONS_DEV/PROD@FORD.COM` (+ `MAIL_TO_ECHEC_SUPPLEMENT` sur échec),
  sujet `France Remarketing workbook reconciliation <mois> - SUCCESS|FAILED`.
- Environnement : `FR_INVENTORY_ENV=dev|prod`, sinon déduit de l'URL Airflow (`astrodev` → dev).

## Règles métier confirmées (Soraya, 15/09)
Restituable ≠ NON · Dealer/SICA = Franchised Dealers · VP Auto/BCA/Autorola/Concilian = Physical Auctions ·
Vendeur vide = non vendu · Performance = moyenne de Valeur revente TTC ÷ Cote ARGUS prof ·
2% Return Fees = 2 % × VFMG · Km excédentaires = Kilométrage − COUVERT × quotos ·
Perte/Profit Remarketing = 2% fees + Montant à facturer · Perte/Profit Repossession = Balance US − Valeur revente ·
Ageing = date d'arrêté − Date de retour, 8 buckets, "statut L" lu via la couleur de ligne.

## À CONFIRMER AVEC SORAYA
1. **Rapport 2 (ERA)** — mapping des coûts : Disposal costs = Frais à la Vente + 2% fees ; Excess Mileage = Montant à facturer ;
   Damage/Other = Frais remise en état ; Insurance = 0 ; Net Sales Proceeds = Proceeds + Excess + Damage − Disposal ;
   Net Placement LEV = Σ Balance US (VFMG en secours) ; Total Profit = Net Proceeds − LEV. Early Termination Charges non calculé.
2. **Rapport 3 (Portefeuille)** — noms de colonnes supposés (voir `PORTEFEUILLE_COLONNES`), filtres Plan = TCM et Marque = Ford.
   Envoyer la ligne d'en-tête du fichier "Portefeuille Complet" pour ajuster.
3. Produits en attente (chiffres rouges du rapport 1) : colonnes Sold Check 1/2/3 en #REF! sans l'onglet PIVOT → placeholder.
4. Les 13 unités O&R du rapport de juin viennent du fichier agence (APC_REPORTING), pas de la feuille Repossession (3 lignes).

## Intégration repo (astro)
Coller `astro/dags/*.py`, `astro/include/remarketing/*.py`, `astro/requirements.txt`. Les DAGs utilisent les imports Airflow 3
(`airflow.providers.standard.*`). Connexions attendues : `google_cloud_default`, `smtp_default`.
