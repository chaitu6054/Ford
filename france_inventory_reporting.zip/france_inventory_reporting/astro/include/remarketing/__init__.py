"""France Inventory Reporting — Remarketing / ERA / Portefeuille. Aucune traduction des colonnes."""
