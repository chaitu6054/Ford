"""Accès GCS (déplacement vérifié, marqueurs) — utilisé uniquement par les DAGs."""
from __future__ import annotations

import os

from airflow.providers.google.cloud.hooks.gcs import GCSHook

from . import config as C


def hook() -> GCSHook:
    return GCSHook(gcp_conn_id=C.GCP_CONN_ID)


def separer(uri: str) -> tuple[str, str]:
    sans = uri.replace("gs://", "", 1)
    bucket, _, objet = sans.partition("/")
    return bucket, objet


def deplacer_vers_sortie(gcs_path: str, prefixe: str) -> str:
    """Copie l'objet vers le bucket de sortie, vérifie, puis supprime la source (demande de la démo)."""
    h = hook()
    bucket, objet = separer(gcs_path)
    destination = f"{prefixe}/input/{os.path.basename(objet)}"
    h.copy(source_bucket=bucket, source_object=objet, destination_bucket=C.BUCKET_OUTPUT, destination_object=destination)
    if not h.exists(C.BUCKET_OUTPUT, destination):
        raise RuntimeError(f"copie non confirmée : gs://{C.BUCKET_OUTPUT}/{destination}")
    h.delete(bucket_name=bucket, object_name=objet)
    return f"gs://{C.BUCKET_OUTPUT}/{destination}"


def telecharger(uri: str, dossier: str) -> str:
    bucket, objet = separer(uri)
    local = os.path.join(dossier, os.path.basename(objet))
    hook().download(bucket_name=bucket, object_name=objet, filename=local)
    return local


def uploader(local: str, objet: str) -> str:
    hook().upload(bucket_name=C.BUCKET_OUTPUT, object_name=objet, filename=local)
    return f"gs://{C.BUCKET_OUTPUT}/{objet}"


def copier_latest(objet_source: str, nom_latest: str) -> str:
    hook().copy(source_bucket=C.BUCKET_OUTPUT, source_object=objet_source,
                destination_bucket=C.BUCKET_OUTPUT, destination_object=f"latest/{nom_latest}")
    return f"gs://{C.BUCKET_OUTPUT}/latest/{nom_latest}"


def marqueur(month: str) -> str:
    return f"{C.PREFIXE_MARQUEUR}/{month}.done"


def mois_traite(month: str) -> bool:
    return hook().exists(C.BUCKET_OUTPUT, marqueur(month))


def poser_marqueur(month: str, contenu: str) -> None:
    hook().upload(bucket_name=C.BUCKET_OUTPUT, object_name=marqueur(month), data=contenu)


def existe_entree(objet: str) -> bool:
    return hook().exists(C.BUCKET_INPUT, objet)
