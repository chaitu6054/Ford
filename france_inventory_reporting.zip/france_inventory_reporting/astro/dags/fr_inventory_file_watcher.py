"""
fr_inventory_file_watcher — surveille le bucket d'entrée une fois par jour (8h Paris).

Comportement demandé à la démo : le watcher "dort" le reste du mois.
  1. verifier_marqueur  : si _processed/<mois>.done existe -> skip immédiat (1 seconde)
  2. attendre_fichier   : sensor en mode reschedule, poke toutes les 15 min, abandon après 6 h (skip, pas échec)
  3. declencher         : TriggerDagRun de fr_inventory_monthly_processing avec conf {gcs_path, month}
Le mois cherché est le mois précédent (le fichier arrive la première semaine du mois suivant).
"""
from __future__ import annotations

from datetime import timedelta

import pendulum
from airflow import DAG
from airflow.exceptions import AirflowSkipException
from airflow.providers.google.cloud.sensors.gcs import GCSObjectExistenceSensor
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.standard.operators.trigger_dagrun import TriggerDagRunOperator

from include.remarketing import config as C
from include.remarketing import storage as S

DAG_CIBLE = "fr_inventory_monthly_processing"
default_args = {"owner": "data-eng", "retries": 0}


def _mois_cible(logical_date: pendulum.DateTime) -> str:
    return logical_date.subtract(months=1).format("YYYY-MM")


def verifier_marqueur(**context) -> dict:
    month = _mois_cible(context["logical_date"])
    if S.mois_traite(month):
        raise AirflowSkipException(f"{month} déjà traité — le watcher dort jusqu'au mois prochain")
    objet = C.MODELE_FICHIER_REMARKETING.format(month=month)
    return {"month": month, "objet": objet, "gcs_path": f"gs://{C.BUCKET_INPUT}/{objet}"}


with DAG(
    dag_id="fr_inventory_file_watcher",
    description="Watcher quotidien du bucket d'entrée France Inventory",
    default_args=default_args,
    start_date=pendulum.datetime(2026, 1, 1, tz="Europe/Paris"),
    schedule="0 8 * * *",
    catchup=False,
    max_active_runs=1,
    tags=["france", "inventory", "watcher"],
) as dag:
    t_marqueur = PythonOperator(task_id="verifier_marqueur", python_callable=verifier_marqueur)
    t_attendre = GCSObjectExistenceSensor(
        task_id="attendre_fichier",
        bucket=C.BUCKET_INPUT,
        object="{{ ti.xcom_pull(task_ids='verifier_marqueur')['objet'] }}",
        google_cloud_conn_id=C.GCP_CONN_ID,
        mode="reschedule",
        poke_interval=15 * 60,
        timeout=6 * 3600,
        soft_fail=True,
    )
    t_declencher = TriggerDagRunOperator(
        task_id="declencher_traitement",
        trigger_dag_id=DAG_CIBLE,
        conf={"gcs_path": "{{ ti.xcom_pull(task_ids='verifier_marqueur')['gcs_path'] }}",
              "month": "{{ ti.xcom_pull(task_ids='verifier_marqueur')['month'] }}"},
        wait_for_completion=False,
        execution_timeout=timedelta(minutes=5),
    )
    t_marqueur >> t_attendre >> t_declencher
