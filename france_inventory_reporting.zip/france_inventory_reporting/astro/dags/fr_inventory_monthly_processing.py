"""
fr_inventory_monthly_processing — extract -> validate -> calculate -> output_reports -> notify

conf attendue : {"gcs_path": "gs://<input>/remarketing_YYYY-MM.xlsx", "month": "YYYY-MM"}
Le fichier d'entrée est DÉPLACÉ (copie vérifiée + suppression) vers le bucket de sortie (audit).
Tous les fichiers générés vont dans le bucket de sortie. Rien n'est traduit.
"""
from __future__ import annotations

import logging
import os
import tempfile
from datetime import date, datetime, timedelta

import pandas as pd
import pendulum
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

from include.remarketing import config as C
from include.remarketing import notifications as N
from include.remarketing import pipeline as P
from include.remarketing import storage as S

LOG = logging.getLogger(__name__)
default_args = {"owner": "data-eng", "retries": 2, "retry_delay": timedelta(minutes=5)}


def _date_arrete(month: str) -> date:
    premier = datetime.strptime(month, "%Y-%m").date()
    return (pd.Timestamp(premier) + pd.offsets.MonthEnd(0)).date()


def extract(**context) -> dict:
    conf = context["dag_run"].conf or {}
    gcs_path, month = conf.get("gcs_path"), conf.get("month")
    if not gcs_path or not month:
        raise ValueError("conf 'gcs_path' et 'month' obligatoires")
    if not gcs_path.lower().endswith((".xlsx", ".xlsm")):
        raise ValueError(f"Le fichier reçu n'est pas un classeur Excel : {gcs_path}")
    prefixe = f"{month}/{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}"
    uri_entree = S.deplacer_vers_sortie(gcs_path, prefixe)
    # fichiers optionnels (Portefeuille, taux) — déplacés s'ils sont présents
    optionnels = {}
    for cle, modele in (("portefeuille", C.MODELE_FICHIER_PORTEFEUILLE), ("taux", C.MODELE_FICHIER_TAUX)):
        objet = modele.format(month=month)
        if S.existe_entree(objet):
            optionnels[cle] = S.deplacer_vers_sortie(f"gs://{C.BUCKET_INPUT}/{objet}", prefixe)
    return {"month": month, "prefixe": prefixe, "date_arrete": _date_arrete(month).isoformat(),
            "uri_entree": uri_entree, **optionnels}


def validate(**context) -> dict:
    meta = context["ti"].xcom_pull(task_ids="extract")
    with tempfile.TemporaryDirectory(prefix="fr_validate_") as dossier:
        local = S.telecharger(meta["uri_entree"], dossier)
        P.valider_classeur(local)
    return meta


def calculate(**context) -> dict:
    meta = context["ti"].xcom_pull(task_ids="validate")
    with tempfile.TemporaryDirectory(prefix="fr_calc_") as dossier:
        local = S.telecharger(meta["uri_entree"], dossier)
        pf = S.telecharger(meta["portefeuille"], dossier) if meta.get("portefeuille") else None
        taux = None
        if meta.get("taux"):
            taux = float(pd.read_excel(S.telecharger(meta["taux"], dossier), header=None).iloc[0, 0])
        tables = P.generer_rapports(local, date.fromisoformat(meta["date_arrete"]), pf, taux)
        if meta["month"] == "2026-06":
            LOG.info("VALIDATION vs rapport juin 2026\n%s", P.valider(tables).to_string(index=False))
        for nom in ("R1 Canaux", "R1 Mouvements", "R1 Ageing", "Resume"):
            LOG.info("%s\n%s", nom, tables[nom].to_string())
        sortie = os.path.join(dossier, f"resultats_france_{meta['month']}.xlsx")
        P.ecrire_classeur(tables, sortie)
        exc = os.path.join(dossier, "exceptions.csv")
        tables["Exceptions"].to_csv(exc, index=False, sep=";")
        resume = tables["Resume"]["valeur"].to_dict()
        return {**meta,
                "resultats_uri": S.uploader(sortie, f"{meta['prefixe']}/output/{os.path.basename(sortie)}"),
                "exceptions_uri": S.uploader(exc, f"{meta['prefixe']}/exceptions.csv"),
                "resume": {k: str(v) for k, v in resume.items()}}


def output_reports(**context) -> dict:
    meta = context["ti"].xcom_pull(task_ids="calculate")
    _, objet = S.separer(meta["resultats_uri"])
    latest = S.copier_latest(objet, f"resultats_france_{meta['month']}.xlsx")
    S.poser_marqueur(meta["month"], f"{meta['resultats_uri']}\n{datetime.utcnow().isoformat()}Z\n")
    return {**meta, "latest_uri": latest}


def notify(**context) -> None:
    meta = context["ti"].xcom_pull(task_ids="output_reports")
    resume = pd.DataFrame.from_dict(meta["resume"], orient="index", columns=["valeur"])
    N.notifier_succes(meta["month"], resume, {"Résultats": meta["resultats_uri"], "Dernière version": meta["latest_uri"],
                                              "Exceptions": meta["exceptions_uri"], "Entrée archivée": meta["uri_entree"]})


with DAG(
    dag_id="fr_inventory_monthly_processing",
    description="France Inventory Reporting — Remarketing, ERA, Portefeuille (colonnes françaises conservées)",
    default_args=default_args,
    start_date=pendulum.datetime(2026, 1, 1, tz="Europe/Paris"),
    schedule=None,
    catchup=False,
    max_active_runs=1,
    tags=["france", "inventory", "remarketing", "era"],
    on_failure_callback=N.callback_echec,
) as dag:
    t1 = PythonOperator(task_id="extract", python_callable=extract)
    t2 = PythonOperator(task_id="validate", python_callable=validate)
    t3 = PythonOperator(task_id="calculate", python_callable=calculate)
    t4 = PythonOperator(task_id="output_reports", python_callable=output_reports)
    t5 = PythonOperator(task_id="notify", python_callable=notify)
    t1 >> t2 >> t3 >> t4 >> t5
