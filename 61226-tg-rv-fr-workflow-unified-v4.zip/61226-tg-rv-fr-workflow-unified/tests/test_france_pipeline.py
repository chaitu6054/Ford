"""Smoke tests on synthetic data for the France calculations (no Airflow)."""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from remarketing.france import config as C  # noqa: E402
from remarketing.france import pipeline as P  # noqa: E402
from remarketing.france import workbook as W  # noqa: E402
from remarketing.france.calculs_era import ligne_era  # noqa: E402


@pytest.fixture(scope="session")
def fichiers(tmp_path_factory):
    try:
        import generer_donnees_test as G

        d = tmp_path_factory.mktemp("data")
        remk, pf = d / "remarketing_2026-06.xlsx", d / "portefeuille_2026-06.xlsx"
        G.generer(str(remk))
        G.generer_portefeuille(str(pf))
        return str(remk), str(pf)
    except Exception as exc:
        raise RuntimeError(f"Unable to build France fixtures: {exc}") from exc


def test_nettoyage_numerique_et_dates():
    try:
        import pandas as pd

        s = W.serie_numerique(pd.Series(["16317,49", "2,026.00 €", "4528100%", "-", None]))
        assert round(s.iloc[0], 2) == 16317.49
        assert s.iloc[1] == 2026.0 and s.iloc[2] == 4528100 and s.isna().iloc[3]
        d = W.serie_date(pd.Series([46106, "2026-06-15", "1900-01-01", None]))
        assert d.iloc[0].year == 2026 and d.iloc[1].month == 6 and d.isna().iloc[2]
    except Exception:
        raise


def test_serie_numerique_formats_fr_et_comptables():
    """Espaces unicode FR, négatifs entre parenthèses, séparateurs mixtes."""
    try:
        import pandas as pd

        s = W.serie_numerique(
            pd.Series(
                [
                    "1\u202f234,56 €",  # insécable étroite FR
                    "1 234,56",  # insécable classique
                    "(2,026.00)",  # négatif comptable US
                    "(1.234,56)",  # négatif comptable FR
                    "1.234,56",  # décimale = virgule la plus à droite
                    "1,234,567",  # milliers US sans décimale
                    "USD 1,234.56",  # code monétaire
                    "–",  # tiret cadratin vide
                ]
            )
        )
        assert round(s.iloc[0], 2) == 1234.56
        assert round(s.iloc[1], 2) == 1234.56
        assert s.iloc[2] == -2026.0
        assert round(s.iloc[3], 2) == -1234.56
        assert round(s.iloc[4], 2) == 1234.56
        assert s.iloc[5] == 1234567.0
        assert round(s.iloc[6], 2) == 1234.56
        assert s.isna().iloc[7]
    except Exception:
        raise


def test_ligne_era():
    try:
        assert ligne_era("PUMA", False) == "Puma" and ligne_era("PUMA", True) == "Puma Gen-E"
        assert ligne_era("MACH-E", True) == "Mustang Mach-E"
        assert ligne_era("???", False) == C.ERA_INCONNU
    except Exception:
        raise


def test_pipeline_complet(fichiers):
    try:
        remk, pf = fichiers
        P.valider_classeur(remk)
        t = P.generer_rapports(remk, date(2026, 6, 30), pf, taux_change=1.08)
        for nom in (
            "R1 Canaux",
            "R1 Mouvements",
            "R1 Ageing",
            "R1 KPIs",
            "R2 ERA INPUT (EUR)",
            "R2 ERA OUTPUT (USD)",
            "R3 Comptes a echeance",
            "Exceptions",
            "Resume",
        ):
            assert nom in t
        m = t["R1 Mouvements"]
        assert m.loc["Inventory End of Period", "contrôle"] == "OK"
        assert t["R1 Ageing"].loc["TCM", "Total units"] == m.loc["Inventory End of Period", "TCM"]
        assert (
            t["R1 Canaux"].loc[C.LIGNES_CANAUX, "Total (mois)"].sum()
        ) == t["R1 Canaux"].loc["Total", "Total (mois)"]
        assert t["R1 Canaux"].loc[["Traders", "Others"], "Total (mois)"].sum() == 0
        era = t["R2 ERA INPUT (EUR)"]
        assert (
            era.loc["Total", "No. of vehicles disposed of in month"]
            == m.loc["Sold in Period", "TCM"]
        )
        import math

        assert math.isclose(
            era.loc["Total", "Total Profit"],
            era.loc["Total", "Net Sales Proceeds"] - era.loc["Total", "Net Placement LEV (OFP)"],
            rel_tol=1e-9,
        )
        assert (
            era.loc["Total", "Month End Inventory Position"]
            == m.loc["Inventory End of Period", "TCM"]
        )
        assert not P.valider(t).empty
    except Exception:
        raise


def test_sans_portefeuille(fichiers):
    try:
        remk, _ = fichiers
        t = P.generer_rapports(remk, date(2026, 6, 30))
        assert "R3 Comptes a echeance" not in t and "R2 ERA OUTPUT (USD)" not in t
        assert "approximation" in t["Resume"].loc["ERA Accounts Expiring", "valeur"]
    except Exception:
        raise


def test_charger_portefeuille_choisit_la_feuille_portefeuille_complet(tmp_path):
    """La 1re feuille peut être un TCD : on lit « Portefeuille Complet »."""
    try:
        import pandas as pd

        from remarketing.france import calculs_portefeuille as CP

        brut = pd.DataFrame(
            {
                "Numéro de contrat": ["1", "2"],
                "N° de série": ["VIN1", "VIN2"],
                "Modèle": ["Puma", "Kuga"],
                "Maturité": ["30-Sep-26", "15-Oct-26"],
                "Code Plan": ["TCM", "TCM"],
            }
        )
        chemin = tmp_path / "pf.xlsx"
        with pd.ExcelWriter(chemin, engine="openpyxl") as w:
            pd.DataFrame({"TCD": ["x"]}).to_excel(w, sheet_name="Feuil1", index=False)
            brut.to_excel(w, sheet_name="Portefeuille Complet", index=False)
        df = CP.charger_portefeuille(str(chemin))
        assert "Numéro de contrat" in df.columns
        c = W.resoudre_colonnes(df, C.PORTEFEUILLE_COLONNES)
        assert c["CONTRAT"] == "Numéro de contrat"
        assert c["VIN"] == "N° de série"
        assert c["MODEL"] == "Modèle"
        assert c["DATE_MATURITE"] == "Maturité"
        assert c["PLAN"] == "Code Plan"
        prep, _ = CP.preparer_portefeuille(df)
        assert prep["_tcm"].all() and (prep["_mois"] == [9, 10]).all()
    except Exception:
        raise


def test_preparer_portefeuille_note_filtre_vide(tmp_path):
    """0 contrat TCM+Ford retenu => note de diagnostic dans les exceptions."""
    try:
        import pandas as pd

        from remarketing.france import calculs_portefeuille as CP

        df = pd.DataFrame(
            {
                "Numéro de contrat": ["1"],
                "Maturité": ["30-Sep-26"],
                "Code Plan": ["AUTRE"],
            }
        )
        _, exc = CP.preparer_portefeuille(df)
        assert any("0/1 contrats retenus" in str(m) for m in exc["motif"])
    except Exception:
        raise
