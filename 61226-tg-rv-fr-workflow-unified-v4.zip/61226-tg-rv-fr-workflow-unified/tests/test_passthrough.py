from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

TEMPLATE = Path(__file__).resolve().parents[1] / "astro" / "config" / "report_template.xlsx"


def _source_workbook(path: Path) -> Path:
    wb = Workbook()
    default = wb.active
    default.title = "regle offensive"
    default["A1"] = "reference value"
    default["A1"].font = Font(bold=True)
    default.column_dimensions["A"].width = 22
    default.row_dimensions[1].height = 30
    default.merge_cells("B2:C2")
    default["B2"] = "merged"
    default.freeze_panes = "B2"
    default["D1"] = "=1+1"  # no cached result in an openpyxl-created workbook

    repo = wb.create_sheet("Repossession")
    repo["A1"] = 123
    legacy = wb.create_sheet("Feuil4")
    legacy["A1"] = "exclude"
    generic = wb.create_sheet("Sheet1")
    generic["A1"] = "exclude"
    wb.save(path)
    wb.close()
    return path


def test_pass_through_sheet_policy_is_exact():
    from remarketing.report import PASS_THROUGH_SHEETS

    assert PASS_THROUGH_SHEETS == (
        "regle offensive",
        "Détails1",
        "Détails2",
        "Solde a checker offensive",
        "Ludovic",
        "remarketing retractatio-engagem",
        "suivi offensivetracker",
        "Repossession",
        "FSA-UPDATE 24042026",
        "code couleur",
    )
    assert "Feuil4" not in PASS_THROUGH_SHEETS
    assert "Sheet1" not in PASS_THROUGH_SHEETS


def test_pass_through_copies_cached_values_styles_and_sheet_settings_without_formulas(tmp_path):
    from remarketing.report import copy_pass_through_sheets

    source = _source_workbook(tmp_path / "source.xlsx")
    target = load_workbook(TEMPLATE, data_only=False, keep_links=False)
    try:
        warnings = copy_pass_through_sheets(source, target)
        assert "regle offensive" in target.sheetnames
        assert "Repossession" in target.sheetnames
        assert "Feuil4" not in target.sheetnames
        assert "Sheet1" not in target.sheetnames

        ws = target["regle offensive"]
        assert ws["A1"].value == "reference value"
        assert ws["A1"].font.bold is True
        assert ws.column_dimensions["A"].width == 22
        assert ws.row_dimensions[1].height == 30
        assert "B2:C2" in {str(rng) for rng in ws.merged_cells.ranges}
        assert ws.freeze_panes == "B2"
        assert ws["D1"].value is None
        assert any("PASS_THROUGH_FORMULA_WITHOUT_CACHE" in warning and "regle offensive!D1" in warning for warning in warnings)
        assert not any(cell.data_type == "f" for row in ws.iter_rows() for cell in row)
    finally:
        target.close()


def test_renderer_can_enable_full_fidelity_pass_through(tmp_path):
    from remarketing.report import render_report_workbook

    source = _source_workbook(tmp_path / "source.xlsx")
    output = tmp_path / "full.xlsx"
    warnings: list[str] = []
    render_report_workbook(
        TEMPLATE,
        [],
        {},
        output,
        passthrough_source=source,
        passthrough_warnings=warnings,
    )
    wb = load_workbook(output, data_only=False, keep_links=False)
    try:
        assert "Repossession" in wb.sheetnames
        assert "regle offensive" in wb.sheetnames
        assert "Feuil4" not in wb.sheetnames
        assert not wb._external_links
    finally:
        wb.close()
    assert any("PASS_THROUGH_FORMULA_WITHOUT_CACHE" in warning for warning in warnings)
