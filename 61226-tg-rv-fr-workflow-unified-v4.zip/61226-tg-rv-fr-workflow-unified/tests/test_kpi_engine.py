from __future__ import annotations

from datetime import date
import os
from pathlib import Path

import pytest

from remarketing.normalize import extract_remarketing
from remarketing.validate import inspect_workbook
from remarketing.models import Dataset, ExcelError
from remarketing.workbook import OOXMLWorkbook

REFERENCE = Path(os.environ.get("REFERENCE_WORKBOOK", "/mnt/data/REMARKETING_ET_REPOSSESSION_copy24072026.xlsx"))
AGE_BUCKETS = (
    "0-30 Days",
    "31-60 Days",
    "61-90 Days",
    "91-120 Days",
    "121-150 Days",
    "151-180 Days",
    "181-360 Days",
    "360+ Days",
)


def dataset(rows):
    headers = ("Sold Check 2", "Sold Check 3", "FSA", "Age Bucket (Unsold)")
    return Dataset(headers, {name: name for name in headers}, rows)


def test_intact_kpi_logic_matches_analyst_formulas():
    from remarketing.calculate import calculate_intact_kpis

    rows = [
        {"Sold Check 2": "Non Solde", "Sold Check 3": "Non Solde", "FSA": "FSA", "Age Bucket (Unsold)": "0-30 Days"},
        {"Sold Check 2": "Non Solde", "Sold Check 3": "Non Solde", "FSA": None, "Age Bucket (Unsold)": "31-60 Days"},
        {"Sold Check 2": "Non Solde", "Sold Check 3": "Solde", "FSA": "FSA", "Age Bucket (Unsold)": "360+ Days"},
        {"Sold Check 2": "solde", "Sold Check 3": "Solde", "FSA": None, "Age Bucket (Unsold)": None},
    ]
    values = calculate_intact_kpis(dataset(rows), date(2026, 9, 16))

    assert values["C2"] == date(2026, 9, 16)
    assert values["C3"] == 3
    assert values["T4"] == 2
    assert values["C6"] == 1
    assert [values[cell] for cell in ("H4", "I4", "J4", "K4", "L4", "M4", "N4", "O4")] == [1, 1, 0, 0, 0, 0, 0, 1]
    assert values["P4"] == 3
    assert values["R4"] == "OK"
    assert values["C19"] == date(2026, 9, 16)
    assert values["E19"] == date(2026, 9, 16)


def test_ageing_bucket_contract_contains_all_eight_source_labels():
    from remarketing.calculate import AGEING_BUCKETS

    assert AGEING_BUCKETS == AGE_BUCKETS


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_source_kpi_dates_are_converted_from_excel_serials_using_cell_formats():
    from remarketing.calculate import source_kpi_date

    with OOXMLWorkbook(REFERENCE) as book:
        assert source_kpi_date(book, "B1") == date(2026, 1, 1)
        assert source_kpi_date(book, "C10") == date(2026, 2, 28)


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_broken_source_formulas_are_preserved_as_errors_with_warnings():
    from remarketing.calculate import build_kpi_result

    with OOXMLWorkbook(REFERENCE) as book:
        inspection = inspect_workbook(book)
        data = extract_remarketing(book, inspection)
        result = build_kpi_result(data, inspection.report_as_of_date, book)

    assert result.values["C4"] == ExcelError("#REF!")
    assert result.values["C7"] == ExcelError("#REF!")
    assert result.values["H13"] == ExcelError("#REF!")
    assert result.values["B21"] == ExcelError("#REF!")
    assert any("SOURCE_FORMULA_BROKEN_PRESERVED" in warning and "KPIs!C4" in warning for warning in result.warnings)
    assert all("C21" not in warning for warning in result.warnings)  # cached IFERROR result is blank, not an Excel error


def test_renderer_writes_kpis_without_changing_template_formats(tmp_path):
    from openpyxl import load_workbook

    from remarketing.calculate import KPIResult
    from remarketing.report import render_kpi_result

    template = Path(__file__).resolve().parents[1] / "astro" / "config" / "report_template.xlsx"
    wb = load_workbook(template, data_only=False, keep_links=False)
    try:
        ws = wb["KPIs"]
        c2_format = ws["C2"].number_format
        c4_format = ws["C4"].number_format
        result = KPIResult(
            values={"C2": date(2026, 9, 16), "C3": 3, "C4": ExcelError("#REF!"), "R4": "OK"},
            warnings=[],
        )
        render_kpi_result(ws, result)
        assert ws["C2"].value == date(2026, 9, 16)
        assert ws["C3"].value == 3
        assert ws["C4"].value == "#REF!"
        assert ws["R4"].value == "OK"
        assert ws["C2"].number_format == c2_format
        assert ws["C4"].number_format == c4_format
    finally:
        wb.close()
