from pathlib import Path
import importlib.util


def load_runner():
    spec=importlib.util.spec_from_file_location('run_local', Path(__file__).resolve().parents[1] / 'local' / 'run_local.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def test_local_runner_rejects_multiple_default_inputs(tmp_path):
    runner=load_runner(); input_dir=tmp_path/'input'; output_dir=tmp_path/'output'; input_dir.mkdir(); output_dir.mkdir()
    (input_dir/'a.xlsx').write_bytes(b'a'); (input_dir/'b.xlsx').write_bytes(b'b')
    assert runner.main(['--input-dir',str(input_dir),'--output-dir',str(output_dir)]) == 2


def test_local_runner_prints_both_fidelity_verdicts(tmp_path, monkeypatch, capsys):
    from remarketing.models import PipelineResult, RunStatus

    runner = load_runner()
    input_dir = tmp_path / "input"
    output_dir = tmp_path / "output"
    input_dir.mkdir()
    source = input_dir / "client.xlsx"
    source.write_bytes(b"client")

    def fake_process_local_file(**kwargs):
        return PipelineResult(
            status=RunStatus.SUCCESS,
            processing_date="2026-09-17",
            source_file="client.xlsx",
            source_sha256="abc",
            business_reconciliation="PASS",
            visual_fidelity="PASS",
        )

    monkeypatch.setattr(runner, "process_local_file", fake_process_local_file)
    assert runner.main(["--input-dir", str(input_dir), "--output-dir", str(output_dir)]) == 0
    output = capsys.readouterr().out
    assert "Business reconciliation: PASS" in output
    assert "Visual fidelity: PASS" in output
