"""Génère un classeur de test avec la structure du fichier de base (données fictives)."""
import random
from datetime import date, timedelta

from openpyxl import Workbook
from openpyxl.styles import PatternFill

random.seed(42)
ARRETE = date(2026, 6, 30)

COULEURS = {
    "0070C0": "le concessionaire a change d'avis et il va finalement reprendre le vhl",
    "70AD47": "dossier complet",
    "FFFFFF": "dossier incomplet",
    "FFFF00": "dossier vendu via le reseau",
    "7030A0": "engagement de reprise concess",
    "ED7D31": "dossier en statut L",
    "808080": "delinquences / restitution anticipe",
}

ENTETES_REMK = [
    "Contrat", "VIN", "date vente", "comment RO", "immat", "METS UN TITRE !", "Statut", "Etape",
    "Date de retour", "Année de Retour", "Mois de retour", "check VD fichier",
    "Enagement de reprise en DMS\n(OUI/NON)", "Adhesion Offensive", "Restituable", "Code Dealer Origine",
    "Nom Concession Origine", "DateMaturite", "Contrat Terms (mois)", "Model", "Engine (a remplir Risk)",
    "Kilométrage fait par le client", "Cote ARGUS prof", "cote Argus HT", "Argus Personnalisé",
    "Balance US", "VFMG", "DG", "Valeur revente TTC", "Frais à la Vente", "2% Return Fees",
    "Perte/Profit (difference)", "Performance vs# Market Value (%) (Cote Argus Prof)", "date revente",
    "Mois de Vente", "Année de vente", "Vendeur", "Delinquance (OUI/NON)", "quotos", "COUVERT BLESS PAR AN",
    "Kilometres excedentaires", "Montant a facturer le client", "Frais remise en etat", "FSA",
]
MODELES = ["PUMA", "KUGA", "MACH-E", "FOCUS", "FIESTA"]
VENDEURS = ["VP Auto", "BCA", "Dealer", "Concilian", "sica", "Autorola"]
ETAPES = ["Non affecte", "Lot Ludovic de Fombelle", "Lot VP Auto", "Lot Autorola", "Lot Zelus", "Concilian"]


def ligne_fictive(i: int, retour: date, vendu_le: date | None, restituable: str, vendeur: str | None):
    km = random.randint(8000, 65000)
    argus = random.choice([12000, 14000, 16000, 18000, 21000, 24000, 27000])
    vfmg = round(argus * random.uniform(0.7, 1.05), 2)
    revente = round(argus * random.uniform(0.75, 0.95), 2) if vendu_le else None
    quotas, couvert = random.choice([2.083333, 3.083333]), random.choice([10000, 15000, 20000, 25000])
    km_exc = km - couvert * quotas
    montant = round(max(km_exc, 0) * 0.07, 2) if vendu_le else None
    modele = random.choice(MODELES)
    return [
        460000 + i, f"WF0FXXWPMH{i:07d}", None, None, f"GV-{i%900:03d}-AB", None,
        "Solde" if vendu_le else "Non affecte",
        random.choice(ETAPES) if not vendu_le else f"Lot {vendeur}",
        retour, retour.year, retour.month, None, "Non", "signé" if restituable == "NON" else "NC", restituable,
        random.randint(100, 900), "CONCESSION X", retour + timedelta(days=random.randint(-20, 20)), 25, modele,
        random.choice(["1.0 Flexifuel Hybrid", "2.5 Duratec PHEV", "Electric"]),
        km, argus, round(argus / 1.2, 2), None, round(vfmg * 1.02, 2), vfmg, 0, revente, 0,
        None, None, None, vendu_le, vendu_le.month if vendu_le else None, vendu_le.year if vendu_le else None,
        vendeur, "Non", quotas, couvert, km_exc, montant, 0, None,
    ]


def generer(chemin: str):
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws.append(ENTETES_REMK)
    fsa_vins = []
    rows = []
    i = 0
    # Retours 2025 (majoritairement vendus) + retours 2026 jusqu'à juillet
    for mois_offset in range(-16, 2):
        annee_mois = date(2026, 6, 1) + timedelta(days=31 * mois_offset)
        nb = random.randint(40, 150) if annee_mois.year == 2026 and annee_mois.month <= 3 else random.randint(20, 70)
        for _ in range(nb):
            i += 1
            retour = date(annee_mois.year, annee_mois.month, random.randint(1, 28))
            restituable = random.choices(["OUI", "NC", "NON"], weights=[70, 15, 15])[0]
            delai = random.choice([None, 20, 45, 70, 100, 130, 160, 250, 400])
            vendu_le = retour + timedelta(days=delai) if delai and restituable != "NON" else None
            if vendu_le and vendu_le > date(2026, 7, 24):
                vendu_le = None
            vendeur = random.choices(VENDEURS, weights=[40, 15, 25, 5, 10, 5])[0] if vendu_le else None
            rows.append((ligne_fictive(i, retour, vendu_le, restituable, vendeur), restituable))
    for r, restituable in rows:
        ws.append(r)
        rgb = random.choices(list(COULEURS), weights=[5, 40, 20, 15, 10, 5, 5])[0]
        for cell in ws[ws.max_row]:
            cell.fill = PatternFill("solid", fgColor=rgb)
        if random.random() < 0.08:
            fsa_vins.append(r[1])
    # quelques cas sales
    ws.append(ligne_fictive(99991, date(2026, 5, 3), date(2026, 6, 15), "OUI", "Dealer"))
    ws.cell(ws.max_row, ENTETES_REMK.index("Valeur revente TTC") + 1).value = "16317,49"
    ws.append(ligne_fictive(99992, date(2026, 4, 3), None, "OUI", None))
    ws.cell(ws.max_row, ENTETES_REMK.index("Date de retour") + 1).value = 46106  # serial
    ws.append(ligne_fictive(99993, date(2026, 4, 3), None, "OUI", None))
    ws.cell(ws.max_row, ENTETES_REMK.index("DateMaturite") + 1).value = date(1900, 1, 1)

    wr = wb.create_sheet("Repossession")
    wr.append(["Date d'inscription de dossier", "Date maj", "Repossession", "Numero contrat", "Nom Client",
               "N d'immatriculation", "Modele", "Balance US", "VFMG", "DG", "Valeur revente",
               "Perte/Profit (difference)", "date revente", "Delinquance (OUI/NON)", "Date Maturite"])
    for k in range(20):
        ins = date(2026, random.randint(1, 6), random.randint(1, 28))
        rev = ins + timedelta(days=random.randint(10, 60)) if random.random() < 0.6 else None
        wr.append([ins, ins, "Repossession", 470000 + k, "CLIENT", "GR-000-AA", "PUMA 0222",
                   round(random.uniform(15000, 45000), 2), round(random.uniform(12000, 40000), 2), 0,
                   round(random.uniform(10000, 30000), 2) if rev else 0, None, rev, "oui", None])

    wf = wb.create_sheet("FSA-UPDATE 24042026")
    wf.append(["VIN", "CURRENT COUNTRY", "FSA"])
    for v in fsa_vins:
        wf.append([v, "ESP", "FSA"])

    wc = wb.create_sheet("code couleur")
    wc.append(["code couleur:", None])
    for rgb, lib in COULEURS.items():
        wc.append([None, lib])
        wc.cell(wc.max_row, 1).fill = PatternFill("solid", fgColor=rgb)

    wb.save(chemin)
    print(f"{chemin}: {len(rows) + 3} lignes Remarketing, {len(fsa_vins)} FSA")


def generer_portefeuille(chemin: str):
    from openpyxl import Workbook as _WB
    wb = _WB(); ws = wb.active; ws.title = "Portefeuille"
    ws.append(["Numero contrat", "VIN", "Modele", "Date Maturite", "Plan", "Marque"])
    for k in range(900):
        mat = date(2026, random.randint(1, 12), random.randint(1, 28))
        ws.append([500000 + k, f"WF0PF{k:08d}", random.choice(["PUMA", "KUGA", "MACH-E", "FOCUS", "FIESTA", "TRANSIT CUSTOM"]),
                   mat, random.choice(["TCM", "TCM", "TCM", "LOA"]), random.choice(["Ford", "Ford", "Ford", "Autre"])])
    wb.save(chemin); print(f"{chemin}: 900 lignes")


if __name__ == "__main__":
    import os
    os.makedirs("local_test/input", exist_ok=True)
    generer("local_test/input/remarketing_2026-06.xlsx")
    generer_portefeuille("local_test/input/portefeuille_2026-06.xlsx")
