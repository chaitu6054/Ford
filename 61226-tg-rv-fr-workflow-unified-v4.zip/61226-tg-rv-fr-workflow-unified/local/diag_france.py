"""Diagnostic France : rejoue l'etape France seule et affiche la traceback complete.

Usage :
    python local/diag_france.py ["C:\\chemin\\vers\\portefeuille.xlsx"]
    python local/diag_france.py 2026-07-31 ["C:\\chemin\\vers\\portefeuille.xlsx"]

Sans date, le mois de traitement est détecté depuis les données du fichier.
"""
import sys
import traceback
from datetime import date
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "astro" / "include"))

from remarketing.france_reports import generate_france_reports, resolve_report_date


def main() -> None:
    args = sys.argv[1:]
    explicit = None
    if args and len(args[0]) == 10 and args[0][4] == "-":
        explicit = date.fromisoformat(args.pop(0))
    pf = Path(args[0]) if args else None
    cands = sorted(
        (REPO / "local" / "input").glob("*.xls*"),
        key=lambda p: p.stat().st_mtime,
    )
    if not cands:
        print("Aucun classeur trouve dans local/input")
        return
    src = cands[-1]
    out = REPO / "local" / "output" / "diag" / "output"
    out.mkdir(parents=True, exist_ok=True)
    print("source:", src.name)
    print("portefeuille:", pf)
    try:
        jour = resolve_report_date(src, explicit)
        print("mois de traitement:", jour)
        res = generate_france_reports(
            input_path=src,
            output_dir=out,
            processing_date=jour,
            portefeuille_path=pf,
            taux=None,
        )
    except Exception:
        traceback.print_exc()
        return
    print("OK")
    print("Remarketing:", res.remarketing_path)
    print("ERA:", res.era_path)
    print("Portefeuille:", res.portefeuille_path)


if __name__ == "__main__":
    main()
