"""Notification abstractions. Production defaults to structured logging."""
from __future__ import annotations

import logging
from collections.abc import Callable, Mapping
from typing import Any, Protocol

from .errors import NotificationError

LOGGER = logging.getLogger(__name__)


class Notifier(Protocol):
    """Notification interface used by orchestration without provider coupling."""

    def notify(self, event: str, message: str, context: Mapping[str, Any]) -> None:
        """Emit one structured processing notification."""
        try:
            ...
        except Exception:
            raise


class LoggingNotifier:
    """Default notifier that emits structured events through Python logging."""

    def notify(self, event: str, message: str, context: Mapping[str, Any]) -> None:
        """Write one notification event to the configured application logger."""
        try:
            LOGGER.info(
                "remarketing_event=%s message=%s context=%s",
                event,
                message,
                dict(context),
            )
        except Exception as exc:
            raise NotificationError(f"Unable to emit notification {event}") from exc


def _environment() -> str:
    """dev on astrodev deployments, prod otherwise (override with REMARKETING_ENV)."""
    try:
        import os

        explicit = os.environ.get("REMARKETING_ENV")
        if explicit:
            return explicit.strip().lower()
        base_url = os.environ.get(
            "AIRFLOW__API__BASE_URL",
            os.environ.get("AIRFLOW__WEBSERVER__BASE_URL", "astrodev"),
        )
        return "dev" if "astrodev" in base_url else "prod"
    except Exception as exc:
        raise NotificationError("Unable to resolve notification environment") from exc


EmailSender = Callable[[list[str], str, str, str], None]


class SmtpNotifier:
    """E-mail notifier. The transport is injected by the DAG layer (Airflow SMTP provider),
    so this shared package stays free of Airflow imports.

    Subject follows the UK convention:
    "France Remarketing workbook reconciliation <month> - <STATUS>".
    Failure e-mails add the configured ``failure_cc`` recipients (FBS contacts).
    """

    def __init__(self, config: Any, sender: EmailSender) -> None:
        try:
            self._config = config
            self._sender = sender
            self._env = _environment()
        except Exception as exc:
            raise NotificationError("Unable to initialise SMTP notifier") from exc

    def _recipients(self, failure: bool) -> list[str]:
        try:
            base = self._config.mail_to_prod if self._env == "prod" else self._config.mail_to_dev
            extra = tuple(self._config.mail_failure_cc) if failure else ()
            seen: list[str] = []
            for address in tuple(base) + extra:
                if address and address not in seen:
                    seen.append(address)
            return seen
        except Exception as exc:
            raise NotificationError("Unable to resolve e-mail recipients") from exc

    def send(self, *, month: str, status: str, html: str) -> None:
        """Send one e-mail; ``status`` is SUCCESS or FAILED."""
        try:
            subject = (
                f"[{self._env.upper()}] France Remarketing workbook reconciliation "
                f"{month} - {status}"
            )
            self._sender(
                self._recipients(failure=status != "SUCCESS"),
                subject,
                html,
                self._config.mail_from,
            )
        except Exception as exc:
            raise NotificationError(f"Unable to send {status} e-mail for {month}") from exc

    def notify(self, event: str, message: str, context: Mapping[str, Any]) -> None:
        """Notifier protocol: log every event, e-mail only terminal ones."""
        try:
            LOGGER.info(
                "remarketing_event=%s message=%s context=%s", event, message, dict(context)
            )
            if event not in {"SUCCESS", "FAILED"}:
                return
            month = str(context.get("month") or context.get("processing_date") or "?")[:7]
            self.send(month=month, status=event, html=render_html(message, context))
        except NotificationError:
            raise
        except Exception as exc:
            raise NotificationError(f"Unable to emit notification {event}") from exc


def render_html(message: str, context: Mapping[str, Any]) -> str:
    """Small HTML table with the run summary (links, counts, verdicts)."""
    try:
        rows = "".join(
            f"<tr><td><b>{key}</b></td><td>{value}</td></tr>"
            for key, value in dict(context).items()
            if value not in (None, "", [])
        )
        return (
            f"<p>{message}</p><table border='1' cellpadding='4'>{rows}</table>"
            "<p>Tous les mois de l'année sont recalculés à chaque exécution ; "
            "les chiffres des mois précédents peuvent être restatés.</p>"
        )
    except Exception as exc:
        raise NotificationError("Unable to render notification HTML") from exc
