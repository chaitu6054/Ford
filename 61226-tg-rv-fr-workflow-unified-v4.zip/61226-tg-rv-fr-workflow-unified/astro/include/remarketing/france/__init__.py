"""France inventory reporting — Remarketing / ERA / Portefeuille.

French sheet, column and value names are preserved (nothing is translated).
"""
