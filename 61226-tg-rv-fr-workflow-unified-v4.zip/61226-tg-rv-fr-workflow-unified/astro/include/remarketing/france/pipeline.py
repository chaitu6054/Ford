"""Orchestration pure pandas (sans Airflow) : exécutable en local et depuis les tasks du DAG."""

from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from . import calculs_era as ERA
from . import calculs_portefeuille as PF
from . import calculs_remarketing as R1
from . import config as C
from . import workbook as W


def valider_classeur(chemin: str) -> None:
    """Niveau classeur + feuille. Lève ValueError avec un message explicite."""
    try:
        noms = W.feuilles(chemin)
        manquantes = [f for f in (C.FEUILLE_REMARKETING, C.FEUILLE_REPOSSESSION) if f not in noms]
        if manquantes:
            raise ValueError(f"Feuille(s) absente(s) : {', '.join(manquantes)}")
        remk = W.lire_feuille(chemin, C.FEUILLE_REMARKETING)
        absentes = [
            c for c in C.COLONNES_REQUISES_REMARKETING if W.trouver_colonne(remk, c) is None
        ]
        if absentes:
            raise ValueError(f"Colonnes absentes dans Remarketing : {', '.join(absentes)}")
    except Exception:
        raise


def generer_rapports(
    chemin_remarketing: str,
    date_arrete: date | None,
    chemin_portefeuille: str | None = None,
    taux_change: float | None = C.TAUX_CHANGE_DEFAUT,
) -> dict[str, pd.DataFrame]:
    """Generer rapports."""
    try:
        legende = W.lire_code_couleur(chemin_remarketing)
        fsa = W.lire_fsa(chemin_remarketing)
        df_brut = W.lire_feuille(chemin_remarketing, C.FEUILLE_REMARKETING, legende)
        note_auto: str | None = None
        if date_arrete is None:
            # Le rapport porte sur le fichier fourni : le mois de traitement
            # est détecté depuis les données (aucune date à deviner).
            detecte = R1.detecter_date_arrete(df_brut)
            if detecte is not None:
                date_arrete = detecte
                note_auto = (
                    "diag: mois de traitement détecté depuis les données : "
                    f"{detecte.isoformat()}"
                )
            else:
                date_arrete = (
                    pd.Timestamp.today().normalize() + pd.offsets.MonthEnd(0)
                ).date()
                note_auto = (
                    "diag: aucune date exploitable dans les données, "
                    f"mois de traitement = {date_arrete.isoformat()}"
                )
        remk = R1.preparer_remarketing(df_brut, date_arrete, fsa)
        repo = None
        if C.FEUILLE_REPOSSESSION in W.feuilles(chemin_remarketing):
            repo = R1.preparer_repossession(
                W.lire_feuille(chemin_remarketing, C.FEUILLE_REPOSSESSION, legende), date_arrete
            )

        tables = R1.tables_rapport_1(remk, repo)
        exceptions = remk.exceptions.copy()
        if note_auto:
            exceptions = pd.concat(
                [
                    exceptions,
                    pd.DataFrame(
                        [
                            {
                                "ligne": "",
                                "contrat": "",
                                "vin": "",
                                "motif": note_auto,
                                "valeur": "",
                            }
                        ]
                    ),
                ],
                ignore_index=True,
            )

        comptes = None
        if chemin_portefeuille:
            pf, exc_pf = PF.preparer_portefeuille(PF.charger_portefeuille(chemin_portefeuille))
            tables.update(PF.tables_rapport_3(pf, date_arrete))
            comptes = tables["R3 Comptes a echeance"]["Accounts Expiring"].drop(
                "Total", errors="ignore"
            )
            if not exc_pf.empty:
                exc_pf.insert(0, "source", "Portefeuille")
                exceptions = pd.concat([exceptions, exc_pf], ignore_index=True)
        tables.update(ERA.rapport_era(remk, comptes, taux_change))
        tables["Exceptions"] = exceptions
        tables["Resume"] = resume(tables, date_arrete, chemin_portefeuille is not None, taux_change)
        return tables
    except Exception:
        raise


def resume(tables: dict, date_arrete: date, portefeuille: bool, taux: float | None) -> pd.DataFrame:
    """Resume."""
    try:
        c, m = tables["R1 Canaux"], tables["R1 Mouvements"]
        fin = pd.Timestamp(date_arrete) + pd.offsets.MonthEnd(0)
        debut = fin - pd.offsets.MonthBegin(1)
        ventes_mois = int(c.loc["Total", "Total (mois)"])
        retours_mois = int(m.loc["Returns in Period", "TCM"])
        alerte = (
            "OK"
            if (ventes_mois or retours_mois)
            else "AUCUNE vente ni retour dans la fenêtre : vérifier la date d'arrêté"
        )
        lignes = [
            ("Date d'arrêté", str(date_arrete)),
            ("Fenêtre du mois", f"{debut.date()} -> {fin.date()}"),
            ("Contrôle fenêtre", alerte),
            (
                "Ventes du mois / YTD",
                f"{int(c.loc['Total', 'Total (mois)'])} / {int(c.loc['Total', 'YTD'])}",
            ),
            ("Retours du mois", int(m.loc["Returns in Period", "TCM"])),
            ("Stock fin de mois (TCM)", int(m.loc["Inventory End of Period", "TCM"])),
            ("Contrôle mouvements", m.loc["Inventory End of Period", "contrôle"]),
            ("Exceptions", int(len(tables["Exceptions"]))),
            (
                "ERA Accounts Expiring",
                "Portefeuille" if portefeuille else "approximation DateMaturite (Remarketing)",
            ),
            ("ERA feuille USD", "oui" if taux else "non (taux de change non fourni)"),
        ]
        return pd.DataFrame(lignes, columns=["indicateur", "valeur"]).set_index("indicateur")
    except Exception:
        raise


# ---- Validation contre le rapport de juin 2026 -------------------------------
CIBLES_JUIN_2026 = {
    ("R1 Canaux", "Franchised Dealers", "Total (mois)"): 44,
    ("R1 Canaux", "Franchised Dealers", "YTD"): 175,
    ("R1 Canaux", "Physical Auctions", "Total (mois)"): 92,
    ("R1 Canaux", "Physical Auctions", "YTD"): 422,
    ("R1 Canaux", "Total", "Total (mois)"): 136,
    ("R1 Canaux", "Total", "YTD"): 597,
    ("R1 Mouvements", "Inventory Prior Period", "TCM"): 295,
    ("R1 Mouvements", "Returns in Period", "TCM"): 70,
    ("R1 Mouvements", "Sold in Period", "TCM"): 123,
    ("R1 Mouvements", "Inventory End of Period", "TCM"): 242,
    ("R1 Ageing", "TCM", "0-30 Days"): 67,
    ("R1 Ageing", "TCM", "31-60 Days"): 42,
    ("R1 Ageing", "TCM", "61-90 Days"): 36,
    ("R1 Ageing", "TCM", "91-120 Days"): 26,
    ("R1 Ageing", "TCM", "121-150 Days"): 18,
    ("R1 Ageing", "TCM", "151-180 Days"): 10,
    ("R1 Ageing", "TCM", "181-360 Days"): 40,
    ("R1 Ageing", "TCM", "360+ Days"): 3,
    ("R1 Ageing", "TCM", "Total units"): 242,
    ("R1 Ageing", "TCM", "Avg Age"): 94,
    ("R1 Canaux", "Franchised Dealers", "Performance vs Market Value (%)"): 0.87,
    ("R1 Canaux", "Physical Auctions", "Performance vs Market Value (%)"): 0.82,
}


def valider(tables: dict[str, pd.DataFrame], cibles: dict = CIBLES_JUIN_2026) -> pd.DataFrame:
    """Valider."""
    try:
        lignes = []
        for (tab, ligne, col), attendu in cibles.items():
            try:
                obtenu = tables[tab].loc[ligne, col]
            except KeyError:
                obtenu = np.nan
            tol = 0.005 if col.startswith("Performance") else 0.5
            lignes.append(
                {
                    "tableau": tab,
                    "ligne": ligne,
                    "colonne": col,
                    "attendu": attendu,
                    "obtenu": obtenu,
                    "ecart": (obtenu - attendu) if pd.notna(obtenu) else np.nan,
                    "ok": bool(pd.notna(obtenu) and abs(obtenu - attendu) < tol),
                }
            )
        return pd.DataFrame(lignes)
    except Exception:
        raise


def ecrire_classeur(tables: dict[str, pd.DataFrame], chemin_sortie: str) -> None:
    """Ecrire classeur."""
    try:
        with pd.ExcelWriter(chemin_sortie, engine="openpyxl") as w:
            for nom, t in tables.items():
                t.to_excel(w, sheet_name=nom[:31], index=True)
    except Exception:
        raise
