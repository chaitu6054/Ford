"""Trigger-only production processing DAG for one exact GCS object generation."""
from __future__ import annotations

import logging
import sys
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = PROJECT_ROOT / "include"
if str(INCLUDE_ROOT) not in sys.path:
    sys.path.insert(0, str(INCLUDE_ROOT))

from remarketing.config import load_config  # noqa: E402
from remarketing.errors import (  # noqa: E402
    ConfigurationError,
    InputDiscoveryError,
    ProcessingError,
    RemarketingError,
)
from remarketing.models import GCSObjectIdentity  # noqa: E402
from remarketing.notify import LoggingNotifier, SmtpNotifier  # noqa: E402
from remarketing.pipeline import process_gcs_object  # noqa: E402
from remarketing.storage import GCSStorage  # noqa: E402

try:
    from airflow import DAG  # noqa: E402
except ImportError:  # local unit tests without Airflow installed
    DAG = None
    PythonOperator = None
else:
    try:  # Airflow 3.x (Astro Runtime 3.x)
        from airflow.providers.standard.operators.python import PythonOperator  # noqa: E402
    except ImportError:  # Airflow 2.x
        from airflow.operators.python import PythonOperator  # noqa: E402

LOGGER = logging.getLogger(__name__)


def resolve_processing_request(dag_run_conf: Mapping[str, object]) -> dict[str, object]:
    """Validate and normalize exact-object metadata supplied by the watcher DAG."""
    try:
        bucket_name = str(dag_run_conf.get("bucket_name", "")).strip()
        object_name = str(dag_run_conf.get("object_name", "")).strip()
        generation = dag_run_conf.get("generation")
        detected_at = str(dag_run_conf.get("detection_timestamp", "")).strip()
        size = int(dag_run_conf.get("size", 0) or 0)
        if not bucket_name or not object_name or generation is None or not detected_at:
            raise ConfigurationError(
                "Processing trigger requires bucket_name, object_name, generation, "
                "and detection_timestamp"
            )
        portefeuille_object = str(dag_run_conf.get("portefeuille_object", "")).strip()
        portefeuille_generation = dag_run_conf.get("portefeuille_generation")
        portefeuille_size = int(dag_run_conf.get("portefeuille_size", 0) or 0)
        taux_raw = dag_run_conf.get("taux_eur_usd")
        taux_eur_usd = float(taux_raw) if taux_raw not in (None, "") else None
        request: dict[str, object] = {
            "bucket_name": bucket_name,
            "object_name": object_name,
            "generation": int(generation),
            "size": size,
            "detection_timestamp": detected_at,
            "taux_eur_usd": taux_eur_usd,
        }
        if portefeuille_object:
            if portefeuille_generation is None:
                raise ConfigurationError(
                    "portefeuille_object requires portefeuille_generation"
                )
            request["portefeuille_object"] = portefeuille_object
            request["portefeuille_generation"] = int(portefeuille_generation)
            request["portefeuille_size"] = portefeuille_size
        return request
    except RemarketingError:
        raise
    except Exception as exc:
        raise ConfigurationError("Invalid processing DAG trigger configuration") from exc


def discover_processing_request() -> dict[str, object]:
    """Build the request from the configured input bucket (manual trigger, no conf).

    Mirrors what the watcher DAG would have passed: exactly one direct-child XLSX
    under the configured input prefix, with its exact generation.
    """
    try:
        config = load_config(require_bucket=True)
        storage = GCSStorage(str(config.bucket_name))
        candidates = storage.list_input_candidates(config.input_prefix)
        if not candidates:
            raise InputDiscoveryError(
                f"No XLSX found under gs://{config.bucket_name}/{config.input_prefix}"
            )
        if len(candidates) > 1:
            raise InputDiscoveryError(
                f"Expected exactly one XLSX under {config.input_prefix}, "
                f"found {len(candidates)}"
            )
        item = candidates[0]
        return resolve_processing_request(
            {
                "bucket_name": item.bucket_name,
                "object_name": item.object_name,
                "generation": item.generation,
                "size": item.size,
                "detection_timestamp": datetime.now(UTC).isoformat(),
            }
        )
    except RemarketingError:
        raise
    except Exception as exc:
        raise InputDiscoveryError("Unable to discover input for manual processing run") from exc


def process_remarketing_workbook(request: Mapping[str, object]) -> dict[str, object]:
    """Run production processing for the exact object generation in the request."""
    try:
        config = load_config(
            overrides={"bucket_name": str(request["bucket_name"])},
            require_bucket=True,
        )
        source = GCSObjectIdentity(
            bucket_name=str(config.bucket_name),
            object_name=str(request["object_name"]),
            generation=int(request["generation"]),
            size=int(request.get("size", 0) or 0),
        )
        portefeuille_source = None
        if request.get("portefeuille_object"):
            portefeuille_source = GCSObjectIdentity(
                bucket_name=str(config.bucket_name),
                object_name=str(request["portefeuille_object"]),
                generation=int(request["portefeuille_generation"]),
                size=int(request.get("portefeuille_size", 0) or 0),
            )
        taux_raw = request.get("taux_eur_usd")
        taux_eur_usd = float(taux_raw) if taux_raw is not None else None
        detected_at = datetime.fromisoformat(
            str(request["detection_timestamp"]).replace("Z", "+00:00")
        )
        return process_gcs_object(
            config=config,
            source=source,
            processing_date=detected_at.date(),
            portefeuille_source=portefeuille_source,
            taux_eur_usd=taux_eur_usd,
        ).to_dict()
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Airflow remarketing processing task failed") from exc


def _smtp_send(to: list[str], subject: str, html: str, from_email: str) -> None:
    """Airflow SMTP provider transport (kept in the DAG layer, not in the shared package)."""
    try:
        from airflow.providers.smtp.hooks.smtp import SmtpHook

        config = load_config(require_bucket=False)
        with SmtpHook(smtp_conn_id=config.smtp_conn_id) as smtp:
            smtp.send_email_smtp(to=to, subject=subject, html_content=html, from_email=from_email)
    except Exception as exc:
        raise ProcessingError("SMTP send failed") from exc


def _month_of(payload: Mapping[str, object]) -> str:
    try:
        return str(payload.get("processing_date") or "")[:7] or "?"
    except Exception as exc:
        raise ProcessingError("Unable to derive month from processing result") from exc


def notify_failure(context: Mapping[str, object]) -> None:
    """DAG-level on_failure_callback: FAILED e-mail to ops + FBS contacts."""
    try:
        config = load_config(require_bucket=False)
        task = context.get("task_instance")
        dag_run = context.get("dag_run")
        conf = {} if dag_run is None else (getattr(dag_run, "conf", None) or {})
        month = str(conf.get("month") or datetime.now(UTC).strftime("%Y-%m"))
        SmtpNotifier(config, _smtp_send).notify(
            "FAILED",
            f"Remarketing processing failed in task {getattr(task, 'task_id', '?')}",
            {
                "month": month,
                "dag": getattr(task, "dag_id", "remarketing_processing_dag"),
                "task": getattr(task, "task_id", "?"),
                "object": conf.get("object_name"),
                "error": str(context.get("exception")),
                "log": getattr(task, "log_url", None),
            },
        )
    except Exception:  # never mask the original task failure
        LOGGER.exception("Failure notification could not be sent")


def log_processing_result(result: Mapping[str, object]) -> None:
    """Log the processing result and send the SUCCESS / DUPLICATE e-mail."""
    try:
        payload = dict(result)
        LOGGER.info("Remarketing processing result: %s", payload)
        config = load_config(require_bucket=False)
        try:
            notifier = SmtpNotifier(config, _smtp_send)
            notifier.notify(
                "SUCCESS",
                f"Remarketing processing finished with status {payload.get('status')}",
                {
                    "month": _month_of(payload),
                    "status": payload.get("status"),
                    "source_file": payload.get("source_file"),
                    "report": payload.get("report"),
                    "reconciliation": payload.get("reconciliation"),
                    "business_reconciliation": payload.get("business_reconciliation"),
                    "visual_fidelity": payload.get("visual_fidelity"),
                    "france_remarketing_report": payload.get("france_remarketing_report"),
                    "france_era_report": payload.get("france_era_report"),
                    "france_portefeuille_report": payload.get("france_portefeuille_report"),
                    "archived_input": payload.get("archived_input"),
                    "manifest": payload.get("manifest"),
                },
            )
        except Exception:  # e-mail problems must not fail a successful run
            LOGGER.exception("Success notification could not be sent; falling back to log")
            LoggingNotifier().notify("SUCCESS", "Remarketing processing finished", payload)
        if payload.get("france_reports_skipped"):
            LOGGER.info("France report stage was skipped for this run.")
        else:
            LOGGER.info(
                "France reports: era=%s portefeuille=%s",
                payload.get("france_era_report"),
                payload.get("france_portefeuille_report"),
            )
    except Exception as exc:
        raise ProcessingError("Unable to log processing result") from exc


def _get_current_context() -> Mapping[str, object]:
    try:
        try:  # Airflow 3.x
            from airflow.sdk import get_current_context
        except ImportError:  # Airflow 2.x
            from airflow.operators.python import get_current_context
        return get_current_context()
    except Exception as exc:
        raise ConfigurationError("Unable to read the Airflow task context") from exc


def _resolve_from_context() -> dict[str, object]:
    """Use the watcher's conf when present; otherwise discover the input (manual run)."""
    try:
        context = _get_current_context()
        dag_run = context.get("dag_run")
        conf = {} if dag_run is None else (dag_run.conf or {})
        if conf.get("bucket_name") and conf.get("object_name"):
            return resolve_processing_request(conf)
        LOGGER.info("No trigger conf supplied; discovering input from the configured bucket.")
        return discover_processing_request()
    except RemarketingError:
        raise
    except Exception as exc:
        raise ConfigurationError(
            "Unable to resolve processing request from Airflow context"
        ) from exc


if DAG is not None:
    try:
        with DAG(
            dag_id="remarketing_processing_dag",
            schedule=None,
            catchup=False,
            max_active_runs=1,
            start_date=datetime(2026, 1, 1, tzinfo=UTC),
            render_template_as_native_obj=True,
            tags=["remarketing", "gcs", "processing"],
            on_failure_callback=notify_failure,
        ) as dag:
            resolve_task = PythonOperator(
                task_id="resolve_processing_request",
                python_callable=_resolve_from_context,
            )
            process_task = PythonOperator(
                task_id="process_remarketing_workbook",
                python_callable=process_remarketing_workbook,
                op_args=[resolve_task.output],
            )
            log_task = PythonOperator(
                task_id="log_processing_result",
                python_callable=log_processing_result,
                op_args=[process_task.output],
            )
            resolve_task >> process_task >> log_task
    except Exception as exc:
        exc.add_note("remarketing_processing_dag definition failed")
        raise
else:
    dag = None
