"""Scheduled GCS watcher DAG for analyst-refreshed remarketing workbooks.

Runs once a day (workbook.yml watcher.schedule, default 08:00 Europe/Paris). It short-circuits
when the input prefix is empty or when the current month already has a SUCCESS manifest, so
after the monthly run it effectively sleeps until the next month.
"""
from __future__ import annotations

import sys
from datetime import UTC, date, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = PROJECT_ROOT / "include"
if str(INCLUDE_ROOT) not in sys.path:
    sys.path.insert(0, str(INCLUDE_ROOT))

from remarketing.config import load_config  # noqa: E402
from remarketing.errors import InputDiscoveryError, RemarketingError  # noqa: E402
from remarketing.storage import GCSStorage  # noqa: E402

try:
    import pendulum  # noqa: E402
    from airflow import DAG  # noqa: E402
except ImportError:  # local unit tests without Airflow installed
    DAG = None
    PythonOperator = None
    ShortCircuitOperator = None
    TriggerDagRunOperator = None
else:
    try:  # Airflow 3.x (Astro Runtime 3.x)
        from airflow.providers.standard.operators.python import (  # noqa: E402
            PythonOperator,
            ShortCircuitOperator,
        )
        from airflow.providers.standard.operators.trigger_dagrun import (  # noqa: E402
            TriggerDagRunOperator,
        )
    except ImportError:  # Airflow 2.x
        from airflow.operators.python import PythonOperator, ShortCircuitOperator  # noqa: E402
        from airflow.operators.trigger_dagrun import TriggerDagRunOperator  # noqa: E402


def list_input_objects() -> list[dict[str, object]]:
    """List direct-child XLSX candidates without mutating GCS state."""
    try:
        config = load_config(require_bucket=True)
        storage = GCSStorage(str(config.bucket_name))
        detected_at = datetime.now(UTC).isoformat()
        return [
            {
                "bucket_name": item.bucket_name,
                "object_name": item.object_name,
                "generation": item.generation,
                "size": item.size,
                "detection_timestamp": detected_at,
            }
            for item in storage.list_input_candidates(config.input_prefix)
        ]
    except RemarketingError:
        raise
    except Exception as exc:
        raise InputDiscoveryError("Unable to list remarketing input objects") from exc


def month_already_processed(today: date | None = None) -> bool:
    """True when a SUCCESS manifest already exists for the current calendar month.

    Demo feedback 18/09: after the month has been processed the watcher goes back to
    sleep until next month. Disable with ``watcher.once_per_month: false`` (workbook.yml).
    """
    try:
        config = load_config(require_bucket=True)
        if not config.watcher_once_per_month:
            return False
        output = GCSStorage(str(config.output_bucket_name or config.bucket_name))
        current = (today or datetime.now(UTC).date()).strftime("%Y-%m")
        for manifest in output.list_success_manifests(config.output_prefix):
            if str(manifest.processing_date)[:7] == current:
                return True
        return False
    except RemarketingError:
        raise
    except Exception as exc:
        raise InputDiscoveryError("Unable to check the monthly processing marker") from exc


def validate_candidate_count(
    candidates: list[dict[str, object]],
) -> bool | dict[str, object]:
    """Short-circuit on no input, on an already-processed month, and reject >1 candidate."""
    try:
        if not candidates:
            return False
        if month_already_processed():
            return False
        if len(candidates) > 1:
            raise InputDiscoveryError(
                f"Expected at most one XLSX in input/, found {len(candidates)}"
            )
        return candidates[0]
    except RemarketingError:
        raise
    except Exception as exc:
        raise InputDiscoveryError("Unable to validate input candidate count") from exc


if DAG is not None:
    try:
        DAG_CONFIG = load_config(require_bucket=False)
        with DAG(
            dag_id="remarketing_file_watcher_dag",
            schedule=DAG_CONFIG.watcher_schedule,
            catchup=False,
            max_active_runs=1,
            start_date=pendulum.datetime(2026, 1, 1, tz="Europe/Paris"),
            render_template_as_native_obj=True,
            tags=["remarketing", "gcs", "watcher"],
        ) as dag:
            list_task = PythonOperator(
                task_id="list_input_objects",
                python_callable=list_input_objects,
            )
            validate_task = ShortCircuitOperator(
                task_id="validate_candidate_count",
                python_callable=validate_candidate_count,
                op_args=[list_task.output],
            )
            trigger_task = TriggerDagRunOperator(
                task_id="trigger_processing_dag",
                trigger_dag_id="remarketing_processing_dag",
                conf=validate_task.output,
                wait_for_completion=False,
            )
            list_task >> validate_task >> trigger_task
    except Exception as exc:
        exc.add_note("remarketing_file_watcher_dag definition failed")
        raise
else:
    dag = None
