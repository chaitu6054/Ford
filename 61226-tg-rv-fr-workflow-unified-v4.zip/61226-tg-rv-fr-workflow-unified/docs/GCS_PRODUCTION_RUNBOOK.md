# GCS production runbook — France Remarketing / ERA / Portefeuille

## Buckets
- Input: `prj-ml-cap-rv-uk-d-tg-rv-fr-inv-input` — manual uploads only (`input/<file>.xlsx`).
- Output: `prj-ml-cap-rv-uk-d-tg-rv-fr-inv-output` — every uploaded file is moved here for audit
  (`output/<date>/input/<file>`), plus all generated files: the report, `reconciliation.xlsx`,
  `france_era_<month>.xlsx`, `france_portefeuille_<month>.xlsx` and `run_summary_<date>.json`.

## Daily watcher (`remarketing_file_watcher_dag`)
- Runs once a day at 08:00 Europe/Paris (`watcher.schedule` in `astro/config/workbook.yml`).
- Short-circuits when the input prefix is empty, or when a SUCCESS manifest already exists for
  the current month (`watcher.once_per_month: true`). After the monthly run it therefore sleeps
  until the next month. To restate a month on purpose, trigger `remarketing_processing_dag`
  manually with the object conf, or set `once_per_month: false`.
- Rejects more than one XLSX in `input/`.

## Processing (`remarketing_processing_dag`)
1. Download the exact object generation; SHA-256 of the bytes.
2. Duplicate bytes already processed → `DUPLICATE_SKIPPED`, input deleted.
3. Same processing date with different bytes → rejected (`AlreadyProcessedError`).
4. Input **moved** (copy, verify generation, delete) to the output bucket.
5. Main report: the final workbook is built from the uploaded XLSX OOXML package;
   openpyxl is not used to serialize the final client workbook. Six visible analyst-facing sheets
   (Pivot Pierre, Feuil2, Pivot Soraya, VENTES, Feuil3, KPIs); Remarketing is veryHidden.
   Cached values only: external links are never refreshed by the application.
6. Business reconciliation and visual fidelity must both PASS before anything is published.
7. France stage: ERA (R2) and Portefeuille (R3) workbooks from `remarketing.france`.
8. `run_summary_<date>.json` written last (success marker used by the watcher).

## Notifications
- SUCCESS / DUPLICATE: `EURVSMTP@FORD.COM` → `EURV_FR_OPERATIONS_DEV@FORD.COM` (dev) or
  `EURV_FR_OPERATIONS_PROD@FORD.COM` (prod), subject
  `France Remarketing workbook reconciliation <month> - SUCCESS`.
- FAILED: same list plus `notifications.failure_cc` (FBS contacts), subject `... - FAILED`.
- Environment detection: `REMARKETING_ENV=dev|prod`, else `astrodev` in the Airflow base URL → dev.
- Airflow connections: `google_cloud_default`, `smtp_default`.

## Optional inputs (same `input/` prefix)
- `portefeuille_<YYYY-MM>.xlsx` → Accounts Expiring per model line (otherwise approximated from DateMaturite).
- `taux_<YYYY-MM>.xlsx` (cell A1 = EUR→USD) → ERA OUTPUT (USD) sheet.

## Local run
`python local/run_local.py --input <file>.xlsx --processing-date 2026-06-30 [--portefeuille p.xlsx] [--taux 1.08]`
