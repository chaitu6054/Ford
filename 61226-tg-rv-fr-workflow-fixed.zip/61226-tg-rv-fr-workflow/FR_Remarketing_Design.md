# France Remarketing Report — Design

## Scope (phase 1)
Input `REMARKETING_ET_REPOSSESSION_*.xlsx` uploaded as `remarketing_YYYY-MM.xlsx`.
Output `MM YYYY France Remarketing Report.xlsx` with Synthèse, Remarketing,
Repossession, Exceptions (and Validation for months with targets).
Out of scope: agency file (O&R, phase 2), ERA/TCM Ford Source (phase 3).

## Business rules (Soraya 9/15)
- Restituable: exclude NON only.
- Channels: Dealer, SICA → Franchised Dealers; VP Auto, BCA, Autorola, Concilian →
  Physical Auctions; blank Vendeur = not sold.
- Sold = Statut "Solde" with sale date in month (date revente, else Mois/Année de vente).
- Returns = Date de retour in month.
- Ageing = month-end − Date de retour for unsold; buckets 0-30 … 181-360, 360+;
  variants all / excl. sold-awaiting-proceeds (PIVOT tab, pending) / excl. also statut L.
- Performance = mean(Valeur revente TTC / Cote ARGUS prof) by channel.
- 2% fees = 0.02 × VFMG; Km excédentaires = Kilométrage − COUVERT × quotos;
  Perte/Profit TCM = fees + Montant à facturer; O&R = Balance US − Valeur revente.
- FSA = VIN in FSA-UPDATE tab; legal hold = Statut L or orange fill (code couleur legend).

## Data quality (flag, never fix)
Header whitespace/case/accent-insensitive; comma decimals; currency / percent strings;
Excel serials; dates < 1950 nulled; #DIV/0! / blank Argus / duplicates → exceptions csv.
External links are never followed (`data_only=True`, cached values).

## Validation targets — June 2026
Channels FD 44 / PA 92 / total 136 (YTD 175 / 422 / 597; perf 87% / 82%).
Movements TCM 295 + 70 − 123 = 242; O&R 4 + 22 − 13 = 13.
Ageing TCM 67/42/36/26/18/10/40/3 = 242, avg 94; O&R 13 in 0-30, avg 11.
Note: channel total 136 includes 13 O&R from the agency file → expect ~123 in phase 1.

## Error model
`include/exceptions.py`: FR-001 marker check, FR-002 input lookup, FR-003 missing input,
FR-004 GCS, FR-010 validation, FR-020 calculation, FR-030 write, FR-040 notification,
FR-999 unexpected. Every task pushes `{error_code, error_message}` to XCom key `error`;
`notify` collects them and emails ops (+ FBS contacts in CC on failure).
