"""Five-minute GCS watcher DAG for analyst-refreshed remarketing workbooks."""
from __future__ import annotations

import sys
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = PROJECT_ROOT / "include"
if str(INCLUDE_ROOT) not in sys.path:
    sys.path.insert(0, str(INCLUDE_ROOT))

from remarketing.config import load_config  # noqa: E402
from remarketing.errors import InputDiscoveryError, RemarketingError  # noqa: E402
from remarketing.storage import GCSStorage  # noqa: E402

try:
    from airflow import DAG  # noqa: E402
    from airflow.operators.python import PythonOperator, ShortCircuitOperator  # noqa: E402
    from airflow.operators.trigger_dagrun import TriggerDagRunOperator  # noqa: E402
except ImportError:
    DAG = None
    PythonOperator = None
    ShortCircuitOperator = None
    TriggerDagRunOperator = None


def list_input_objects() -> list[dict[str, object]]:
    """List direct-child XLSX candidates without mutating GCS state."""
    try:
        config = load_config(require_bucket=True)
        storage = GCSStorage(str(config.bucket_name))
        detected_at = datetime.now(UTC).isoformat()
        return [
            {
                "bucket_name": item.bucket_name,
                "object_name": item.object_name,
                "generation": item.generation,
                "size": item.size,
                "detection_timestamp": detected_at,
            }
            for item in storage.list_input_candidates(config.input_prefix)
        ]
    except Exception as exc:
        if isinstance(exc, RemarketingError):
            raise
        raise InputDiscoveryError("Unable to list remarketing input objects") from exc


def validate_candidate_count(
    candidates: list[dict[str, object]],
) -> bool | dict[str, object]:
    """Short-circuit on no input and reject more than one candidate."""
    try:
        if not candidates:
            return False
        if len(candidates) > 1:
            raise InputDiscoveryError(
                f"Expected at most one XLSX in input/, found {len(candidates)}"
            )
        return candidates[0]
    except Exception as exc:
        if isinstance(exc, RemarketingError):
            raise
        raise InputDiscoveryError("Unable to validate input candidate count") from exc


if DAG is not None:
    try:
        DAG_CONFIG = load_config(require_bucket=False)
        with DAG(
            dag_id="remarketing_file_watcher_dag",
            schedule=DAG_CONFIG.watcher_schedule,
            catchup=False,
            max_active_runs=1,
            start_date=datetime(2026, 1, 1, tzinfo=UTC),
            render_template_as_native_obj=True,
            tags=["remarketing", "gcs", "watcher"],
        ) as dag:
            list_task = PythonOperator(
                task_id="list_input_objects",
                python_callable=list_input_objects,
            )
            validate_task = ShortCircuitOperator(
                task_id="validate_candidate_count",
                python_callable=validate_candidate_count,
                op_args=[list_task.output],
            )
            trigger_task = TriggerDagRunOperator(
                task_id="trigger_processing_dag",
                trigger_dag_id="remarketing_processing_dag",
                conf=validate_task.output,
                wait_for_completion=False,
            )
            list_task >> validate_task >> trigger_task
    except Exception as exc:
        exc.add_note("operation failed")
        raise
else:
    dag = None
