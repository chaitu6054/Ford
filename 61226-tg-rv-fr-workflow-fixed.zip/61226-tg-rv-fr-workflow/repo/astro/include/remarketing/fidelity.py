"""OOXML-preserving construction of the final analyst-facing workbook."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile
from defusedxml.ElementTree import fromstring as safe_fromstring

from .errors import FidelityBuildError
from .models import FidelityBuildResult

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
DOC_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
REL_ID_ATTR = f"{{{DOC_REL_NS}}}id"

ET.register_namespace("", MAIN_NS)
ET.register_namespace("r", DOC_REL_NS)


@dataclass(frozen=True, slots=True)
class _WorkbookSheetRef:
    name: str
    sheet_id: str
    relationship_id: str
    state: str
    original_index: int


def _parse_workbook_sheets(workbook_xml: bytes) -> tuple[_WorkbookSheetRef, ...]:
    try:
        root = safe_fromstring(workbook_xml)
        parent = root.find(f"{{{MAIN_NS}}}sheets")
        if parent is None:
            raise FidelityBuildError("Workbook does not contain a sheet collection")
        values: list[_WorkbookSheetRef] = []
        for index, node in enumerate(parent):
            values.append(
                _WorkbookSheetRef(
                    name=node.attrib.get("name", ""),
                    sheet_id=node.attrib.get("sheetId", ""),
                    relationship_id=node.attrib.get(REL_ID_ATTR, ""),
                    state=node.attrib.get("state", "visible"),
                    original_index=index,
                )
            )
        return tuple(values)
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError("Unable to parse workbook sheet collection") from exc


def _select_retained_sheets(
    sheets: tuple[_WorkbookSheetRef, ...],
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
) -> tuple[_WorkbookSheetRef, ...]:
    try:
        requested = set(visible_sheets) | set(technical_sheets)
        available = {sheet.name for sheet in sheets}
        missing = sorted(requested - available)
        if missing:
            raise FidelityBuildError(
                "Required fidelity sheets are missing: " + ", ".join(missing)
            )
        return tuple(sheet for sheet in sheets if sheet.name in requested)
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError("Unable to select retained workbook sheets") from exc


def _referenced_sheet_names(expression: str, sheets: tuple[_WorkbookSheetRef, ...]) -> set[str]:
    try:
        found: set[str] = set()
        for sheet in sheets:
            quoted = "'" + sheet.name.replace("'", "''") + "'!"
            unquoted = sheet.name + "!"
            if quoted in expression or unquoted in expression:
                found.add(sheet.name)
        return found
    except Exception as exc:
        raise FidelityBuildError("Unable to inspect defined-name sheet references") from exc


def _rewrite_defined_names(
    root: ET.Element,
    retained: tuple[_WorkbookSheetRef, ...],
    original_sheets: tuple[_WorkbookSheetRef, ...],
) -> None:
    try:
        parent = root.find(f"{{{MAIN_NS}}}definedNames")
        if parent is None:
            return
        retained_names = {sheet.name for sheet in retained}
        new_index = {sheet.original_index: index for index, sheet in enumerate(retained)}
        for node in list(parent):
            local_value = node.attrib.get("localSheetId")
            if local_value is not None:
                old_index = int(local_value)
                if old_index not in new_index:
                    parent.remove(node)
                    continue
                node.set("localSheetId", str(new_index[old_index]))
            references = _referenced_sheet_names(node.text or "", original_sheets)
            if references and not references.issubset(retained_names):
                parent.remove(node)
        if len(parent) == 0:
            root.remove(parent)
    except Exception as exc:
        raise FidelityBuildError("Unable to rewrite workbook defined names") from exc


def _rewrite_workbook_view(root: ET.Element, retained: tuple[_WorkbookSheetRef, ...]) -> None:
    try:
        visible_indexes = [
            index for index, sheet in enumerate(retained) if sheet.state == "visible"
        ]
        fallback = visible_indexes[0] if visible_indexes else 0
        views = root.find(f"{{{MAIN_NS}}}bookViews")
        if views is None:
            return
        for view in views:
            view.set("activeTab", str(fallback))
            view.set("firstSheet", str(fallback))
    except Exception as exc:
        raise FidelityBuildError("Unable to rewrite workbook view indexes") from exc


def _rewrite_sheet_collection(
    root: ET.Element,
    retained: tuple[_WorkbookSheetRef, ...],
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
) -> None:
    try:
        parent = root.find(f"{{{MAIN_NS}}}sheets")
        if parent is None:
            raise FidelityBuildError("Workbook sheet collection is missing")
        visible = set(visible_sheets)
        technical = set(technical_sheets)
        retained_names = {sheet.name for sheet in retained}
        for node in list(parent):
            name = node.attrib.get("name", "")
            if name not in retained_names:
                parent.remove(node)
                continue
            if name in technical:
                node.set("state", "veryHidden")
            elif name in visible:
                node.attrib.pop("state", None)
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError("Unable to rewrite workbook sheet collection") from exc


def _rewrite_workbook_xml(
    workbook_xml: bytes,
    retained: tuple[_WorkbookSheetRef, ...],
    original_sheets: tuple[_WorkbookSheetRef, ...],
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
) -> bytes:
    try:
        root = safe_fromstring(workbook_xml)
        _rewrite_sheet_collection(root, retained, visible_sheets, technical_sheets)
        _rewrite_defined_names(root, retained, original_sheets)
        _rewrite_workbook_view(root, retained)
        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError("Unable to serialize workbook control XML") from exc


def _rewrite_workbook_relationships(
    workbook_rels: bytes,
    retained_relationship_ids: frozenset[str],
) -> bytes:
    try:
        ET.register_namespace("", PKG_REL_NS)
        root = safe_fromstring(workbook_rels)
        for node in list(root):
            rel_type = node.attrib.get("Type", "")
            rel_id = node.attrib.get("Id", "")
            if rel_type.endswith("/worksheet") and rel_id not in retained_relationship_ids:
                root.remove(node)
            elif rel_type.endswith("/calcChain"):
                root.remove(node)
        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    except Exception as exc:
        raise FidelityBuildError("Unable to rewrite workbook relationships") from exc


def _rewrite_content_types_without_calc_chain(content_types_xml: bytes) -> bytes:
    try:
        ET.register_namespace("", CONTENT_NS)
        root = safe_fromstring(content_types_xml)
        for node in list(root):
            if node.attrib.get("PartName") == "/xl/calcChain.xml":
                root.remove(node)
        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    except Exception as exc:
        raise FidelityBuildError("Unable to rewrite package content types") from exc


def _transform_workbook_control_parts(
    source_parts: dict[str, bytes],
    *,
    sheets: tuple[_WorkbookSheetRef, ...],
    retained: tuple[_WorkbookSheetRef, ...],
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
    workbook_xml: bytes,
    workbook_rels: bytes,
) -> tuple[dict[str, bytes], frozenset[str]]:
    try:
        replacements = {
            "xl/workbook.xml": _rewrite_workbook_xml(
                workbook_xml,
                retained,
                sheets,
                visible_sheets,
                technical_sheets,
            ),
            "xl/_rels/workbook.xml.rels": _rewrite_workbook_relationships(
                workbook_rels,
                frozenset(sheet.relationship_id for sheet in retained),
            ),
        }
        removals: set[str] = set()
        if "xl/calcChain.xml" in source_parts:
            removals.add("xl/calcChain.xml")
            content_types = source_parts.get("[Content_Types].xml")
            if content_types is not None:
                replacements["[Content_Types].xml"] = (
                    _rewrite_content_types_without_calc_chain(content_types)
                )
        return replacements, frozenset(removals)
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError("Unable to transform workbook control parts") from exc


def _write_transformed_package(
    source_path: Path,
    output_path: Path,
    replacements: dict[str, bytes],
    removals: frozenset[str],
) -> None:
    try:
        with ZipFile(source_path, "r") as source_archive, ZipFile(
            output_path,
            "w",
            compression=ZIP_DEFLATED,
        ) as output_archive:
            for info in source_archive.infolist():
                if info.filename in removals:
                    continue
                payload = replacements.get(info.filename, source_archive.read(info.filename))
                output_archive.writestr(info, payload)
    except Exception as exc:
        raise FidelityBuildError(f"Unable to write fidelity workbook: {output_path}") from exc


def build_fidelity_workbook(
    source_path: Path | str,
    output_path: Path | str,
    *,
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
) -> FidelityBuildResult:
    """Create a client workbook by preserving source OOXML and trimming registration."""
    try:
        source = Path(source_path)
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(source, "r") as source_archive:
            source_parts = {
                name: source_archive.read(name) for name in source_archive.namelist()
            }
        workbook_xml = source_parts["xl/workbook.xml"]
        workbook_rels = source_parts["xl/_rels/workbook.xml.rels"]
        sheets = _parse_workbook_sheets(workbook_xml)
        retained = _select_retained_sheets(sheets, visible_sheets, technical_sheets)
        replacements, removals = _transform_workbook_control_parts(
            source_parts,
            sheets=sheets,
            retained=retained,
            visible_sheets=visible_sheets,
            technical_sheets=technical_sheets,
            workbook_xml=workbook_xml,
            workbook_rels=workbook_rels,
        )
        _write_transformed_package(source, output, replacements, removals)
        return FidelityBuildResult(
            path=output,
            retained_sheets=tuple(sheet.name for sheet in retained),
            removed_sheet_count=len(sheets) - len(retained),
        )
    except Exception as exc:
        if isinstance(exc, FidelityBuildError):
            raise
        raise FidelityBuildError(
            f"Unable to build fidelity workbook from {source_path}"
        ) from exc
