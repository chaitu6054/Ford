"""Notification abstractions. Production defaults to structured logging."""
from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any, Protocol

from .errors import NotificationError

LOGGER = logging.getLogger(__name__)


class Notifier(Protocol):
    """Notification interface used by orchestration without provider coupling."""

    def notify(self, event: str, message: str, context: Mapping[str, Any]) -> None:
        """Emit one structured processing notification."""
        try:
            ...
        except Exception as exc:
            exc.add_note("notify failed")
            raise


class LoggingNotifier:
    """Default notifier that emits structured events through Python logging."""

    def notify(self, event: str, message: str, context: Mapping[str, Any]) -> None:
        """Write one notification event to the configured application logger."""
        try:
            LOGGER.info(
                "remarketing_event=%s message=%s context=%s",
                event,
                message,
                dict(context),
            )
        except Exception as exc:
            raise NotificationError(f"Unable to emit notification {event}") from exc
