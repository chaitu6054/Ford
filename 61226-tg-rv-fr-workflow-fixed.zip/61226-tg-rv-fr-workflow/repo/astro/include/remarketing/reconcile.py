from __future__ import annotations


from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
import math
from pathlib import Path
import re

from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter, range_boundaries

from .calculate import AGEING_CELLS, BROKEN_REFERENCE_CELLS, PivotSpec, load_pivot_definitions
from .errors import ReconciliationError
from .models import (
    CellValue,
    ExcelError,
    ReconciliationSummary as PipelineReconciliationSummary,
    VisualFidelityResult,
)
from .workbook import OOXMLWorkbook

RECONCILIATION_HEADERS = (
    "Report Sheet",
    "Section ID",
    "Logical Row Key",
    "Logical Column Key",
    "Data Field",
    "Analyst Cell",
    "Generated Cell",
    "Analyst Value",
    "Generated Value",
    "Status",
    "Numeric Difference",
    "Category",
    "Explanation",
)

KPI_RECONCILIATION_CELLS = frozenset({
    "B1", "C2", "C3", "T4", "C6", "P4", "R4", "C10", "C19", "E19",
    *AGEING_CELLS.keys(),
    *BROKEN_REFERENCE_CELLS,
})


@dataclass(frozen=True, slots=True)
class ComparisonResult:
    """Result of comparing one analyst and generated workbook value."""

    status: str
    category: str
    numeric_difference: float | int | None
    explanation: str


@dataclass(frozen=True, slots=True)
class KeyedComparison:
    """Comparison result keyed by a logical report item identifier."""

    key: str
    analyst_value: CellValue
    generated_value: CellValue
    status: str
    category: str
    numeric_difference: float | int | None
    explanation: str


@dataclass(frozen=True, slots=True)
class ReconciliationRow:
    """One detailed reconciliation row written to the audit workbook."""

    report_sheet: str
    section_id: str
    logical_row_key: str
    logical_column_key: str
    data_field: str
    analyst_cell: str
    generated_cell: str
    analyst_value: CellValue
    generated_value: CellValue
    status: str
    numeric_difference: float | int | None
    category: str
    explanation: str


@dataclass(frozen=True, slots=True)
class ReconciliationSummary:
    """Aggregate reconciliation counts across all compared report cells."""

    total_rows: int
    status_counts: dict[str, int]
    category_counts: dict[str, int]
    sheet_counts: dict[str, int]

    @property
    def mismatch_count(self) -> int:
        """Return the number of unexplained reconciliation mismatches."""
        try:
            return self.status_counts.get("MISMATCH", 0)
        except Exception as exc:
            exc.add_note("mismatch_count failed")
            raise

    @property
    def has_mismatches(self) -> bool:
        """Return whether any reconciliation mismatch remains."""
        try:
            return self.mismatch_count > 0
        except Exception as exc:
            exc.add_note("has_mismatches failed")
            raise


def _is_number(value: CellValue) -> bool:
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    except Exception as exc:
        exc.add_note("_is_number failed")
        raise


def _display_precision(number_format: str | None) -> tuple[int, bool] | None:
    try:
        if not number_format or number_format == "General":
            return None
        first = number_format.split(";", 1)[0]
        # Ignore quoted literals while retaining the numeric mask itself.
        mask = re.sub(r'"[^"]*"', "", first)
        match = re.search(r"0(?:\.([0#]+))?", mask)
        if match is None:
            return None
        decimals = len(match.group(1) or "")
        return decimals, "%" in mask
    except Exception as exc:
        exc.add_note("_display_precision failed")
        raise


def compare_values(
    analyst: CellValue,
    generated: CellValue,
    analyst_number_format: str | None,
    *,
    known_source_error: bool = False,
) -> ComparisonResult:
    """Compare one analyst value with its generated counterpart."""
    try:
        if isinstance(analyst, ExcelError) or isinstance(generated, ExcelError):
            if (
                isinstance(analyst, ExcelError)
                and isinstance(generated, ExcelError)
                and analyst.code == generated.code
            ):
                if known_source_error:
                    return ComparisonResult(
                        "KNOWN_SOURCE_ERROR",
                        "SOURCE_FORMULA_BROKEN_PRESERVED",
                        None,
                        f"Preserved analyst source error {analyst.code}",
                    )
                return ComparisonResult(
                    "KNOWN_SOURCE_ERROR",
                    "UNSUPPORTED_SOURCE_ERROR",
                    None,
                    f"Analyst source error {analyst.code} is preserved",
                )
            return ComparisonResult(
                "MISMATCH",
                "UNSUPPORTED_SOURCE_ERROR",
                None,
                "Excel error differs: "
                f"analyst={_serializable(analyst)!r}, "
                f"generated={_serializable(generated)!r}",
            )

        if _is_number(analyst) and _is_number(generated):
            difference = generated - analyst
            if analyst == generated:
                return ComparisonResult(
                    "MATCH",
                    "EXACT",
                    difference,
                    "Numeric values match exactly",
                )
            if math.isclose(float(analyst), float(generated), rel_tol=1e-9, abs_tol=1e-9):
                return ComparisonResult(
                    "MATCH",
                    "NUMERIC_TOLERANCE",
                    difference,
                    "Numeric values match within internal tolerance",
                )
            precision = _display_precision(analyst_number_format)
            if precision is not None:
                decimals, percentage = precision
                scale = 100 if percentage else 1
                if round(float(analyst) * scale, decimals) == round(
                    float(generated) * scale, decimals
                ):
                    return ComparisonResult(
                        "MATCH",
                        "NUMERIC_TOLERANCE",
                        difference,
                        "Numeric values match at displayed precision "
                        f"({decimals} decimals{' percent' if percentage else ''})",
                    )
            return ComparisonResult(
                "MISMATCH",
                "VALUE_MISMATCH",
                difference,
                "Numeric values differ",
            )

        if analyst == generated and type(analyst) is type(generated):
            return ComparisonResult("MATCH", "EXACT", None, "Values match exactly")
        if analyst == generated:
            return ComparisonResult("MATCH", "EXACT", None, "Values are equivalent")
        if (
            analyst is not None
            and generated is not None
            and type(analyst) is not type(generated)
        ):
            return ComparisonResult(
                "MISMATCH",
                "TYPE_MISMATCH",
                None,
                "Value types differ: "
                f"analyst={type(analyst).__name__}, "
                f"generated={type(generated).__name__}",
            )
        return ComparisonResult("MISMATCH", "VALUE_MISMATCH", None, "Values differ")
    except Exception as exc:
        exc.add_note("compare_values failed")
        raise


def compare_keyed_values(
    analyst: Mapping[str, tuple[CellValue, str | None]],
    generated: Mapping[str, CellValue],
) -> list[KeyedComparison]:
    """Compare keyed analyst and generated value collections."""
    try:
        rows: list[KeyedComparison] = []
        all_keys = sorted(set(analyst) | set(generated))
        for key in all_keys:
            if key not in generated:
                value, _fmt = analyst[key]
                rows.append(KeyedComparison(
                    key, value, None, "MISMATCH", "MISSING_GENERATED_ITEM", None,
                    "Analyst item is missing from generated output",
                ))
                continue
            if key not in analyst:
                rows.append(KeyedComparison(
                    key, None, generated[key], "MISMATCH", "EXTRA_GENERATED_ITEM", None,
                    "Generated output contains an item absent from analyst output",
                ))
                continue
            value, fmt = analyst[key]
            comparison = compare_values(value, generated[key], fmt)
            rows.append(KeyedComparison(
                key, value, generated[key], comparison.status, comparison.category,
                comparison.numeric_difference, comparison.explanation,
            ))
        return rows
    except Exception as exc:
        exc.add_note("compare_keyed_values failed")
        raise


def _serializable(value: CellValue):
    try:
        return value.code if isinstance(value, ExcelError) else value
    except Exception as exc:
        exc.add_note("_serializable failed")
        raise


def summarize(rows: list[ReconciliationRow]) -> ReconciliationSummary:
    """Summarize detailed reconciliation rows into audit counts."""
    try:
        return ReconciliationSummary(
            total_rows=len(rows),
            status_counts=dict(Counter(row.status for row in rows)),
            category_counts=dict(Counter(row.category for row in rows)),
            sheet_counts=dict(Counter(row.report_sheet for row in rows)),
        )
    except Exception as exc:
        exc.add_note("summarize failed")
        raise


def write_reconciliation_workbook(
    rows: list[ReconciliationRow],
    output_path: Path | str,
) -> Path:
    """Write the detailed reconciliation workbook and summary sheet."""
    try:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        wb = Workbook()
        ws = wb.active
        ws.title = "Reconciliation"
        ws.append(RECONCILIATION_HEADERS)
        for row in rows:
            ws.append([
                row.report_sheet,
                row.section_id,
                row.logical_row_key,
                row.logical_column_key,
                row.data_field,
                row.analyst_cell,
                row.generated_cell,
                _serializable(row.analyst_value),
                _serializable(row.generated_value),
                row.status,
                row.numeric_difference,
                row.category,
                row.explanation,
            ])
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:M{max(ws.max_row, 1)}"
        widths = (20, 24, 20, 22, 24, 16, 16, 22, 22, 20, 18, 34, 56)
        for index, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(index)].width = width

        summary = summarize(rows)
        summary_ws = wb.create_sheet("Summary")
        summary_ws.append(["Group", "Value", "Count"])
        for name, count in sorted(summary.status_counts.items()):
            summary_ws.append(["Status", name, count])
        for name, count in sorted(summary.category_counts.items()):
            summary_ws.append(["Category", name, count])
        for name, count in sorted(summary.sheet_counts.items()):
            summary_ws.append(["Sheet", name, count])
        summary_ws.freeze_panes = "A2"
        summary_ws.column_dimensions["A"].width = 16
        summary_ws.column_dimensions["B"].width = 38
        summary_ws.column_dimensions["C"].width = 12

        wb.save(output)
        wb.close()
        return output
    except Exception as exc:
        exc.add_note("write_reconciliation_workbook failed")
        raise


def _coordinate(col: int, row: int) -> str:
    try:
        return f"{get_column_letter(col)}{row}"
    except Exception as exc:
        exc.add_note("_coordinate failed")
        raise


def _reconcile_cell(
    analyst_book: OOXMLWorkbook,
    generated_book: OOXMLWorkbook,
    *,
    sheet: str,
    section_id: str,
    coordinate: str,
    row_key: str,
    column_key: str,
    data_field: str = "",
    known_source_error: bool = False,
) -> ReconciliationRow:
    try:
        analyst_cell = analyst_book.read_cell(sheet, coordinate)
        generated_cell = generated_book.read_cell(sheet, coordinate)
        comparison = compare_values(
            analyst_cell.value,
            generated_cell.value,
            analyst_book.style_number_format(analyst_cell.style_id),
            known_source_error=known_source_error,
        )
        return ReconciliationRow(
            report_sheet=sheet,
            section_id=section_id,
            logical_row_key=row_key,
            logical_column_key=column_key,
            data_field=data_field,
            analyst_cell=coordinate,
            generated_cell=coordinate,
            analyst_value=analyst_cell.value,
            generated_value=generated_cell.value,
            status=comparison.status,
            numeric_difference=comparison.numeric_difference,
            category=comparison.category,
            explanation=comparison.explanation,
        )
    except Exception as exc:
        exc.add_note("_reconcile_cell failed")
        raise


def reconcile_workbooks(
    analyst_path: Path | str,
    generated_path: Path | str,
    output_path: Path | str,
    *,
    pivot_specs: tuple[PivotSpec, ...] | list[PivotSpec] | None = None,
) -> ReconciliationSummary:
    """Reconcile configured report sections and KPI cells between workbooks."""
    try:
        specs = list(load_pivot_definitions() if pivot_specs is None else pivot_specs)
        rows: list[ReconciliationRow] = []
        with OOXMLWorkbook(analyst_path) as analyst, OOXMLWorkbook(generated_path) as generated:
            for spec in specs:
                min_col, min_row, max_col, max_row = range_boundaries(spec.reference_range)
                for row in range(min_row, max_row + 1):
                    for col in range(min_col, max_col + 1):
                        coordinate = _coordinate(col, row)
                        analyst_value = analyst.read_cell(spec.sheet, coordinate).value
                        rows.append(_reconcile_cell(
                            analyst,
                            generated,
                            sheet=spec.sheet,
                            section_id=spec.pivot_id,
                            coordinate=coordinate,
                            row_key=f"row:{row - min_row}",
                            column_key=f"col:{col - min_col}",
                            known_source_error=isinstance(analyst_value, ExcelError),
                        ))

            for coordinate in sorted(KPI_RECONCILIATION_CELLS):
                source_value = analyst.read_cell("KPIs", coordinate).value
                rows.append(_reconcile_cell(
                    analyst,
                    generated,
                    sheet="KPIs",
                    section_id="KPIs",
                    coordinate=coordinate,
                    row_key=coordinate,
                    column_key="",
                    known_source_error=(
                        coordinate in BROKEN_REFERENCE_CELLS
                        and isinstance(source_value, ExcelError)
                    ),
                ))

        write_reconciliation_workbook(rows, output_path)
        return summarize(rows)
    except Exception as exc:
        exc.add_note("reconcile_workbooks failed")
        raise


def reconcile_report(
    *,
    analyst_workbook: Path | str,
    generated_workbook: Path | str,
    reconciliation_output: Path | str,
    reference_dir: Path | str | None = None,
) -> PipelineReconciliationSummary:
    """Run report reconciliation and return pipeline-safe summary metadata."""
    try:
        summary = reconcile_workbooks(
            analyst_workbook,
            generated_workbook,
            reconciliation_output,
        )
        return PipelineReconciliationSummary(
            mismatch_count=summary.mismatch_count,
            unexplained_mismatch_count=summary.mismatch_count,
            output_path=str(reconciliation_output),
        )
    except Exception as exc:
        if isinstance(exc, ReconciliationError):
            raise
        raise ReconciliationError("Unable to reconcile generated report") from exc


def append_visual_fidelity_sheet(
    reconciliation_path: Path | str,
    result: VisualFidelityResult,
    *,
    source_name: str,
    generated_name: str,
) -> Path:
    """Append a deterministic visual-fidelity audit sheet to reconciliation output."""
    try:
        path = Path(reconciliation_path)
        workbook = load_workbook(path, data_only=False, keep_links=False)
        try:
            if "Visual Fidelity" in workbook.sheetnames:
                workbook.remove(workbook["Visual Fidelity"])
            sheet = workbook.create_sheet("Visual Fidelity")
            sheet["A1"] = "Final Verdict"
            sheet["B1"] = result.status
            sheet["A2"] = "Source Workbook"
            sheet["B2"] = source_name
            sheet["A3"] = "Generated Workbook"
            sheet["B3"] = generated_name
            sheet["A4"] = "Patched Cells"
            sheet["B4"] = ", ".join(result.patched_cells)
            sheet["A5"] = "Check"
            sheet["B5"] = "Status"
            sheet["C5"] = "Detail"
            for row_number, check in enumerate(result.checks, start=6):
                sheet.cell(row=row_number, column=1, value=check.name)
                sheet.cell(row=row_number, column=2, value=check.status)
                sheet.cell(row=row_number, column=3, value=check.detail)
            sheet.freeze_panes = "A6"
            sheet.column_dimensions["A"].width = 34
            sheet.column_dimensions["B"].width = 18
            sheet.column_dimensions["C"].width = 90
            workbook.save(path)
        finally:
            workbook.close()
        return path
    except Exception as exc:
        raise ReconciliationError(
            f"Unable to append visual fidelity results to {reconciliation_path}"
        ) from exc
