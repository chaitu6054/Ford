from __future__ import annotations


from datetime import date, datetime
import re

from openpyxl.utils.datetime import from_excel

from .models import CellValue, Dataset, ExcelError
from .validate import WorkbookInspection
from .workbook import OOXMLCell, OOXMLWorkbook

DATE_FIELDS = frozenset({
    "date vente", "Date de retour", "date proposition", "date immatriculation (Bless > F6, F17)",
    "DateMaturite", "date revente", "Date envoi mail dealer ne souhaitant pas la reprise",
    "Date reception package complet (fiche restitution,fiche fin de c",
})

TEXT_ID_FIELDS = frozenset({
    "Contrat", "VIN", "immat", "Code Dealer Origine",
    "Code dealer ou le vhl est restitue( +00)", "Code Modele",
    "Code Dealer Repreneur",
})

_DATA_BEARING_FIELDS = ("Contrat", "VIN", "Statut", "Model")
_COL_RE = re.compile(r"^([A-Z]+)")


def _column(coordinate: str) -> str:
    try:
        match = _COL_RE.match(coordinate)
        return match.group(1) if match else coordinate
    except Exception as exc:
        exc.add_note("_column failed")
        raise


def normalize_excel_value(field: str, cell: OOXMLCell) -> CellValue:
    """Normalize one cached worksheet cell into the calculation-domain value."""
    try:
        value = cell.value
        if value is None or isinstance(value, ExcelError):
            return value
        if field in DATE_FIELDS:
            if isinstance(value, datetime):
                return value.date()
            if isinstance(value, date):
                return value
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                converted = from_excel(value)
                return converted.date() if isinstance(converted, datetime) else converted
        # Preserve strings verbatim (including leading zeros) for identifiers and all other text.
        if isinstance(value, str):
            return value
        return value
    except Exception as exc:
        exc.add_note("normalize_excel_value failed")
        raise


def extract_remarketing(book: OOXMLWorkbook, inspection: WorkbookInspection) -> Dataset:
    """Extract the normalized Remarketing dataset from an inspected workbook."""
    try:
        headers = tuple(inspection.column_by_field.keys())
        field_by_column = {column: field for field, column in inspection.column_by_field.items()}
        rows: list[dict[str, CellValue]] = []

        for source_row in book.iter_sheet_rows("Remarketing", min_row=2):
            row: dict[str, CellValue] = {field: None for field in headers}
            for cell in source_row:
                field = field_by_column.get(_column(cell.coordinate))
                if field is None:
                    continue
                row[field] = normalize_excel_value(field, cell)
            if any(row.get(field) is not None for field in _DATA_BEARING_FIELDS if field in row):
                rows.append(row)

        return Dataset(
            headers=headers,
            original_headers=dict(inspection.original_header_by_field),
            rows=rows,
        )
    except Exception as exc:
        exc.add_note("extract_remarketing failed")
        raise


def normalize_dataset(reader: OOXMLWorkbook, inspection: WorkbookInspection) -> Dataset:
    """Return the normalized calculation dataset for a validated workbook."""
    try:
        return extract_remarketing(reader, inspection)
    except Exception as exc:
        exc.add_note("normalize_dataset failed")
        raise
