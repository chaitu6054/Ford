from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from posixpath import dirname, join, normpath
from typing import Literal
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile
from defusedxml.ElementTree import ParseError, fromstring as safe_fromstring

from openpyxl.styles.numbers import is_date_format
from openpyxl.utils.cell import range_boundaries
from openpyxl.utils.datetime import from_excel, to_excel

from .errors import PivotDefinitionError, WorkbookOpenError
from .models import CellValue, Dataset, ExcelError
from .workbook import WorkbookReader

# --- migrated from report_definitions.py ---


@dataclass(frozen=True, slots=True)
class DataFieldSpec:
    """Definition of one pivot data field and aggregation rule."""

    source_field: str
    aggregation: Literal["count", "sum", "average"]
    caption: str
    number_format: str | None
    show_data_as: str | None = None


@dataclass(frozen=True, slots=True)
class FilterSpec:
    """Definition of one saved pivot filter selection."""

    field: str
    included_items: tuple[str, ...] | None
    excluded_items: tuple[str, ...]
    include_blank: bool


@dataclass(frozen=True, slots=True)
class PivotSpec:
    """Serializable definition of one analyst pivot/report section."""

    pivot_id: str
    sheet: str
    excel_name: str
    reference_range: str
    start_cell: str
    row_fields: tuple[str, ...]
    column_fields: tuple[str, ...]
    filters: tuple[FilterSpec, ...]
    data_fields: tuple[DataFieldSpec, ...]
    row_grand_totals: bool
    column_grand_totals: bool
    item_order: dict[str, tuple[str, ...]]
    data_fields_outer: bool = False
    cache_definition: str | None = None


@dataclass(frozen=True, slots=True)
class ChartSeriesSpec:
    """Definition of one chart series sourced from a report section."""

    title: str | None
    source_pivot_id: str
    category_offsets: tuple[int, int, int, int] | None
    category_kind: str | None
    value_offsets: tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class ChartSpec:
    """Definition of one analyst chart and its workbook placement."""

    chart_id: str
    sheet: str
    chart_type: str
    title: str | None
    anchor: str
    source_pivot_id: str
    series: tuple[ChartSeriesSpec, ...]
    legend_position: str | None = None
    category_axis_title: str | None = None
    value_axis_title: str | None = None
    width_cm: float = 15.0
    height_cm: float = 7.5
    bar_direction: str | None = None
    grouping: str | None = None
    gap_width: int | None = None
    overlap: int | None = None
    from_marker: tuple[int, int, int, int] | None = None
    to_marker: tuple[int, int, int, int] | None = None


DEFAULT_REFERENCE_DIR = Path(__file__).resolve().parents[2] / "config" / "reference"

def _load_json(name: str, reference_dir: Path | str | None = None):
    try:
        ref = Path(reference_dir or DEFAULT_REFERENCE_DIR) / name
        with ref.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception as exc:
        exc.add_note("_load_json failed")
        raise


def load_pivot_definitions(reference_dir: Path | str | None = None) -> tuple[PivotSpec, ...]:
    """Load validated pivot/report definitions from packaged JSON metadata."""
    try:
        raw = _load_json("pivot_definitions.json", reference_dir)
        specs = []
        for item in raw:
            specs.append(PivotSpec(
                pivot_id=item["pivot_id"],
                sheet=item["sheet"],
                excel_name=item["excel_name"],
                reference_range=item["reference_range"],
                start_cell=item["start_cell"],
                row_fields=tuple(item.get("row_fields", ())),
                column_fields=tuple(item.get("column_fields", ())),
                filters=tuple(FilterSpec(
                    field=f["field"],
                    included_items=(
                        None
                        if f.get("included_items") is None
                        else tuple(f["included_items"])
                    ),
                    excluded_items=tuple(f.get("excluded_items", ())),
                    include_blank=bool(f.get("include_blank", True)),
                ) for f in item.get("filters", ())),
                data_fields=tuple(DataFieldSpec(
                    source_field=d["source_field"],
                    aggregation=d["aggregation"],
                    caption=d["caption"],
                    number_format=d.get("number_format"),
                    show_data_as=d.get("show_data_as"),
                ) for d in item.get("data_fields", ())),
                row_grand_totals=bool(item.get("row_grand_totals", True)),
                column_grand_totals=bool(item.get("column_grand_totals", True)),
                item_order={key: tuple(value) for key, value in item.get("item_order", {}).items()},
                data_fields_outer=bool(item.get("data_fields_outer", False)),
                cache_definition=item.get("cache_definition"),
            ))
        return tuple(specs)
    except Exception as exc:
        exc.add_note("load_pivot_definitions failed")
        raise


def load_chart_definitions(reference_dir: Path | str | None = None) -> tuple[ChartSpec, ...]:
    """Load analyst chart definitions from packaged JSON metadata."""
    try:
        raw = _load_json("chart_definitions.json", reference_dir)
        specs = []
        for item in raw:
            series = tuple(ChartSeriesSpec(
                title=s.get("title"),
                source_pivot_id=s.get("source_pivot_id", item["source_pivot_id"]),
                category_offsets=(
                    None
                    if s.get("category_offsets") is None
                    else tuple(s["category_offsets"])
                ),
                category_kind=s.get("category_kind"),
                value_offsets=tuple(s["value_offsets"]),
            ) for s in item.get("series", ()))
            specs.append(ChartSpec(
                chart_id=item["chart_id"],
                sheet=item["sheet"],
                chart_type=item["chart_type"],
                title=item.get("title"),
                anchor=item["anchor"],
                source_pivot_id=item["source_pivot_id"],
                series=series,
                legend_position=item.get("legend_position"),
                category_axis_title=item.get("category_axis_title"),
                value_axis_title=item.get("value_axis_title"),
                width_cm=float(item.get("width_cm", 15.0)),
                height_cm=float(item.get("height_cm", 7.5)),
                bar_direction=item.get("bar_direction"),
                grouping=item.get("grouping"),
                gap_width=None if item.get("gap_width") is None else int(item["gap_width"]),
                overlap=None if item.get("overlap") is None else int(item["overlap"]),
                from_marker=None if item.get("from_marker") is None else tuple(item["from_marker"]),
                to_marker=None if item.get("to_marker") is None else tuple(item["to_marker"]),
            ))
        return tuple(specs)
    except Exception as exc:
        exc.add_note("load_chart_definitions failed")
        raise

# --- migrated from pivot_cache.py ---

_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def _local(tag: str) -> str:
    try:
        return tag.rsplit("}", 1)[-1]
    except Exception as exc:
        exc.add_note("_local failed")
        raise


def _number(raw: str | None) -> int | float | None:
    try:
        if raw is None:
            return None
        value = float(raw)
        return int(value) if value.is_integer() else value
    except Exception as exc:
        exc.add_note("_number failed")
        raise


def _typed_value(node: ET.Element) -> CellValue:
    try:
        kind = _local(node.tag)
        raw = node.attrib.get("v")
        if kind == "m":
            return None
        if kind == "s":
            return raw or ""
        if kind == "e":
            return ExcelError(raw or "#N/A")
        if kind == "b":
            return raw == "1"
        if kind == "n":
            return _number(raw)
        if kind == "d":
            if raw is None:
                return None
            parsed = datetime.fromisoformat(raw)
            return parsed.date() if parsed.time() == datetime.min.time() else parsed
        raise PivotDefinitionError(f"unsupported pivot-cache value type: {kind}")
    except Exception as exc:
        exc.add_note("_typed_value failed")
        raise


def _relationships_part(part: str) -> str:
    try:
        return normpath(join(dirname(part), "_rels", f"{part.rsplit('/', 1)[-1]}.rels"))
    except Exception as exc:
        exc.add_note("_relationships_part failed")
        raise


def _resolve(base_part: str, target: str) -> str:
    try:
        if target.startswith("/"):
            return target.lstrip("/")
        return normpath(join(dirname(base_part), target))
    except Exception as exc:
        exc.add_note("_resolve failed")
        raise


def _records_part(zf: ZipFile, cache_definition: str) -> str:
    try:
        rels_part = _relationships_part(cache_definition)
        try:
            root = safe_fromstring(zf.read(rels_part))
        except (KeyError, ParseError) as exc:
            raise PivotDefinitionError(
                f"pivot cache has no readable relationships: {cache_definition}"
            ) from exc
        for rel in root.findall(f"{{{_PKG_REL}}}Relationship"):
            if rel.attrib.get("Type", "").endswith("/pivotCacheRecords"):
                return _resolve(cache_definition, rel.attrib["Target"])
        raise PivotDefinitionError(f"pivot cache has no records relationship: {cache_definition}")
    except Exception as exc:
        exc.add_note("_records_part failed")
        raise


def load_pivot_cache_dataset(path: Path | str, cache_definition: str | None) -> Dataset:
    """Read a normalized dataset from an embedded Excel pivot cache."""
    try:
        if not cache_definition:
            raise PivotDefinitionError("pivot definition does not identify an embedded cache")
        workbook_path = Path(path)
        try:
            zf = ZipFile(workbook_path, "r")
        except (OSError, BadZipFile) as exc:
            raise WorkbookOpenError(f"could not open workbook '{workbook_path}': {exc}") from exc

        try:
            try:
                definition_root = safe_fromstring(zf.read(cache_definition))
            except (KeyError, ParseError) as exc:
                raise PivotDefinitionError(
                    f"could not read pivot cache definition: {cache_definition}"
                ) from exc

            fields_node = definition_root.find(f"{{{_MAIN}}}cacheFields")
            if fields_node is None:
                raise PivotDefinitionError(f"pivot cache contains no fields: {cache_definition}")

            names: list[str] = []
            originals: dict[str, str] = {}
            shared_items: list[list[CellValue]] = []
            for field in fields_node.findall(f"{{{_MAIN}}}cacheField"):
                original = field.attrib.get("name", "")
                name = original.strip()
                names.append(name)
                originals.setdefault(name, original)
                shared = field.find(f"{{{_MAIN}}}sharedItems")
                shared_items.append(
                    []
                    if shared is None
                    else [_typed_value(item) for item in list(shared)]
                )

            records_part = _records_part(zf, cache_definition)
            try:
                records_root = safe_fromstring(zf.read(records_part))
            except (KeyError, ParseError) as exc:
                raise PivotDefinitionError(
                    f"could not read pivot cache records: {records_part}"
                ) from exc

            rows: list[dict[str, CellValue]] = []
            for record in list(records_root):
                row: dict[str, CellValue] = {name: None for name in names}
                for index, node in enumerate(list(record)):
                    if index >= len(names):
                        break
                    if _local(node.tag) == "x":
                        item_index = int(node.attrib["v"])
                        items = shared_items[index]
                        if not 0 <= item_index < len(items):
                            raise PivotDefinitionError(
                                f"pivot cache item index {item_index} out of range "
                                f"for field {names[index]!r}"
                            )
                        value = items[item_index]
                    else:
                        value = _typed_value(node)
                    row[names[index]] = value
                rows.append(row)

            return Dataset(headers=tuple(names), original_headers=originals, rows=rows)
        finally:
            zf.close()
    except Exception as exc:
        exc.add_note("load_pivot_cache_dataset failed")
        raise

# --- migrated from pivot_engine.py ---


@dataclass(slots=True)
class PivotResult:
    """Calculated pivot matrix and logical keyed values."""

    pivot_id: str
    matrix: list[list[CellValue]]
    row_keys: list[tuple[str, ...]]
    column_keys: list[tuple[str, ...]]
    logical_values: dict[tuple[tuple[str, ...], tuple[str, ...], str], CellValue]


def aggregate(values: list[CellValue], kind: str) -> CellValue:
    """Aggregate cell values using the supported Excel pivot aggregation semantics."""
    try:
        if kind == "count":
            return sum(v is not None for v in values)
        numeric = [
            float(value)
            for value in values
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        ]
        if kind == "sum":
            return sum(numeric)
        if kind == "average":
            return None if not numeric else sum(numeric) / len(numeric)
        raise PivotDefinitionError(f"unsupported aggregation: {kind}")
    except Exception as exc:
        exc.add_note("aggregate failed")
        raise


def _display(value: CellValue) -> str:
    try:
        if value is None:
            return "(blank)"
        if isinstance(value, ExcelError):
            return value.code
        if isinstance(value, datetime):
            return value.isoformat(timespec="seconds")
        if isinstance(value, date):
            return value.isoformat()
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return str(value)
    except Exception as exc:
        exc.add_note("_display failed")
        raise


def _label_aliases(label: str) -> tuple[str, ...]:
    try:
        aliases = [label]
        # Pivot caches may store the same Excel date as an ISO date or serial number.
        candidate = label[:10] if len(label) >= 10 else label
        try:
            parsed = date.fromisoformat(candidate)
        except ValueError:
            return tuple(aliases)
        aliases.append(f"{parsed.isoformat()}T00:00:00")
        aliases.append(str(int(to_excel(parsed))))
        return tuple(dict.fromkeys(aliases))
    except Exception as exc:
        exc.add_note("_label_aliases failed")
        raise


def _value_aliases(value: CellValue) -> tuple[str, ...]:
    try:
        return _label_aliases(_display(value))
    except Exception as exc:
        exc.add_note("_value_aliases failed")
        raise


def _matches_manifest_item(value: CellValue, manifest_item: str) -> bool:
    try:
        return manifest_item in _value_aliases(value)
    except Exception as exc:
        exc.add_note("_matches_manifest_item failed")
        raise


def _passes_filter(row: dict[str, CellValue], spec: FilterSpec) -> bool:
    try:
        value = row.get(spec.field)
        if value is None and not spec.include_blank:
            return False
        if spec.included_items is not None:
            if not any(_matches_manifest_item(value, item) for item in spec.included_items):
                return False
        if any(_matches_manifest_item(value, item) for item in spec.excluded_items):
            return False
        return True
    except Exception as exc:
        exc.add_note("_passes_filter failed")
        raise


def _filtered_rows(dataset: Dataset, spec: PivotSpec) -> list[dict[str, CellValue]]:
    try:
        return [
            row
            for row in dataset.rows
            if all(_passes_filter(row, filter_spec) for filter_spec in spec.filters)
        ]
    except Exception as exc:
        exc.add_note("_filtered_rows failed")
        raise


def _saved_rank(label: str, order: tuple[str, ...]) -> int | None:
    try:
        aliases = _label_aliases(label)
        for idx, saved in enumerate(order):
            if saved in aliases:
                return idx
        return None
    except Exception as exc:
        exc.add_note("_saved_rank failed")
        raise


def _item_sort_key(field: str, label: str, spec: PivotSpec):
    try:
        order = spec.item_order.get(field, ())
        rank = _saved_rank(label, order)
        if rank is not None:
            return (0, rank, "", "")
        return (1, len(order), label.casefold(), label)
    except Exception as exc:
        exc.add_note("_item_sort_key failed")
        raise


def _tuple_sort_key(fields: tuple[str, ...], key: tuple[str, ...], spec: PivotSpec):
    try:
        return tuple(_item_sort_key(field, label, spec) for field, label in zip(fields, key))
    except Exception as exc:
        exc.add_note("_tuple_sort_key failed")
        raise


def _full_group_keys(
    rows: list[dict[str, CellValue]],
    fields: tuple[str, ...],
    spec: PivotSpec,
) -> list[tuple[str, ...]]:
    try:
        if not fields:
            return [()]
        keys = {tuple(_display(row.get(field)) for field in fields) for row in rows}
        return sorted(keys, key=lambda key: _tuple_sort_key(fields, key, spec))
    except Exception as exc:
        exc.add_note("_full_group_keys failed")
        raise


def _row_keys(
    rows: list[dict[str, CellValue]],
    fields: tuple[str, ...],
    spec: PivotSpec,
) -> list[tuple[str, ...]]:
    try:
        full = _full_group_keys(rows, fields, spec)
        if len(fields) <= 1:
            return full
        output: list[tuple[str, ...]] = []
        seen: set[tuple[str, ...]] = set()
        for key in full:
            for depth in range(1, len(key) + 1):
                prefix = key[:depth]
                if prefix not in seen:
                    seen.add(prefix)
                    output.append(prefix)
        return output
    except Exception as exc:
        exc.add_note("_row_keys failed")
        raise


def _row_matches_key(
    row: dict[str, CellValue],
    fields: tuple[str, ...],
    key: tuple[str, ...],
) -> bool:
    try:
        return all(_display(row.get(field)) == label for field, label in zip(fields, key))
    except Exception as exc:
        exc.add_note("_row_matches_key failed")
        raise


def _rows_for(
    rows: list[dict[str, CellValue]],
    row_fields: tuple[str, ...],
    row_key: tuple[str, ...],
    col_fields: tuple[str, ...],
    col_key: tuple[str, ...],
) -> list[dict[str, CellValue]]:
    try:
        result = []
        for row in rows:
            if row_key and not _row_matches_key(row, row_fields, row_key):
                continue
            if col_key and not _row_matches_key(row, col_fields, col_key):
                continue
            result.append(row)
        return result
    except Exception as exc:
        exc.add_note("_rows_for failed")
        raise


def _raw_aggregate(rows: list[dict[str, CellValue]], data_field: DataFieldSpec) -> CellValue:
    try:
        if not rows:
            return None
        return aggregate([row.get(data_field.source_field) for row in rows], data_field.aggregation)
    except Exception as exc:
        exc.add_note("_raw_aggregate failed")
        raise


def _measure(
    rows: list[dict[str, CellValue]],
    row_fields: tuple[str, ...],
    row_key: tuple[str, ...],
    col_fields: tuple[str, ...],
    col_key: tuple[str, ...],
    data_field: DataFieldSpec,
) -> CellValue:
    try:
        numerator_rows = _rows_for(rows, row_fields, row_key, col_fields, col_key)
        numerator = _raw_aggregate(numerator_rows, data_field)
        if data_field.show_data_as is None:
            return numerator
        if data_field.show_data_as == "percentOfCol":
            denominator_rows = _rows_for(rows, (), (), col_fields, col_key)
            denominator = _raw_aggregate(denominator_rows, data_field)
            if numerator is None and not numerator_rows:
                numerator = 0
            if (
                not isinstance(numerator, (int, float))
                or not isinstance(denominator, (int, float))
                or denominator == 0
            ):
                return None
            return float(numerator) / float(denominator)
        raise PivotDefinitionError(f"unsupported showDataAs mode: {data_field.show_data_as}")
    except Exception as exc:
        exc.add_note("_measure failed")
        raise


def _total_across_columns(
    rows: list[dict[str, CellValue]],
    row_fields: tuple[str, ...],
    row_key: tuple[str, ...],
    data_field: DataFieldSpec,
) -> CellValue:
    try:
        numerator_rows = _rows_for(rows, row_fields, row_key, (), ())
        numerator = _raw_aggregate(numerator_rows, data_field)
        if data_field.show_data_as is None:
            return numerator
        if data_field.show_data_as == "percentOfCol":
            denominator = _raw_aggregate(rows, data_field)
            if (
                not isinstance(numerator, (int, float))
                or not isinstance(denominator, (int, float))
                or denominator == 0
            ):
                return None
            return float(numerator) / float(denominator)
        raise PivotDefinitionError(f"unsupported showDataAs mode: {data_field.show_data_as}")
    except Exception as exc:
        exc.add_note("_total_across_columns failed")
        raise


def _grand_for_column(
    rows: list[dict[str, CellValue]],
    col_fields: tuple[str, ...],
    col_key: tuple[str, ...],
    data_field: DataFieldSpec,
) -> CellValue:
    try:
        column_rows = _rows_for(rows, (), (), col_fields, col_key)
        value = _raw_aggregate(column_rows, data_field)
        if data_field.show_data_as == "percentOfCol":
            if isinstance(value, (int, float)) and value != 0:
                return 1.0
            return None
        return value
    except Exception as exc:
        exc.add_note("_grand_for_column failed")
        raise


def _matrix_label(row_key: tuple[str, ...]) -> str:
    try:
        return row_key[-1] if row_key else ""
    except Exception as exc:
        exc.add_note("_matrix_label failed")
        raise


def _render_no_columns(
    spec: PivotSpec,
    rows: list[dict[str, CellValue]],
    row_keys: list[tuple[str, ...]],
) -> list[list[CellValue]]:
    try:
        data_fields = spec.data_fields
        if not spec.row_fields:
            if not data_fields:
                return []
            if len(data_fields) == 1:
                field = data_fields[0]
                return [[field.caption], [_measure(rows, (), (), (), (), field)]]
            return [
                [field.caption for field in data_fields],
                [_measure(rows, (), (), (), (), field) for field in data_fields],
            ]

        if not data_fields:
            matrix: list[list[CellValue]] = [["Étiquettes de lignes"]]
            matrix.extend([[_matrix_label(key)] for key in row_keys])
            if spec.column_grand_totals:
                matrix.append(["Total général"])
            return matrix

        matrix = [["Étiquettes de lignes", *[field.caption for field in data_fields]]]
        for key in row_keys:
            matrix.append([
                _matrix_label(key),
                *[_measure(rows, spec.row_fields, key, (), (), field) for field in data_fields],
            ])
        if spec.column_grand_totals:
            matrix.append([
                "Total général",
                *[_grand_for_column(rows, (), (), field) for field in data_fields],
            ])
        return matrix
    except Exception as exc:
        exc.add_note("_render_no_columns failed")
        raise


def _render_one_data_with_columns(
    spec: PivotSpec,
    rows: list[dict[str, CellValue]],
    row_keys: list[tuple[str, ...]],
    col_keys: list[tuple[str, ...]],
) -> list[list[CellValue]]:
    try:
        field = spec.data_fields[0]
        col_labels = [_matrix_label(key) for key in col_keys]
        total_col = ["Total général"] if spec.row_grand_totals else []
        if spec.row_fields:
            matrix: list[list[CellValue]] = [
                [
                    field.caption,
                    "Étiquettes de colonnes",
                    *([None] * max(0, len(col_keys) - 1)),
                    *([None] if spec.row_grand_totals else []),
                ],
                ["Étiquettes de lignes", *col_labels, *total_col],
            ]
            for row_key in row_keys:
                values = [
                    _measure(
                        rows,
                        spec.row_fields,
                        row_key,
                        spec.column_fields,
                        col_key,
                        field,
                    )
                    for col_key in col_keys
                ]
                if spec.row_grand_totals:
                    values.append(_total_across_columns(rows, spec.row_fields, row_key, field))
                matrix.append([_matrix_label(row_key), *values])
            if spec.column_grand_totals:
                totals = [
                    _grand_for_column(rows, spec.column_fields, col_key, field)
                    for col_key in col_keys
                ]
                if spec.row_grand_totals:
                    totals.append(_grand_for_column(rows, (), (), field))
                matrix.append(["Total général", *totals])
            return matrix

        matrix = [
            [
                None,
                "Étiquettes de colonnes",
                *([None] * max(0, len(col_keys) - 1)),
                *([None] if spec.row_grand_totals else []),
            ],
            [None, *col_labels, *total_col],
        ]
        values = [
            _grand_for_column(rows, spec.column_fields, col_key, field)
            for col_key in col_keys
        ]
        if spec.row_grand_totals:
            values.append(_grand_for_column(rows, (), (), field))
        matrix.append([field.caption, *values])
        return matrix
    except Exception as exc:
        exc.add_note("_render_one_data_with_columns failed")
        raise


def _render_multi_data_with_columns(
    spec: PivotSpec,
    rows: list[dict[str, CellValue]],
    row_keys: list[tuple[str, ...]],
    col_keys: list[tuple[str, ...]],
) -> list[list[CellValue]]:
    try:
        fields = spec.data_fields
        n = len(fields)
        total_headers = (
            [f"Total {field.caption}" for field in fields]
            if spec.row_grand_totals
            else []
        )
        matrix: list[list[CellValue]] = []

        if spec.data_fields_outer:
            width_each = len(col_keys)
            top = [None]
            labels = ["Étiquettes de lignes"]
            for field in fields:
                top.extend([field.caption, *([None] * max(0, width_each - 1))])
                labels.extend([_matrix_label(key) for key in col_keys])
            top.extend(total_headers)
            labels.extend([None] * len(total_headers))
            header = [None, "Étiquettes de colonnes", *([None] * max(0, len(top) - 2))]
            matrix.extend([header, top, labels])

            for row_key in row_keys:
                out: list[CellValue] = [_matrix_label(row_key)]
                for field in fields:
                    out.extend(
                        _measure(
                            rows,
                            spec.row_fields,
                            row_key,
                            spec.column_fields,
                            col_key,
                            field,
                        )
                        for col_key in col_keys
                    )
                if spec.row_grand_totals:
                    out.extend(
                        _total_across_columns(rows, spec.row_fields, row_key, field)
                        for field in fields
                    )
                matrix.append(out)
            if spec.column_grand_totals:
                out = ["Total général"]
                for field in fields:
                    out.extend(
                        _grand_for_column(rows, spec.column_fields, col_key, field)
                        for col_key in col_keys
                    )
                if spec.row_grand_totals:
                    out.extend(_grand_for_column(rows, (), (), field) for field in fields)
                matrix.append(out)
            return matrix

        # Real column items are outer; data fields repeat inside each item.
        header0: list[CellValue] = [None, "Étiquettes de colonnes"]
        body_width = len(col_keys) * n
        header0.extend([None] * max(0, body_width - 1))
        header0.extend([None] * len(total_headers))
        header1: list[CellValue] = [None]
        for col_key in col_keys:
            header1.extend([_matrix_label(col_key), *([None] * (n - 1))])
        header1.extend(total_headers)
        header2: list[CellValue] = ["Étiquettes de lignes"]
        for _ in col_keys:
            header2.extend(field.caption for field in fields)
        header2.extend([None] * len(total_headers))
        matrix.extend([header0, header1, header2])

        for row_key in row_keys:
            out = [_matrix_label(row_key)]
            for col_key in col_keys:
                out.extend(
                    _measure(
                        rows,
                        spec.row_fields,
                        row_key,
                        spec.column_fields,
                        col_key,
                        field,
                    )
                    for field in fields
                )
            if spec.row_grand_totals:
                out.extend(
                    _total_across_columns(rows, spec.row_fields, row_key, field)
                    for field in fields
                )
            matrix.append(out)
        if spec.column_grand_totals:
            out = ["Total général"]
            for col_key in col_keys:
                out.extend(
                    _grand_for_column(rows, spec.column_fields, col_key, field)
                    for field in fields
                )
            if spec.row_grand_totals:
                out.extend(_grand_for_column(rows, (), (), field) for field in fields)
            matrix.append(out)
        return matrix
    except Exception as exc:
        exc.add_note("_render_multi_data_with_columns failed")
        raise


def run_pivot(dataset: Dataset, spec: PivotSpec) -> PivotResult:
    """Calculate one pivot/report section from a normalized dataset."""
    try:
        rows = _filtered_rows(dataset, spec)
        row_keys = _row_keys(rows, spec.row_fields, spec)
        col_keys = _full_group_keys(rows, spec.column_fields, spec)

        logical_values: dict[tuple[tuple[str, ...], tuple[str, ...], str], CellValue] = {}
        for row_key in row_keys:
            for col_key in col_keys:
                for field in spec.data_fields:
                    logical_values[(row_key, col_key, field.caption)] = _measure(
                        rows, spec.row_fields, row_key, spec.column_fields, col_key, field
                    )

        if not spec.column_fields:
            matrix = _render_no_columns(spec, rows, row_keys)
        elif len(spec.data_fields) <= 1:
            matrix = _render_one_data_with_columns(spec, rows, row_keys, col_keys)
        else:
            matrix = _render_multi_data_with_columns(spec, rows, row_keys, col_keys)

        return PivotResult(spec.pivot_id, matrix, row_keys, col_keys, logical_values)
    except Exception as exc:
        exc.add_note("run_pivot failed")
        raise

# --- migrated from kpi_engine.py ---

AGEING_BUCKETS = (
    "0-30 Days",
    "31-60 Days",
    "61-90 Days",
    "91-120 Days",
    "121-150 Days",
    "151-180 Days",
    "181-360 Days",
    "360+ Days",
)
AGEING_CELLS = dict(zip(("H4", "I4", "J4", "K4", "L4", "M4", "N4", "O4"), AGEING_BUCKETS))

BROKEN_REFERENCE_CELLS = frozenset({
    "C4", "C5", "C7", "C8", "C11", "C12", "C13", "C14", "C15", "C16",
    "H5", "I5", "J5", "K5", "L5", "M5", "N5", "O5", "P5", "R5",
    "H13", "I13", "J13", "K13", "L13", "M13", "N13", "O13", "P13", "R13",
    "H14", "I14", "J14", "K14", "L14", "M14", "N14", "O14", "P14", "R14",
    *{f"B{row}" for row in range(21, 33)},
    *{f"C{row}" for row in range(21, 28)},
    *{f"E{row}" for row in range(21, 28)},
})


@dataclass(slots=True)
class KPIResult:
    """Calculated KPI values plus source-workbook warnings."""

    values: dict[str, CellValue]
    warnings: list[str]


def _text_equals(value: CellValue, expected: str) -> bool:
    try:
        return isinstance(value, str) and value.casefold() == expected.casefold()
    except Exception as exc:
        exc.add_note("_text_equals failed")
        raise


def calculate_intact_kpis(dataset: Dataset, report_as_of_date: date) -> dict[str, CellValue]:
    """Calculate KPI cells whose source formulas are intact and reproducible."""
    try:
        unsold_rows = [
            row
            for row in dataset.rows
            if _text_equals(row.get("Sold Check 2"), "Non Solde")
        ]
        values: dict[str, CellValue] = {
            "C2": report_as_of_date,
            "C3": len(unsold_rows),
            "T4": sum(_text_equals(row.get("Sold Check 3"), "Solde") for row in dataset.rows),
            "C6": sum(
                _text_equals(row.get("Sold Check 3"), "Non Solde")
                and _text_equals(row.get("FSA"), "FSA")
                for row in dataset.rows
            ),
            # C19 and E19 are intact source formulas (=C2), so they follow
            # the deterministic run date.
            "C19": report_as_of_date,
            "E19": report_as_of_date,
        }
        for coordinate, bucket in AGEING_CELLS.items():
            values[coordinate] = sum(
                _text_equals(row.get("Age Bucket (Unsold)"), bucket)
                for row in unsold_rows
            )
        total_ageing = sum(int(values[coordinate]) for coordinate in AGEING_CELLS)
        values["P4"] = total_ageing
        values["R4"] = "OK" if total_ageing == values["C3"] else "ISSUE"
        return values
    except Exception as exc:
        exc.add_note("calculate_intact_kpis failed")
        raise


def source_kpi_date(book: WorkbookReader, coordinate: str) -> date:
    """Read a cached date value from a KPI worksheet cell."""
    try:
        cell = book.read_cell("KPIs", coordinate)
        value = cell.value
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            number_format = book.style_number_format(cell.style_id)
            if is_date_format(number_format) or (cell.formula and "TODAY" in cell.formula.upper()):
                converted = from_excel(value)
                return converted.date() if isinstance(converted, datetime) else converted
        raise ValueError(f"KPIs!{coordinate} does not contain a cached Excel date")
    except Exception as exc:
        exc.add_note("source_kpi_date failed")
        raise


def build_kpi_result(
    dataset: Dataset,
    report_as_of_date: date,
    source_book: WorkbookReader,
) -> KPIResult:
    """Build deterministic KPI output while preserving known source errors."""
    try:
        values = calculate_intact_kpis(dataset, report_as_of_date)
        values["B1"] = source_kpi_date(source_book, "B1")
        values["C10"] = source_kpi_date(source_book, "C10")

        warnings: list[str] = []
        for coordinate in sorted(BROKEN_REFERENCE_CELLS):
            source_value = source_book.read_cell("KPIs", coordinate).value
            if isinstance(source_value, ExcelError):
                values[coordinate] = source_value
                warnings.append(
                    f"SOURCE_FORMULA_BROKEN_PRESERVED: KPIs!{coordinate} {source_value.code}"
                )
        return KPIResult(values=values, warnings=warnings)
    except Exception as exc:
        exc.add_note("build_kpi_result failed")
        raise

def _saved_single_cell_error(book: WorkbookReader, spec: PivotSpec):
    try:
        min_col, min_row, max_col, max_row = range_boundaries(spec.reference_range)
        if (min_col, min_row) != (max_col, max_row):
            return None
        value = book.read_cell(spec.sheet, spec.start_cell).value
        return value if isinstance(value, ExcelError) else None
    except Exception as exc:
        exc.add_note("_saved_single_cell_error failed")
        raise

def build_pivot_results(
    input_path: Path | str,
    specs: Iterable[PivotSpec],
) -> dict[str, PivotResult]:
    """Calculate all configured report sections from the source workbook caches."""
    try:
        path = Path(input_path)
        cache_datasets = {}
        results = {}
        with WorkbookReader(path) as source_book:
            for spec in specs:
                saved_error = _saved_single_cell_error(source_book, spec)
                if saved_error is not None:
                    results[spec.pivot_id] = PivotResult(spec.pivot_id, [[saved_error]], [], [], {})
                    continue
                cache_key = spec.cache_definition
                if cache_key not in cache_datasets:
                    cache_datasets[cache_key] = load_pivot_cache_dataset(path, cache_key)
                results[spec.pivot_id] = run_pivot(cache_datasets[cache_key], spec)
        return results
    except Exception as exc:
        exc.add_note("build_pivot_results failed")
        raise
