from __future__ import annotations

from collections.abc import Iterable, Mapping
from copy import copy
from dataclasses import dataclass
from datetime import date, datetime
import os
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference, Series
from openpyxl.chart.data_source import AxDataSource, NumRef, StrRef
from openpyxl.chart.legend import Legend
from openpyxl.chart.series import SeriesLabel
from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, TwoCellAnchor
from openpyxl.styles.numbers import is_date_format
from openpyxl.utils.cell import get_column_letter, range_boundaries
from openpyxl.utils.datetime import to_excel

from .calculate import (
    ChartSeriesSpec,
    ChartSpec,
    KPIResult,
    PivotResult,
    PivotSpec,
    build_kpi_result,
    build_pivot_results,
    load_chart_definitions,
    load_pivot_definitions,
)
from .errors import LayoutOverflowError, PivotDefinitionError, ReportGenerationError
from .models import ExcelError, ReportArtifact
from .normalize import extract_remarketing
from .validate import inspect_workbook
from .workbook import OOXMLWorkbook, WorkbookReader

# --- migrated from charts.py ---


def _reference(ws, pivot: PivotSpec, offsets: tuple[int, int, int, int]) -> Reference:
    try:
        start_col, start_row, _, _ = range_boundaries(pivot.start_cell)
        row1, col1, row2, col2 = offsets
        return Reference(
            ws,
            min_col=start_col + col1,
            min_row=start_row + row1,
            max_col=start_col + col2,
            max_row=start_row + row2,
        )
    except Exception as exc:
        exc.add_note("_reference failed")
        raise


def _series_title(series, title: str | None) -> None:
    try:
        if not title:
            return
        if "!" in title:
            series.tx = SeriesLabel(strRef=StrRef(f=title))
        else:
            series.tx = SeriesLabel(v=title)
    except Exception as exc:
        exc.add_note("_series_title failed")
        raise


def _append_series(chart, ws, pivot: PivotSpec, spec: ChartSeriesSpec) -> None:
    try:
        values = _reference(ws, pivot, spec.value_offsets)
        series = Series(values)
        _series_title(series, spec.title)
        if spec.category_offsets is not None:
            categories = _reference(ws, pivot, spec.category_offsets)
            formula = str(categories)
            if spec.category_kind == "str":
                series.cat = AxDataSource(strRef=StrRef(f=formula))
            else:
                series.cat = AxDataSource(numRef=NumRef(f=formula))
        chart.append(series)
    except Exception as exc:
        exc.add_note("_append_series failed")
        raise


def _anchor(spec: ChartSpec) -> TwoCellAnchor | None:
    try:
        if spec.from_marker is None or spec.to_marker is None:
            return None
        return TwoCellAnchor(
            _from=AnchorMarker(*spec.from_marker),
            to=AnchorMarker(*spec.to_marker),
        )
    except Exception as exc:
        exc.add_note("_anchor failed")
        raise


def create_chart(ws: Any, spec: ChartSpec, pivots: Mapping[str, PivotSpec]) -> Any:
    """Create one analyst chart from configured report-section references."""
    try:
        if spec.chart_type == "barChart":
            chart = BarChart()
            if spec.bar_direction is not None:
                chart.type = spec.bar_direction
            if spec.grouping is not None:
                chart.grouping = spec.grouping
            if spec.gap_width is not None:
                chart.gapWidth = spec.gap_width
            if spec.overlap is not None:
                chart.overlap = spec.overlap
        elif spec.chart_type == "lineChart":
            chart = LineChart()
            if spec.grouping is not None:
                chart.grouping = spec.grouping
        elif spec.chart_type == "pieChart":
            chart = PieChart()
        else:
            raise PivotDefinitionError(f"unsupported chart type: {spec.chart_type}")

        chart.title = spec.title
        chart.width = spec.width_cm
        chart.height = spec.height_cm
        chart.legend = (
            None
            if spec.legend_position is None
            else Legend(legendPos=spec.legend_position)
        )
        if hasattr(chart, "x_axis") and spec.category_axis_title is not None:
            chart.x_axis.title = spec.category_axis_title
        if hasattr(chart, "y_axis") and spec.value_axis_title is not None:
            chart.y_axis.title = spec.value_axis_title

        for series_spec in spec.series:
            try:
                pivot = pivots[series_spec.source_pivot_id]
            except KeyError as exc:
                raise PivotDefinitionError(
                    f"chart {spec.chart_id} references unknown pivot {series_spec.source_pivot_id}"
                ) from exc
            _append_series(chart, ws, pivot, series_spec)

        exact_anchor = _anchor(spec)
        chart.anchor = exact_anchor if exact_anchor is not None else spec.anchor
        return chart
    except Exception as exc:
        exc.add_note("create_chart failed")
        raise


def render_charts(
    workbook: Any,
    specs: tuple[ChartSpec, ...] | list[ChartSpec],
    pivots: Mapping[str, PivotSpec],
) -> None:
    """Render all configured analyst charts into the target workbook."""
    try:
        for spec in specs:
            ws = workbook[spec.sheet]
            ws.add_chart(create_chart(ws, spec, pivots))
    except Exception as exc:
        exc.add_note("render_charts failed")
        raise

# --- migrated from passthrough.py ---

PASS_THROUGH_SHEETS = (
    "regle offensive",
    "Détails1",
    "Détails2",
    "Solde a checker offensive",
    "Ludovic",
    "remarketing retractatio-engagem",
    "suivi offensivetracker",
    "Repossession",
    "FSA-UPDATE 24042026",
    "code couleur",
)


def _formula_without_cache_warnings(source_path: Path, sheet_names: list[str]) -> list[str]:
    try:
        warnings: list[str] = []
        with OOXMLWorkbook(source_path) as raw:
            available = set(raw.sheet_names())
            for sheet_name in sheet_names:
                if sheet_name not in available:
                    continue
                for row in raw.iter_sheet_rows(sheet_name):
                    for cell in row:
                        if cell.formula is not None and cell.value is None:
                            warnings.append(
                                "PASS_THROUGH_FORMULA_WITHOUT_CACHE: "
                                f"{sheet_name}!{cell.coordinate}"
                            )
        return warnings
    except Exception as exc:
        exc.add_note("_formula_without_cache_warnings failed")
        raise


def _copy_cell(source_cell, target_cell) -> None:
    try:
        target_cell.value = source_cell.value
        if source_cell.data_type == "e":
            target_cell.data_type = "e"
        if source_cell.has_style:
            target_cell.font = copy(source_cell.font)
            target_cell.fill = copy(source_cell.fill)
            target_cell.border = copy(source_cell.border)
            target_cell.alignment = copy(source_cell.alignment)
            target_cell.protection = copy(source_cell.protection)
            target_cell.number_format = source_cell.number_format
    except Exception as exc:
        exc.add_note("_copy_cell failed")
        raise


def _copy_sheet(source_ws, target_ws) -> None:
    try:
        target_ws.sheet_state = source_ws.sheet_state
        for source_cell in source_ws._cells.values():
            _copy_cell(source_cell, target_ws.cell(source_cell.row, source_cell.column))

        for merged in source_ws.merged_cells.ranges:
            target_ws.merge_cells(str(merged))

        for key, dimension in source_ws.column_dimensions.items():
            copied = copy(dimension)
            copied.worksheet = target_ws
            target_ws.column_dimensions[key] = copied
        for key, dimension in source_ws.row_dimensions.items():
            copied = copy(dimension)
            copied.worksheet = target_ws
            target_ws.row_dimensions[key] = copied

        target_ws.views = copy(source_ws.views)
        target_ws.sheet_format = copy(source_ws.sheet_format)
        target_ws.sheet_properties = copy(source_ws.sheet_properties)
        target_ws.page_margins = copy(source_ws.page_margins)
        target_ws.page_setup = copy(source_ws.page_setup)
        target_ws.print_options = copy(source_ws.print_options)
        target_ws.auto_filter = copy(source_ws.auto_filter)
    except Exception as exc:
        exc.add_note("_copy_sheet failed")
        raise


def copy_pass_through_sheets(
    source_path: Path | str,
    target_workbook: Any,
) -> list[str]:
    """Copy approved pass-through sheets while collecting cache warnings."""
    try:
        source = Path(source_path)
        source_wb = load_workbook(source, data_only=True, keep_links=False)
        try:
            selected = [name for name in PASS_THROUGH_SHEETS if name in source_wb.sheetnames]
            warnings = _formula_without_cache_warnings(source, selected)
            for sheet_name in selected:
                if sheet_name in target_workbook.sheetnames:
                    del target_workbook[sheet_name]
                target_ws = target_workbook.create_sheet(sheet_name)
                _copy_sheet(source_wb[sheet_name], target_ws)
            return warnings
        finally:
            source_wb.close()
    except Exception as exc:
        exc.add_note("copy_pass_through_sheets failed")
        raise

# --- migrated from renderer.py ---


@dataclass(frozen=True, slots=True)
class RenderedBlock:
    """Location metadata for one rendered report section."""

    pivot_id: str
    sheet: str
    start_cell: str
    end_cell: str


def _excel_value(value):
    try:
        return value.code if isinstance(value, ExcelError) else value
    except Exception as exc:
        exc.add_note("_excel_value failed")
        raise


def _text_alias(value: str) -> str:
    try:
        aliases = {
            "(vide)": "(blank)",
            "Grand Total": "Total général",
            "Row Labels": "Étiquettes de lignes",
            "Column Labels": "Étiquettes de colonnes",
        }
        return aliases.get(value.rstrip(), value.rstrip())
    except Exception as exc:
        exc.add_note("_text_alias failed")
        raise


def _equivalent_to_analyst(generated, analyst, analyst_number_format: str) -> bool:
    try:
        if isinstance(analyst, ExcelError):
            if isinstance(generated, ExcelError):
                return generated.code == analyst.code
            return isinstance(generated, str) and generated == analyst.code
        if isinstance(generated, ExcelError):
            return False
        if isinstance(analyst, (int, float)) and is_date_format(analyst_number_format):
            if isinstance(generated, (date, datetime)):
                return float(to_excel(generated)) == float(analyst)
            if isinstance(generated, str):
                try:
                    parsed = (
                        datetime.fromisoformat(generated)
                        if "T" in generated
                        else date.fromisoformat(generated)
                    )
                except ValueError:
                    pass
                else:
                    return float(to_excel(parsed)) == float(analyst)
        if (
            isinstance(generated, str)
            and isinstance(analyst, (int, float))
            and not isinstance(analyst, bool)
        ):
            normalized = (
                int(analyst)
                if isinstance(analyst, float) and analyst.is_integer()
                else analyst
            )
            return generated == str(normalized)
        if isinstance(generated, str) and isinstance(analyst, str):
            return _text_alias(generated) == _text_alias(analyst)
        return generated == analyst
    except Exception as exc:
        exc.add_note("_equivalent_to_analyst failed")
        raise


def _pivot_excel_value(value, analyst_cell=None, analyst_number_format: str = "General"):
    try:
        if analyst_cell is not None and _equivalent_to_analyst(
            value,
            analyst_cell,
            analyst_number_format,
        ):
            return _excel_value(analyst_cell)
        if value == "(blank)":
            return "(vide)"
        return _excel_value(value)
    except Exception as exc:
        exc.add_note("_pivot_excel_value failed")
        raise


def _matrix_shape(matrix: list[list[object]]) -> tuple[int, int]:
    try:
        return len(matrix), max((len(row) for row in matrix), default=0)
    except Exception as exc:
        exc.add_note("_matrix_shape failed")
        raise


def _result_bounds(spec: PivotSpec, result: PivotResult) -> tuple[int, int, int, int]:
    try:
        start_col, start_row, _, _ = range_boundaries(spec.start_cell)
        rows, cols = _matrix_shape(result.matrix)
        end_row = start_row + max(0, rows - 1)
        end_col = start_col + max(0, cols - 1)
        return start_col, start_row, end_col, end_row
    except Exception as exc:
        exc.add_note("_result_bounds failed")
        raise


def _rectangles_overlap(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    try:
        return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])
    except Exception as exc:
        exc.add_note("_rectangles_overlap failed")
        raise


def _validate_layout(specs: list[PivotSpec], results: Mapping[str, PivotResult]) -> None:
    try:
        by_sheet: dict[str, list[PivotSpec]] = {}
        for spec in specs:
            by_sheet.setdefault(spec.sheet, []).append(spec)
        for sheet_specs in by_sheet.values():
            for spec in sheet_specs:
                result = results.get(spec.pivot_id)
                if result is None:
                    continue
                produced = _result_bounds(spec, result)
                for other in sheet_specs:
                    if other.pivot_id == spec.pivot_id:
                        continue
                    reserved = range_boundaries(other.reference_range)
                    if _rectangles_overlap(produced, reserved):
                        own_reference = range_boundaries(spec.reference_range)
                        # Expansion into another saved report region is not safe. An
                        # overlap that is already part of the source layout is allowed.
                        if not _rectangles_overlap(own_reference, reserved):
                            raise LayoutOverflowError(
                                f"{spec.pivot_id} expansion overlaps {other.pivot_id} "
                                f"on {spec.sheet}; "
                                f"requires rows {produced[1]}:{produced[3]}"
                            )
    except Exception as exc:
        exc.add_note("_validate_layout failed")
        raise


def _copy_style(source, target) -> None:
    try:
        if source.has_style:
            target._style = copy(source._style)
        if source.number_format:
            target.number_format = source.number_format
    except Exception as exc:
        exc.add_note("_copy_style failed")
        raise


def _prototype_cell(ws, spec: PivotSpec, out_row: int, out_col: int, value):
    try:
        min_col, min_row, max_col, max_row = range_boundaries(spec.reference_range)
        if min_row <= out_row <= max_row and min_col <= out_col <= max_col:
            return ws.cell(out_row, out_col)

        relative_col = out_col - min_col
        source_col = min(max_col, min_col + max(0, relative_col))
        is_total = isinstance(value, str) and value in {"Total général", "Grand Total"}
        if is_total:
            source_row = max_row
        else:
            source_row = min(max_row - 1 if max_row > min_row else max_row, min_row + 1)
        return ws.cell(source_row, source_col)
    except Exception as exc:
        exc.add_note("_prototype_cell failed")
        raise


def _apply_data_number_format(cell, spec: PivotSpec, matrix_col_index: int) -> None:
    try:
        if matrix_col_index == 0 or not spec.data_fields:
            return
        # The exact column structure varies by pivot layout. Repeating data-field
        # formats is correct for both single-measure and multi-measure column blocks.
        data_index = (matrix_col_index - 1) % len(spec.data_fields)
        fmt = spec.data_fields[data_index].number_format
        if fmt:
            cell.number_format = fmt
    except Exception as exc:
        exc.add_note("_apply_data_number_format failed")
        raise


def render_kpi_result(ws: Any, result: KPIResult) -> None:
    """Render deterministic KPI values into the target worksheet."""
    try:
        for coordinate, value in result.values.items():
            ws[coordinate].value = _excel_value(value)
    except Exception as exc:
        exc.add_note("render_kpi_result failed")
        raise


def render_pivot_result(
    ws: Any,
    spec: PivotSpec,
    result: PivotResult,
    analyst_book: OOXMLWorkbook | None = None,
) -> RenderedBlock:
    """Render one calculated pivot/report section into a worksheet."""
    try:
        start_col, start_row, _, _ = range_boundaries(spec.start_cell)
        rows, cols = _matrix_shape(result.matrix)

        for row_index, row in enumerate(result.matrix):
            out_row = start_row + row_index
            for col_index in range(cols):
                out_col = start_col + col_index
                value = row[col_index] if col_index < len(row) else None
                target = ws.cell(out_row, out_col)
                prototype = _prototype_cell(ws, spec, out_row, out_col, value)
                if prototype.coordinate != target.coordinate:
                    _copy_style(prototype, target)
                analyst_cell = None
                analyst_format = "General"
                if analyst_book is not None:
                    analyst_cell = analyst_book.read_cell(spec.sheet, target.coordinate)
                    analyst_format = analyst_book.style_number_format(analyst_cell.style_id)
                analyst_value = None if analyst_cell is None else analyst_cell.value
                equivalent = analyst_cell is not None and _equivalent_to_analyst(
                    value,
                    analyst_value,
                    analyst_format,
                )
                coerced = _pivot_excel_value(value, analyst_value, analyst_format)
                target.value = coerced
                if equivalent and analyst_cell is not None and isinstance(coerced, str):
                    if analyst_cell.data_type == "e":
                        target.data_type = "e"
                    elif analyst_cell.data_type in {"s", "str", "inlineStr"}:
                        target.data_type = "s"
                (
                    ref_min_col,
                    ref_min_row,
                    ref_max_col,
                    ref_max_row,
                ) = range_boundaries(spec.reference_range)
                if (
                    analyst_cell is not None
                    and ref_min_row <= out_row <= ref_max_row
                    and ref_min_col <= out_col <= ref_max_col
                ):
                    target.number_format = analyst_format
                else:
                    _apply_data_number_format(target, spec, col_index)

        end_col = start_col + max(0, cols - 1)
        end_row = start_row + max(0, rows - 1)
        return RenderedBlock(
            pivot_id=spec.pivot_id,
            sheet=spec.sheet,
            start_cell=spec.start_cell,
            end_cell=f"{get_column_letter(end_col)}{end_row}",
        )
    except Exception as exc:
        exc.add_note("render_pivot_result failed")
        raise


def render_report_workbook(
    template_path: Path | str,
    specs: Iterable[PivotSpec],
    results: Mapping[str, PivotResult],
    output_path: Path | str,
    *,
    chart_specs: Iterable[ChartSpec] = (),
    passthrough_source: Path | str | None = None,
    passthrough_warnings: list[str] | None = None,
    analyst_reference_path: Path | str | None = None,
) -> Path:
    """Render the full analyst-facing workbook from the validated template."""
    try:
        spec_list = list(specs)
        chart_list = list(chart_specs)
        _validate_layout(spec_list, results)
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        wb = load_workbook(template_path, data_only=False, keep_links=False)
        analyst_book = (
            OOXMLWorkbook(analyst_reference_path)
            if analyst_reference_path is not None
            else None
        )
        try:
            for spec in spec_list:
                result = results.get(spec.pivot_id)
                if result is None:
                    continue
                render_pivot_result(wb[spec.sheet], spec, result, analyst_book)
            if chart_list:
                render_charts(wb, chart_list, {spec.pivot_id: spec for spec in spec_list})
            if passthrough_source is not None:
                warnings = copy_pass_through_sheets(passthrough_source, wb)
                if passthrough_warnings is not None:
                    passthrough_warnings.extend(warnings)
            wb.save(output)
        finally:
            wb.close()
            if analyst_book is not None:
                analyst_book.close()
        return output
    except Exception as exc:
        exc.add_note("render_report_workbook failed")
        raise


def report_filename(compact_date: str) -> str:
    """Return the deterministic analyst report filename for a processing date."""
    try:
        return f"REMARKETING_REPOSSESSION_REPORT_{compact_date}.xlsx"
    except Exception as exc:
        raise ReportGenerationError("Unable to create report filename") from exc

def generate_report_artifact(
    *,
    input_path: Path | str,
    output_dir: Path | str,
    report_as_of_date: date,
    processing_date: date,
    reference_dir: Path | str,
    template_path: Path | str,
    full_fidelity: bool = True,
) -> ReportArtifact:
    """Generate the analyst-equivalent report workbook and artifact metadata."""
    try:
        resolved_input = Path(input_path).resolve(strict=True)
        if not resolved_input.is_file() or resolved_input.suffix.lower() != ".xlsx":
            raise ReportGenerationError("Input must be an existing XLSX file")
        resolved_output_dir = Path(output_dir).resolve(strict=True)
        if not resolved_output_dir.is_dir():
            raise ReportGenerationError("Output directory must already exist")

        with WorkbookReader(resolved_input) as source_book:
            inspection = inspect_workbook(
                source_book,
                explicit_as_of=report_as_of_date,
            )
            dataset = extract_remarketing(source_book, inspection)
            kpi_result = build_kpi_result(
                dataset,
                inspection.report_as_of_date,
                source_book,
            )

        specs = list(load_pivot_definitions(reference_dir))
        chart_specs = list(load_chart_definitions(reference_dir))
        results = build_pivot_results(resolved_input, specs)
        output_path = resolved_output_dir / report_filename(
            processing_date.strftime("%Y%m%d")
        )
        output_prefix = os.path.normcase(f"{resolved_output_dir}{os.sep}")
        if not os.path.normcase(str(output_path.resolve())).startswith(output_prefix):
            raise ReportGenerationError("Report path escapes output directory")
        warnings = list(inspection.warnings) + list(kpi_result.warnings)
        passthrough_warnings: list[str] = []
        render_report_workbook(
            template_path,
            specs,
            results,
            output_path,
            chart_specs=chart_specs,
            passthrough_source=resolved_input if full_fidelity else None,
            passthrough_warnings=passthrough_warnings,
            analyst_reference_path=resolved_input,
        )
        warnings.extend(passthrough_warnings)

        workbook = load_workbook(output_path, data_only=False, keep_links=False)
        try:
            render_kpi_result(workbook["KPIs"], kpi_result)
            workbook.save(output_path)
        finally:
            workbook.close()

        return ReportArtifact(
            path=output_path,
            pivot_count=len(specs),
            chart_count=len(chart_specs),
            warnings=tuple(warnings),
            report_as_of_date=inspection.report_as_of_date.isoformat(),
        )
    except Exception as exc:
        if isinstance(exc, ReportGenerationError):
            raise
        raise ReportGenerationError(
            f"Unable to generate report for {input_path}"
        ) from exc
