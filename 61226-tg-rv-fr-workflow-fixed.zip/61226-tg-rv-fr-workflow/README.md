# 61226-tg-rv-fr-workflow — France Remarketing Report Automation

Ford Credit Europe RV process automation, France stream (Remarketing / Repossession
inventory reporting workbook). Mirrors the layout of `cap-rv-uk-workflow`.

## Layout
```
astro/
  dags/       thin orchestration only (watcher + monthly processing)
  include/    pure Python business logic, no Airflow imports (fr_workbook/core/*)
  plugins/    one task callable per file, try/except -> structured XCom error
  tests/      unit tests per module + DAG orchestration tests
  scripts/    run_local.py — run the report on a real file without Airflow
```

## Flow
1. `fr_inventory_file_watcher` (every 2h): previous month then current month;
   skip if `_processed/<month>.done` exists; if `remarketing_YYYY-MM.xlsx` is in
   the input bucket, trigger processing with conf `{gcs_path, month}`.
2. `fr_inventory_monthly_processing`:
   `copy_input` (audit copy to `<month>/<ts>/input/`) → `validate_workbook`
   (workbook / sheet / column) → `generate_report` (xlsx + exceptions csv to
   `<month>/<ts>/output/`, validation vs June 2026 targets) → `finalize_report_run`
   (`latest/` copy + `.done` marker) → `notify` (always runs; SUCCESS to ops,
   FAILURE to ops + FBS contacts in CC; subject contains "workbook reconciliation").

## Local run
```
pip install -r astro/requirements.txt
cd astro && pytest
python scripts/run_local.py ~/Downloads/remarketing_2026-06.xlsx 2026-06
```
Everything French (sheet names, columns, values) stays French — manager decision 9/14.
Column aliases live in `include/constants.py` (`COLUMNS`); validation tells you what
is missing on the first real run.

## Environment
`FR_RV_ENV=dev|prod` selects the recipient list. SMTP goes through Airflow's default
`smtp_default` connection with `from_email=EURVSMTP@FORD.COM`.
