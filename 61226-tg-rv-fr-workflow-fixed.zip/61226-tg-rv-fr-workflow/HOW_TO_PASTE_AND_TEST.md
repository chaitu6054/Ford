# Paste and test

1. Unzip. The folder is the repo root: paste everything into
   61226-tg-rv-fr-workflow on branch feature/fr-monthly-processing.
2. Delete the old files first so the scheduler does not pick them up:
   astro/dags/monthly_processing_dag.py, astro/dags/file_watcher.py,
   astro/include/calculs_france.py, remarketing_airflow_automation/
3. Install and test:
       pip install -r astro/requirements.txt
       cd astro
       pytest
   Expected: 24 passed (includes both DAG orchestration tests).
   If Airflow is not installed locally, 2 DAG tests are skipped; run
   `astro dev start` or `pip install apache-airflow==2.10.5` to run them too.
4. Run on the real June file:
       python scripts/run_local.py <path>/remarketing_2026-06.xlsx 2026-06
   Fix any "Colonnes manquantes" by adding the real header to COLUMNS in
   astro/include/constants.py.
5. .tekton/ and .fossa.yml: copy from the UK repo (see the placeholder files).
