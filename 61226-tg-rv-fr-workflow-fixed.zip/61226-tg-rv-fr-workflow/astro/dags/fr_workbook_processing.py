from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

from include.callbacks import clear_trigger_error, record_trigger_failure
from include.constants import PROCESSING_DAG_ID
from plugins.copy_input_operator import copy_input
from plugins.finalize_report_run_operator import finalize
from plugins.generate_report_operator import generate
from plugins.send_reconciliation_email_operator import notify
from plugins.validate_workbook_operator import validate

default_args = {
    "owner": "fr-rv-automation",
    "retries": 0,
    "retry_delay": timedelta(minutes=5),
    "on_failure_callback": record_trigger_failure,
    "on_success_callback": clear_trigger_error,
}

with DAG(
    dag_id=PROCESSING_DAG_ID,
    description="France remarketing monthly report: copy -> validate -> generate -> finalize -> notify.",
    schedule=None,  # triggered by the watcher with conf {gcs_path, month}
    start_date=datetime(2026, 9, 1),
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    tags=["france", "rv", "processing"],
) as dag:

    copy_input_task = PythonOperator(task_id="copy_input", python_callable=copy_input)
    validate_task = PythonOperator(task_id="validate_workbook", python_callable=validate)
    generate_task = PythonOperator(task_id="generate_report", python_callable=generate)
    finalize_task = PythonOperator(task_id="finalize_report_run", python_callable=finalize)
    notify_task = PythonOperator(
        task_id="notify",
        python_callable=notify,
        trigger_rule=TriggerRule.ALL_DONE,  # always send: success or failure email
    )

    copy_input_task >> validate_task >> generate_task >> finalize_task >> notify_task
