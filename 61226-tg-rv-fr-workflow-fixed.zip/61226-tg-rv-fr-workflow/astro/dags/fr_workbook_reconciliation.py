from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

from include.callbacks import clear_trigger_error, record_trigger_failure
from include.constants import PROCESSING_DAG_ID, WATCHER_DAG_ID
from plugins.fr_workbook_reconciliation_operator import reconcile

default_args = {
    "owner": "fr-rv-automation",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id=WATCHER_DAG_ID,
    description="Every 2h: detect a new France remarketing input file and trigger processing.",
    schedule="0 */2 * * *",
    start_date=datetime(2026, 9, 1),
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    tags=["france", "rv", "watcher"],
) as dag:

    reconcile_task = PythonOperator(
        task_id="reconcile",
        python_callable=reconcile,
        on_failure_callback=record_trigger_failure,
        on_success_callback=clear_trigger_error,
    )

    trigger_processing = TriggerDagRunOperator(
        task_id="trigger_monthly_processing",
        trigger_dag_id=PROCESSING_DAG_ID,
        conf={
            "gcs_path": "{{ ti.xcom_pull(task_ids='reconcile', key='gcs_path') }}",
            "month": "{{ ti.xcom_pull(task_ids='reconcile', key='month') }}",
        },
        wait_for_completion=False,
    )

    reconcile_task >> trigger_processing
