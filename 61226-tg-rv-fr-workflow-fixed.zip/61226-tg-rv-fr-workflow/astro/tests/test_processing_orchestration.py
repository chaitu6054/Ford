import os

import pytest

pytest.importorskip("airflow")

from airflow.models import DagBag  # noqa: E402

DAGS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "dags")


@pytest.fixture(scope="module")
def dagbag():
    return DagBag(dag_folder=DAGS, include_examples=False, read_dags_from_db=False)


def test_no_import_errors(dagbag):
    assert dagbag.import_errors == {}


def test_processing_dag_order(dagbag):
    dag = dagbag.dags.get("fr_inventory_monthly_processing")
    assert dag is not None
    order = ["copy_input", "validate_workbook", "generate_report", "finalize_report_run", "notify"]
    for up, down in zip(order, order[1:]):
        assert down in dag.get_task(up).downstream_task_ids
    assert dag.get_task("notify").trigger_rule == "all_done"
    assert dag.schedule_interval is None


def test_watcher_dag(dagbag):
    dag = dagbag.dags.get("fr_inventory_file_watcher")
    assert dag is not None
    assert "trigger_monthly_processing" in dag.get_task("reconcile").downstream_task_ids
    assert dag.max_active_runs == 1
