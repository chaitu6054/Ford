import os
import sys
from datetime import date

import pytest
from openpyxl import Workbook
from openpyxl.styles import PatternFill

ASTRO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ASTRO not in sys.path:
    sys.path.insert(0, ASTRO)
os.environ.setdefault("FR_RV_ENV", "dev")

ORANGE = "FFC000"
REM_HEADERS = ["VIN", "Restituable", "Vendeur", "Statut", "Etape", "Date de retour", "Date revente",
               "Mois de Vente", "Année de vente", "Valeur revente TTC", "Cote ARGUS prof", "VFMG",
               "Kilométrage", "COUVERT BLESS PAR AN", "quotos", "Montant à facturer le client"]
REPO_HEADERS = ["VIN", "Statut", "Date de retour", "Date revente", "Valeur revente", "Balance US", "Vendeur"]


@pytest.fixture
def sample_workbook(tmp_path):
    """Small French workbook covering the rules: channels, restituable NON, legal hold colour,
    comma decimals, currency strings, FSA list, duplicate VIN."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws.append(["  "])  # title row above the header, like the real file
    ws.append(REM_HEADERS)
    rows = [
        # vin, restituable, vendeur, statut, etape, retour, revente, mois, annee, valeur, cote, vfmg, km, couvert, quotas, montant
        ["V1", "OUI", "Dealer", "Soldé", "E1", date(2026, 5, 10), date(2026, 6, 5), 6, 2026, "16317,49", 18000, 20000, 60000, 15000, 3, 100],
        ["V2", "NC", "BCA", "Solde", "E1", date(2026, 4, 1), date(2026, 6, 20), 6, 2026, "2,026.00 €", 2500, 10000, 30000, 15000, 2, 50],
        ["V3", "NON", "Dealer", "Solde", "E1", date(2026, 5, 1), date(2026, 6, 1), 6, 2026, 9000, 10000, 12000, 1, 1, 1, 0],
        ["V4", "OUI", "", "Stock", "E2", date(2026, 6, 15), None, None, None, None, 8000, 9000, 1, 1, 1, 0],
        ["V5", "OUI", "", "L", "E2", date(2026, 1, 15), None, None, None, None, 8000, 9000, 1, 1, 1, 0],
        ["V6", "OUI", "", "Stock", "E2", date(2026, 3, 1), None, None, None, None, 8000, 9000, 1, 1, 1, 0],
        ["V6", "OUI", "", "Stock", "E2", date(2026, 3, 1), None, None, None, None, "#DIV/0!", 9000, 1, 1, 1, 0],
        ["V7", "OUI", "SICA", "Solde", "E1", date(2026, 2, 1), date(2026, 3, 3), 3, 2026, 7000, 8000, 9000, 1, 1, 1, 10],
    ]
    for r in rows:
        ws.append(r)
    for cell in ws[8]:  # V6 first occurrence -> orange = legal hold via legend
        cell.fill = PatternFill("solid", fgColor=ORANGE)

    ws2 = wb.create_sheet("Repossession")
    ws2.append(REPO_HEADERS)
    ws2.append(["R1", "Solde", date(2026, 6, 2), date(2026, 6, 25), 5000, 7000, "Autorola"])
    ws2.append(["R2", "Stock", date(2026, 6, 20), None, None, 7000, ""])

    ws3 = wb.create_sheet("FSA-UPDATE 24042026")
    ws3.append(["VIN"])
    ws3.append(["V4"])

    ws4 = wb.create_sheet("code couleur")
    ws4.append([None, "dossier en statut L"])
    ws4["A1"].fill = PatternFill("solid", fgColor=ORANGE)

    path = tmp_path / "remarketing_2026-06.xlsx"
    wb.save(path)
    return str(path)
