from datetime import date

from include.fr_workbook.core.rules import (
    AGE_LABELS,
    canal,
    est_legal_hold,
    est_restituable,
    est_vendu,
    tranche_age,
)


def test_restituable_excludes_non_only():
    assert est_restituable("OUI") and est_restituable("NC") and est_restituable("")
    assert not est_restituable("non")


def test_channels():
    assert canal("Dealer") == "Franchised Dealers"
    assert canal("SICA") == "Franchised Dealers"
    for v in ("VP Auto", "BCA", "Autorola", "Concilian"):
        assert canal(v) == "Physical Auctions"
    assert canal("") is None
    assert canal("Inconnu") == "Autre"


def test_sold_status_accent_insensitive():
    assert est_vendu("Solde") and est_vendu("SOLDÉ") and not est_vendu("Stock")


def test_legal_hold_by_status_or_colour():
    assert est_legal_hold("L", None)
    assert est_legal_hold("Stock", "dossier en statut L")
    assert not est_legal_hold("Stock", "FFC000")


def test_age_buckets():
    assert tranche_age(0) == "0-30 Days"
    assert tranche_age(30) == "0-30 Days"
    assert tranche_age(31) == "31-60 Days"
    assert tranche_age(200) == "181-360 Days"
    assert tranche_age(361) == "360+ Days"
    assert AGE_LABELS[-1] == "360+ Days"
