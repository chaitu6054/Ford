from include.fr_workbook.core.report import build_report
from include.fr_workbook.targets import validate_report
from include.fr_workbook.writer import write_report
from include.workbook_validation import validate_workbook


def test_validation_passes_on_sample(sample_workbook):
    summary = validate_workbook(sample_workbook)
    assert not summary["missing_columns"]
    assert summary["sheets"]["remarketing"]["header_row"] == 2


def test_report_channels_and_filters(sample_workbook):
    r = build_report(sample_workbook, "2026-06")
    ch = r.channels.set_index("Canal")
    # V1 (Dealer) sold in June; V3 excluded (NON); V7 sold in March (YTD only)
    assert ch.loc["Franchised Dealers", "Mois"] == 1
    assert ch.loc["Franchised Dealers", "YTD"] == 2
    # V2 (BCA) + R1 (Autorola, repossession sheet)
    assert ch.loc["Physical Auctions", "Mois"] == 2
    assert ch.loc["Total", "Mois"] == 3
    assert ch.loc["Franchised Dealers", "Perf Mois"] == round(16317.49 / 18000, 4)


def test_movements_and_ageing(sample_workbook):
    r = build_report(sample_workbook, "2026-06")
    mv = r.movements_tcm.iloc[0]
    # opening: V1, V2, V5, V6, V6dup (returned before June, unsold at 1 June); V7 sold in March
    assert mv["Stock début"] == 5
    assert mv["Retours"] == 1          # V4
    assert mv["Ventes"] == 2           # V1, V2
    assert mv["Stock fin (calcul)"] == 4 == mv["Stock fin (données)"]
    ag = r.ageing_tcm["tous"].set_index("Tranche")["Nombre"]
    assert ag["Total"] == 4
    assert ag["0-30 Days"] == 1        # V4
    # legal hold: V5 (statut L) and V6 row 8 (orange fill) removed in the third variant
    ag3 = r.ageing_tcm["hors attente encaissement et statut L"].set_index("Tranche")["Nombre"]
    assert ag3["Total"] == 2


def test_fsa_exceptions_and_financials(sample_workbook):
    r = build_report(sample_workbook, "2026-06")
    rem = r.remarketing.set_index("vin", drop=False)
    assert bool(rem.loc["V4", "fsa"]) is True
    assert rem.loc["V1", "frais_retour_2pct"] == 400.0
    assert rem.loc["V1", "km_excedentaires"] == 15000
    assert rem.loc["V1", "perte_profit"] == 500.0
    motifs = set(r.exceptions["motif"])
    assert "#DIV/0!" in motifs and "contrat en double" in motifs


def test_writer_and_validation(sample_workbook, tmp_path):
    r = build_report(sample_workbook, "2026-06")
    v = validate_report(r)
    assert len(v) > 0 and {"attendu", "obtenu", "ecart"} <= set(v.columns)
    out = write_report(r, str(tmp_path / "out.xlsx"), v)
    from openpyxl import load_workbook
    assert set(load_workbook(out).sheetnames) >= {"Synthèse", "Remarketing", "Repossession", "Exceptions", "Validation"}
