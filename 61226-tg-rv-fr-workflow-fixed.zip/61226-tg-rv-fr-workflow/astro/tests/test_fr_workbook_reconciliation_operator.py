from datetime import date
from unittest.mock import MagicMock, patch

import pytest

pytest.importorskip("airflow")

from airflow.exceptions import AirflowSkipException  # noqa: E402

from include import exceptions as ce  # noqa: E402
from plugins import fr_workbook_reconciliation_operator as op  # noqa: E402


def _ctx(day=date(2026, 9, 16)):
    ti = MagicMock()
    ld = MagicMock()
    ld.date.return_value = day
    return {"ti": ti, "logical_date": ld}, ti


def test_candidate_months():
    assert op.candidate_months(date(2026, 9, 16)) == ["2026-08", "2026-09"]
    assert op.candidate_months(date(2026, 1, 5)) == ["2025-12", "2026-01"]


@patch.object(op.gcs, "blob_exists")
def test_reconcile_picks_previous_month(mock_exists):
    ctx, ti = _ctx()
    # marker 2026-08 absent, input 2026-08 present
    mock_exists.side_effect = [False, True]
    with patch.object(op, "get_current_context", return_value=ctx):
        out = op.reconcile()
    assert out["month"] == "2026-08"
    ti.xcom_push.assert_any_call(key="month", value="2026-08")


@patch.object(op.gcs, "blob_exists")
def test_reconcile_skips_when_processed_and_no_file(mock_exists):
    ctx, ti = _ctx()
    # 08 marker present; 09 marker absent, 09 input absent
    mock_exists.side_effect = [True, False, False]
    with patch.object(op, "get_current_context", return_value=ctx):
        with pytest.raises(AirflowSkipException):
            op.reconcile()


@patch.object(op.gcs, "blob_exists", side_effect=RuntimeError("gcs down"))
def test_reconcile_pushes_structured_error(mock_exists):
    ctx, ti = _ctx()
    with patch.object(op, "get_current_context", return_value=ctx):
        with pytest.raises(ce.ProcessedMarkerCheckException):
            op.reconcile()
    pushed = [c.kwargs for c in ti.xcom_push.call_args_list if c.kwargs.get("key") == "error"]
    assert pushed[-1]["value"]["error_code"] == "FR-001"
