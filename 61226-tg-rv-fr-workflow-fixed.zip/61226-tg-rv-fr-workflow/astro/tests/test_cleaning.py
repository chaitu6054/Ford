from datetime import date, datetime

from include.fr_workbook.core.cleaning import to_date, to_number


def test_comma_decimal():
    assert to_number("16317,49") == (16317.49, None)


def test_currency_thousands():
    assert to_number("2,026.00 €") == (2026.0, None)


def test_percent_formatted():
    assert to_number("4528100%") == (45281.0, None)


def test_error_values_flagged():
    val, err = to_number("#DIV/0!")
    assert val is None and err == "#DIV/0!"


def test_excel_serial_date():
    assert to_date(46143) == (date(2026, 5, 1), None)


def test_datetime_and_string_dates():
    assert to_date(datetime(2026, 6, 3, 12)) == (date(2026, 6, 3), None)
    assert to_date("03/06/2026") == (date(2026, 6, 3), None)


def test_date_before_1950_nulled():
    val, err = to_date(date(1900, 1, 1))
    assert val is None and "1950" in err
