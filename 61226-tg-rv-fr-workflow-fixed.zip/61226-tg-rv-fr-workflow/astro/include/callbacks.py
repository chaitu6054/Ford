def record_trigger_failure(context):
    """on_failure_callback: store a structured error on the task instance."""
    ti = context["ti"]
    exc = context.get("exception")
    ti.xcom_push(
        key="error",
        value={
            "task_id": ti.task_id,
            "error_code": getattr(exc, "error_code", "FR-999"),
            "error_message": getattr(exc, "error_message", str(exc)),
        },
    )


def clear_trigger_error(context):
    """on_success_callback: clear an error left by an earlier retry attempt."""
    context["ti"].xcom_push(key="error", value=None)
