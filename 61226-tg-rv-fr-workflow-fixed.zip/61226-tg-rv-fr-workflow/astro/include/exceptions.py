class BaseFRException(Exception):
    """Base for all France inventory workflow exceptions.

    Carries error_code and error_message so operators can push a structured
    error to XCom and the notify task can render it in the email.
    """

    error_code = "FR-000"

    def __init__(self, message):
        super().__init__(message)
        self.error_message = message


class ProcessedMarkerCheckException(BaseFRException):
    error_code = "FR-001"


class InputFileRetrievalException(BaseFRException):
    error_code = "FR-002"


class MissingInputFileException(BaseFRException):
    error_code = "FR-003"


class GcsOperationException(BaseFRException):
    error_code = "FR-004"


class WorkbookValidationException(BaseFRException):
    error_code = "FR-010"


class ReportCalculationException(BaseFRException):
    error_code = "FR-020"


class ReportWriteException(BaseFRException):
    error_code = "FR-030"


class NotificationException(BaseFRException):
    error_code = "FR-040"
