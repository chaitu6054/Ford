from datetime import date

from include.constants import (
    AGE_BUCKETS,
    CANAL_AUTRE,
    CANAUX,
    LEGAL_HOLD_LABEL,
    RESTITUABLE_EXCLUS,
    STATUT_LEGAL,
    STATUTS_VENDU,
)
from include.fr_workbook.core.cleaning import is_blank
from include.fr_workbook.core.reader import normalise_key, strip_accents


def norm(value):
    return strip_accents(str(value)).strip().upper() if not is_blank(value) else ""


def est_restituable(value):
    """Exclude NON only; OUI, NC and blank stay in."""
    return norm(value) not in RESTITUABLE_EXCLUS


def canal(vendeur):
    """Blank Vendeur = not sold -> None. Unknown vendor -> 'Autre'."""
    v = norm(vendeur)
    if not v:
        return None
    return CANAUX.get(v, CANAL_AUTRE)


def est_vendu(statut):
    return norm(statut) in STATUTS_VENDU


def date_vente_effective(date_revente, mois_vente, annee_vente):
    """date revente if present, else first day of Mois/Année de vente."""
    if date_revente is not None:
        return date_revente
    if mois_vente and annee_vente:
        try:
            return date(int(annee_vente), int(mois_vente), 1)
        except ValueError:
            return None
    return None


def dans_periode(d, start, end):
    return d is not None and start <= d <= end


def est_legal_hold(statut, couleur_label):
    if norm(statut) == STATUT_LEGAL:
        return True
    return LEGAL_HOLD_LABEL in normalise_key(couleur_label)


def est_fsa(vin, fsa_vins):
    return normalise_key(vin) in fsa_vins if not is_blank(vin) else False


def age_jours(date_retour, end):
    if date_retour is None:
        return None
    return max((end - date_retour).days, 0)


def bucket_label(lo, hi):
    return f"{lo}-{hi} Days" if hi is not None else f"{lo - 1}+ Days"


AGE_LABELS = [bucket_label(lo, hi) for lo, hi in AGE_BUCKETS]


def tranche_age(age):
    if age is None:
        return None
    for lo, hi in AGE_BUCKETS:
        if age >= lo and (hi is None or age <= hi):
            return bucket_label(lo, hi)
    return AGE_LABELS[-1]
