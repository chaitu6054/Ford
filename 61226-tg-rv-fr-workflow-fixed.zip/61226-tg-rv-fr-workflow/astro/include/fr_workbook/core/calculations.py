import pandas as pd

from include.constants import CANAUX_ORDRE, FRAIS_RETOUR_TAUX
from include.fr_workbook.core.rules import (
    AGE_LABELS,
    age_jours,
    canal,
    dans_periode,
    date_vente_effective,
    est_fsa,
    est_legal_hold,
    est_vendu,
    tranche_age,
)


def _perf(df):
    """Performance vs Market Value = mean of row-level Valeur revente TTC / Cote ARGUS prof."""
    if df.empty:
        return None
    cote = pd.to_numeric(df["cote_argus"], errors="coerce")
    val = pd.to_numeric(df["valeur_revente"], errors="coerce")
    ratio = (val / cote)[(cote > 0) & val.notna()]
    return round(float(ratio.mean()), 4) if len(ratio) else None


def enrich(df, sheet, start, end, fsa_vins, exceptions):
    """Add derived columns to a cleaned Remarketing/Repossession frame (in place)."""
    year_start = start.replace(month=1, day=1)

    df["canal"] = df["vendeur"].map(canal)
    df["vendu"] = df["statut"].map(est_vendu)
    df["date_vente_effective"] = [
        date_vente_effective(d, m, a)
        for d, m, a in zip(df["date_revente"], df["mois_vente"], df["annee_vente"])
    ]
    df["vendu_dans_mois"] = [
        v and dans_periode(d, start, end) for v, d in zip(df["vendu"], df["date_vente_effective"])
    ]
    df["vendu_ytd"] = [
        v and dans_periode(d, year_start, end)
        for v, d in zip(df["vendu"], df["date_vente_effective"])
    ]
    df["retour_dans_mois"] = [dans_periode(d, start, end) for d in df["date_retour"]]
    df["legal_hold"] = [est_legal_hold(s, c) for s, c in zip(df["statut"], df["_couleur"])]
    df["fsa"] = [est_fsa(v, fsa_vins) for v in df["vin"]]

    # in stock at month end = returned by month end and not sold by month end
    df["en_stock_fin_mois"] = [
        (r is not None and r <= end) and not (v and (d is None or d <= end))
        for r, v, d in zip(df["date_retour"], df["vendu"], df["date_vente_effective"])
    ]
    df["age_jours"] = [
        age_jours(r, end) if s else None for r, s in zip(df["date_retour"], df["en_stock_fin_mois"])
    ]
    df["tranche_age"] = df["age_jours"].map(tranche_age)
    df["attente_encaissement"] = False  # TODO: PIVOT tab -> Sold Check 1/2/3 (sold awaiting proceeds)

    # financials (row level)
    vfmg = pd.to_numeric(df["vfmg"], errors="coerce")
    df["frais_retour_2pct"] = (vfmg * FRAIS_RETOUR_TAUX).round(2)
    km = pd.to_numeric(df["kilometrage"], errors="coerce")
    couvert = pd.to_numeric(df["couvert_par_an"], errors="coerce")
    quotas = pd.to_numeric(df["quotas"], errors="coerce")
    df["km_excedentaires"] = (km - couvert * quotas).round(0)
    if sheet == "remarketing":
        montant = pd.to_numeric(df["montant_facturer"], errors="coerce")
        df["perte_profit"] = (df["frais_retour_2pct"] + montant).round(2)
    else:
        balance = pd.to_numeric(df["balance_us"], errors="coerce")
        valeur = pd.to_numeric(df["valeur_revente"], errors="coerce")
        df["perte_profit"] = (balance - valeur).round(2)

    # exceptions: sold without a date, vendor without sale status
    for _, r in df.iterrows():
        if r["vendu"] and r["date_vente_effective"] is None:
            exceptions.append(_exc(sheet, r, "date_revente", None, "vendu sans date de vente"))
        if r["canal"] and not r["vendu"]:
            exceptions.append(_exc(sheet, r, "vendeur", r["vendeur"], "vendeur renseigne mais statut non Solde"))
    return df


def _exc(sheet, row, colonne, valeur, motif):
    return {
        "onglet": sheet,
        "ligne": row.get("_ligne"),
        "vin": row.get("vin"),
        "colonne": colonne,
        "valeur": valeur,
        "motif": motif,
    }


def channels_table(frames):
    """Sales by channel, month and YTD, with performance. frames = [remarketing, repossession]."""
    sold = pd.concat([f[f["vendu"]] for f in frames], ignore_index=True)
    rows = []
    for c in CANAUX_ORDRE:
        m = sold[(sold["canal"] == c) & sold["vendu_dans_mois"]]
        y = sold[(sold["canal"] == c) & sold["vendu_ytd"]]
        rows.append({"Canal": c, "Mois": len(m), "YTD": len(y),
                     "Perf Mois": _perf(m), "Perf YTD": _perf(y)})
    m = sold[sold["vendu_dans_mois"]]
    y = sold[sold["vendu_ytd"]]
    rows.append({"Canal": "Total", "Mois": len(m), "YTD": len(y),
                 "Perf Mois": _perf(m), "Perf YTD": _perf(y)})
    return pd.DataFrame(rows)


def movements_table(df, start, end):
    """Stock début + Retours − Ventes = Stock fin."""
    opening = sum(
        (r is not None and r < start) and not (v and d is not None and d < start)
        for r, v, d in zip(df["date_retour"], df["vendu"], df["date_vente_effective"])
    )
    returns = int(df["retour_dans_mois"].sum())
    sold = int(df["vendu_dans_mois"].sum())
    return pd.DataFrame([{
        "Stock début": opening,
        "Retours": returns,
        "Ventes": sold,
        "Stock fin (calcul)": opening + returns - sold,
        "Stock fin (données)": int(df["en_stock_fin_mois"].sum()),
    }])


def ageing_table(df):
    """Bucket counts + average age for rows in stock at month end."""
    stock = df[df["en_stock_fin_mois"]]
    counts = stock["tranche_age"].value_counts()
    rows = [{"Tranche": lbl, "Nombre": int(counts.get(lbl, 0))} for lbl in AGE_LABELS]
    ages = pd.to_numeric(stock["age_jours"], errors="coerce").dropna()
    rows.append({"Tranche": "Total", "Nombre": int(len(stock))})
    rows.append({"Tranche": "Age moyen", "Nombre": round(float(ages.mean()), 1) if len(ages) else None})
    return pd.DataFrame(rows)


def ageing_variants(df):
    """Three views: all / excluding sold-awaiting-proceeds / excluding also legal hold."""
    return {
        "tous": ageing_table(df),
        "hors attente encaissement": ageing_table(df[~df["attente_encaissement"]]),
        "hors attente encaissement et statut L": ageing_table(
            df[~df["attente_encaissement"] & ~df["legal_hold"]]
        ),
    }
