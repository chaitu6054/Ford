from dataclasses import dataclass, field

import pandas as pd

from include import exceptions as ce
from include.constants import COLUMNS, DATE_COLUMNS, NUMERIC_COLUMNS, SHEETS
from include.fr_workbook.core import calculations as calc
from include.fr_workbook.core.cleaning import is_blank, to_date, to_number, to_text
from include.fr_workbook.core.reader import (
    find_sheet,
    match_columns,
    open_workbook,
    read_colour_legend,
    read_vin_set,
    sheet_to_records,
)
from include.fr_workbook.core.rules import est_restituable
from include.logging_config import get_logger
from include.path_utils import month_bounds

logger = get_logger(__name__)


@dataclass
class ReportResult:
    month: str
    remarketing: pd.DataFrame
    repossession: pd.DataFrame
    channels: pd.DataFrame
    movements_tcm: pd.DataFrame
    movements_or: pd.DataFrame
    ageing_tcm: dict
    ageing_or: dict
    exceptions: pd.DataFrame
    summary: dict = field(default_factory=dict)


def _frame(ws, legend, sheet, exceptions):
    headers, records = sheet_to_records(ws, legend)
    mapping = match_columns(headers, COLUMNS)
    df = pd.DataFrame(records)
    df = df.rename(columns={v: k for k, v in mapping.items()})
    for logical in COLUMNS:
        if logical not in df.columns:
            df[logical] = None
    if "_couleur" not in df.columns:
        df["_couleur"] = None

    def convert(col, fn):
        out = []
        for raw, ligne, vin in zip(df[col], df["_ligne"], df["vin"]):
            val, err = fn(raw)
            if err:
                exceptions.append({"onglet": sheet, "ligne": ligne, "vin": vin,
                                   "colonne": col, "valeur": raw, "motif": err})
            out.append(val)
        return out

    for col in NUMERIC_COLUMNS:
        df[col] = convert(col, to_number)
    for col in DATE_COLUMNS:
        df[col] = convert(col, to_date)
    for col in ("vin", "restituable", "vendeur", "statut", "etape"):
        df[col] = df[col].map(to_text)

    # duplicates: flag, never fix
    dup = df[df["vin"].duplicated(keep=False) & (df["vin"] != "")]
    for _, r in dup.iterrows():
        exceptions.append({"onglet": sheet, "ligne": r["_ligne"], "vin": r["vin"],
                           "colonne": "vin", "valeur": r["vin"], "motif": "contrat en double"})
    # blank Argus on a sold row -> exception (perf cannot be computed)
    for _, r in df.iterrows():
        if is_blank(r["cote_argus"]) and to_text(r["statut"]):
            exceptions.append({"onglet": sheet, "ligne": r["_ligne"], "vin": r["vin"],
                               "colonne": "cote_argus", "valeur": None, "motif": "Cote ARGUS prof vide"})
    return df


def build_report(path, month):
    """Read the French workbook and compute every section of the monthly report."""
    try:
        start, end = month_bounds(month)
        wb = open_workbook(path)
        legend = read_colour_legend(find_sheet(wb, SHEETS["legende"]))
        fsa_vins = read_vin_set(find_sheet(wb, SHEETS["fsa"]))
        exceptions = []

        rem = _frame(find_sheet(wb, SHEETS["remarketing"]), legend, "remarketing", exceptions)
        repo = _frame(find_sheet(wb, SHEETS["repossession"]), legend, "repossession", exceptions)

        rem_all = len(rem)
        rem = rem[rem["restituable"].map(est_restituable)].reset_index(drop=True)
        logger.info(f"Remarketing: {rem_all} rows, {len(rem)} after Restituable filter (NON excluded)")

        rem = calc.enrich(rem, "remarketing", start, end, fsa_vins, exceptions)
        repo = calc.enrich(repo, "repossession", start, end, fsa_vins, exceptions)

        result = ReportResult(
            month=month,
            remarketing=rem,
            repossession=repo,
            channels=calc.channels_table([rem, repo]),
            movements_tcm=calc.movements_table(rem, start, end),
            movements_or=calc.movements_table(repo, start, end),
            ageing_tcm=calc.ageing_variants(rem),
            ageing_or=calc.ageing_variants(repo),
            exceptions=pd.DataFrame(exceptions, columns=["onglet", "ligne", "vin", "colonne", "valeur", "motif"]),
        )
        result.summary = {
            "Lignes Remarketing (après filtre)": len(rem),
            "Lignes Repossession": len(repo),
            "Ventes du mois (tous canaux)": int(result.channels.iloc[-1]["Mois"]),
            "Ventes YTD": int(result.channels.iloc[-1]["YTD"]),
            "Stock fin TCM": int(result.movements_tcm.iloc[0]["Stock fin (calcul)"]),
            "Stock fin O&R": int(result.movements_or.iloc[0]["Stock fin (calcul)"]),
            "Exceptions": len(result.exceptions),
            "Légende couleurs lue": len(legend),
            "VIN FSA": len(fsa_vins),
        }
        logger.info(f"Report built for {month}: {result.summary}")
        return result
    except ce.BaseFRException:
        raise
    except Exception as e:
        logger.error(f"Report calculation failed for {month}: {e}")
        raise ce.ReportCalculationException(f"Report calculation failed for {month}: " + str(e)) from e
