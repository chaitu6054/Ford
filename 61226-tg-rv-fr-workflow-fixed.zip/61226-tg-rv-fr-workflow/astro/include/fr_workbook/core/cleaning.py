import math
import re
from datetime import date, datetime, timedelta

from include.constants import DATE_MIN_YEAR

CURRENCY_RE = re.compile(r"[€$£\s\u00a0]")
ERROR_VALUES = {"#DIV/0!", "#N/A", "#REF!", "#VALUE!", "#NAME?", "#NUM!"}
EXCEL_EPOCH = date(1899, 12, 30)
DATE_FORMATS = ("%d/%m/%Y", "%Y-%m-%d", "%d/%m/%y", "%d-%m-%Y", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S")


def is_blank(value):
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return str(value).strip() == ""


def to_number(value):
    """Returns (float | None, error | None). Handles '16317,49', '2,026.00 €',
    '4528100%', Excel error strings."""
    if is_blank(value):
        return None, None
    if isinstance(value, bool):
        return float(value), None
    if isinstance(value, (int, float)):
        return float(value), None
    s = str(value).strip()
    if s.upper() in ERROR_VALUES:
        return None, s
    percent = s.endswith("%")
    s = CURRENCY_RE.sub("", s.rstrip("%"))
    if "," in s and "." in s:
        s = s.replace(",", "")          # 2,026.00 -> thousands comma
    elif "," in s:
        s = s.replace(",", ".")         # 16317,49 -> decimal comma
    try:
        n = float(s)
    except ValueError:
        return None, f"non numerique: {value}"
    return (n / 100 if percent else n), None


def to_date(value):
    """Returns (date | None, error | None). Handles datetime, Excel serials,
    common FR/ISO strings; dates before DATE_MIN_YEAR are nulled and flagged."""
    if is_blank(value):
        return None, None
    d = None
    if isinstance(value, datetime):
        d = value.date()
    elif isinstance(value, date):
        d = value
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        if 20000 < value < 80000:       # plausible Excel serial (1954..2119)
            d = EXCEL_EPOCH + timedelta(days=int(value))
        else:
            return None, f"serial invalide: {value}"
    else:
        s = str(value).strip()
        for fmt in DATE_FORMATS:
            try:
                d = datetime.strptime(s, fmt).date()
                break
            except ValueError:
                continue
        if d is None:
            return None, f"date illisible: {value}"
    if d.year < DATE_MIN_YEAR:
        return None, f"date avant {DATE_MIN_YEAR}: {d.isoformat()}"
    return d, None


def to_text(value):
    return "" if is_blank(value) else str(value).strip()
