import re
import unicodedata

from openpyxl import load_workbook

from include import exceptions as ce


def strip_accents(text):
    return "".join(
        c for c in unicodedata.normalize("NFKD", str(text)) if not unicodedata.combining(c)
    )


def normalise_key(text):
    """'Cote ARGUS  prof ' -> 'cote argus prof'; None -> ''"""
    if text is None:
        return ""
    return re.sub(r"\s+", " ", strip_accents(text)).strip().lower()


def open_workbook(path):
    try:
        # data_only=True reads cached values; the 25 external links are never followed.
        return load_workbook(path, data_only=True)
    except Exception as e:
        raise ce.WorkbookValidationException(f"Impossible d'ouvrir {path}: " + str(e)) from e


def find_sheet(wb, wanted):
    key = normalise_key(wanted)
    for name in wb.sheetnames:
        n = normalise_key(name)
        if n == key or n.startswith(key):
            return wb[name]
    return None


def find_header_row(ws, anchor="vin", max_scan=15):
    for row in ws.iter_rows(min_row=1, max_row=min(max_scan, ws.max_row)):
        for cell in row:
            if normalise_key(cell.value) == anchor:
                return cell.row
    return 1


def read_headers(ws):
    header_row = find_header_row(ws)
    headers = [normalise_key(c.value) for c in ws[header_row]]
    return headers, header_row


def match_columns(headers, columns):
    """logical -> normalised header actually present. Exact match first, then prefix."""
    mapping = {}
    for logical, aliases in columns.items():
        aliases = [aliases] if isinstance(aliases, str) else aliases
        keys = [normalise_key(a) for a in aliases]
        found = next((h for h in headers if h in keys), None)
        if found is None:
            found = next((h for h in headers for k in keys if h.startswith(k)), None)
        if found:
            mapping[logical] = found
    return mapping


def fill_rgb(cell):
    fill = cell.fill
    if fill is None or fill.fill_type != "solid" or fill.fgColor is None:
        return None
    rgb = fill.fgColor.rgb
    if not isinstance(rgb, str) or rgb in ("00000000", "FFFFFFFF"):
        return None
    return rgb[-6:].upper()


def row_rgb(row, scan=5):
    for cell in row[:scan]:
        rgb = fill_rgb(cell)
        if rgb:
            return rgb
    return None


def read_colour_legend(ws):
    """'code couleur' sheet -> {RGB: label}. A legend row = a filled cell + a text cell."""
    legend = {}
    if ws is None:
        return legend
    for row in ws.iter_rows():
        rgb = row_rgb(row, scan=len(row))
        label = next(
            (c.value.strip() for c in row if isinstance(c.value, str) and c.value.strip()), None
        )
        if rgb and label:
            legend[rgb] = label
    return legend


def sheet_to_records(ws, legend=None):
    """Return (headers, records). Record keys are normalised headers, plus
    '_ligne' (Excel row) and '_couleur' (legend label or raw RGB)."""
    headers, header_row = read_headers(ws)
    records = []
    for row in ws.iter_rows(min_row=header_row + 1):
        values = [c.value for c in row]
        if all(v is None or str(v).strip() == "" for v in values):
            continue
        rec = {h: v for h, v in zip(headers, values) if h}
        rec["_ligne"] = row[0].row
        rgb = row_rgb(row)
        rec["_couleur"] = (legend or {}).get(rgb, rgb)
        records.append(rec)
    return headers, records


def read_vin_set(ws, column="vin"):
    if ws is None:
        return set()
    _, records = sheet_to_records(ws)
    return {normalise_key(r.get(column)) for r in records if r.get(column)}
