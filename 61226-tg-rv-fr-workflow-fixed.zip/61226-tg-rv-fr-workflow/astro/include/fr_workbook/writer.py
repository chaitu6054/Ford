import pandas as pd

from include import exceptions as ce
from include.logging_config import get_logger

logger = get_logger(__name__)

DETAIL_COLUMNS = [
    "_ligne", "vin", "restituable", "vendeur", "canal", "statut", "etape", "_couleur",
    "legal_hold", "fsa", "date_retour", "date_revente", "date_vente_effective", "vendu",
    "vendu_dans_mois", "retour_dans_mois", "en_stock_fin_mois", "age_jours", "tranche_age",
    "attente_encaissement", "valeur_revente", "cote_argus", "vfmg", "frais_retour_2pct",
    "kilometrage", "couvert_par_an", "quotas", "km_excedentaires", "montant_facturer",
    "balance_us", "perte_profit",
]


def _write_block(ws_writer, sheet, df, title, startrow):
    pd.DataFrame([[title]]).to_excel(ws_writer, sheet_name=sheet, startrow=startrow,
                                     index=False, header=False)
    df.to_excel(ws_writer, sheet_name=sheet, startrow=startrow + 1, index=False)
    return startrow + len(df) + 4


def write_report(result, out_path, validation=None):
    """Write the monthly report workbook: Synthèse + detail + exceptions (+ validation)."""
    try:
        with pd.ExcelWriter(out_path, engine="openpyxl") as xw:
            row = 0
            row = _write_block(xw, "Synthèse", result.channels, f"Ventes par canal — {result.month}", row)
            row = _write_block(xw, "Synthèse", result.movements_tcm, "Mouvements TCM (Remarketing)", row)
            row = _write_block(xw, "Synthèse", result.movements_or, "Mouvements O&R (Repossession)", row)
            for label, table in result.ageing_tcm.items():
                row = _write_block(xw, "Synthèse", table, f"Ageing TCM — {label}", row)
            for label, table in result.ageing_or.items():
                row = _write_block(xw, "Synthèse", table, f"Ageing O&R — {label}", row)

            cols = [c for c in DETAIL_COLUMNS if c in result.remarketing.columns]
            result.remarketing[cols].to_excel(xw, sheet_name="Remarketing", index=False)
            cols = [c for c in DETAIL_COLUMNS if c in result.repossession.columns]
            result.repossession[cols].to_excel(xw, sheet_name="Repossession", index=False)
            result.exceptions.to_excel(xw, sheet_name="Exceptions", index=False)
            if validation is not None and len(validation):
                validation.to_excel(xw, sheet_name="Validation", index=False)

            for ws in xw.book.worksheets:
                for col in ws.columns:
                    width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
                    ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 10), 45)
        logger.info(f"Report written: {out_path}")
        return out_path
    except Exception as e:
        logger.error(f"Failed to write report {out_path}: {e}")
        raise ce.ReportWriteException(f"Failed to write report {out_path}: " + str(e)) from e


def write_exceptions(result, out_path):
    try:
        result.exceptions.to_csv(out_path, index=False, sep=";", encoding="utf-8-sig")
        return out_path
    except Exception as e:
        raise ce.ReportWriteException(f"Failed to write exceptions {out_path}: " + str(e)) from e


def write_validation(validation, out_path):
    try:
        validation.to_csv(out_path, index=False, sep=";", encoding="utf-8-sig")
        return out_path
    except Exception as e:
        raise ce.ReportWriteException(f"Failed to write validation {out_path}: " + str(e)) from e
