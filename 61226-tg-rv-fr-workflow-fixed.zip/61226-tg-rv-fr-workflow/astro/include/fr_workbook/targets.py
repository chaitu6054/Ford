import numbers

import pandas as pd

# Validation targets confirmed from the June 2026 report (Soraya, 9/15).
# NOTE: channel totals (136 / 597) include 13 O&R units from the agency file
# (phase 2). Until then the TCM+Repossession-sheet total is expected to be ~123.
TARGETS = {
    "2026-06": {
        "canaux": {
            "Franchised Dealers": {"Mois": 44, "YTD": 175, "Perf Mois": 0.87},
            "Physical Auctions": {"Mois": 92, "YTD": 422, "Perf Mois": 0.82},
            "Total": {"Mois": 136, "YTD": 597},
        },
        "mouvements_tcm": {"Stock début": 295, "Retours": 70, "Ventes": 123, "Stock fin (calcul)": 242},
        "mouvements_or": {"Stock début": 4, "Retours": 22, "Ventes": 13, "Stock fin (calcul)": 13},
        "ageing_tcm": {"0-30 Days": 67, "31-60 Days": 42, "61-90 Days": 36, "91-120 Days": 26,
                       "121-150 Days": 18, "151-180 Days": 10, "181-360 Days": 40,
                       "360+ Days": 3, "Total": 242, "Age moyen": 94},
        "ageing_or": {"0-30 Days": 13, "Age moyen": 11},
    }
}


def _row(section, metric, expected, actual):
    ecart = None
    if isinstance(expected, numbers.Number) and isinstance(actual, numbers.Number):
        ecart = round(float(actual) - float(expected), 4)
    return {"section": section, "metrique": metric, "attendu": expected, "obtenu": actual,
            "ecart": ecart, "ok": ecart == 0 if ecart is not None else None}


def validate_report(result):
    """Compare a ReportResult against TARGETS[month]. Returns a DataFrame (empty if no targets)."""
    targets = TARGETS.get(result.month)
    if not targets:
        return pd.DataFrame(columns=["section", "metrique", "attendu", "obtenu", "ecart", "ok"])
    rows = []

    ch = result.channels.set_index("Canal")
    for canal, metrics in targets["canaux"].items():
        for m, exp in metrics.items():
            got = ch.loc[canal, m] if canal in ch.index else None
            got = round(float(got), 2) if isinstance(got, float) and m.startswith("Perf") else got
            rows.append(_row("canaux", f"{canal} / {m}", exp, got))

    for section, table in (("mouvements_tcm", result.movements_tcm), ("mouvements_or", result.movements_or)):
        for m, exp in targets[section].items():
            rows.append(_row(section, m, exp, int(table.iloc[0][m])))

    for section, ag in (("ageing_tcm", result.ageing_tcm["tous"]), ("ageing_or", result.ageing_or["tous"])):
        idx = ag.set_index("Tranche")["Nombre"]
        for m, exp in targets[section].items():
            got = idx.get(m)
            rows.append(_row(section, m, exp, got))

    df = pd.DataFrame(rows)
    return df
