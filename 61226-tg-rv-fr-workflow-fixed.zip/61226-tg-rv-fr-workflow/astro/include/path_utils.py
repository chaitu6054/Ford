import calendar
import os
from datetime import date

from include.constants import (
    EXCEPTIONS_FILENAME,
    LATEST_PREFIX,
    PROCESSED_PREFIX,
    REPORT_FILENAME,
    VALIDATION_FILENAME,
)

LOCAL_ROOT = os.environ.get("FR_RV_LOCAL_ROOT", "/tmp/fr_rv")


def month_parts(month):
    yyyy, mm = month.split("-")
    return yyyy, mm


def month_bounds(month):
    """'2026-06' -> (date(2026,6,1), date(2026,6,30))"""
    yyyy, mm = (int(p) for p in month_parts(month))
    last = calendar.monthrange(yyyy, mm)[1]
    return date(yyyy, mm, 1), date(yyyy, mm, last)


def run_prefix(month, ts):
    return f"{month}/{ts}"


def input_object(month, ts, filename):
    return f"{run_prefix(month, ts)}/input/{filename}"


def output_object(month, ts, filename):
    return f"{run_prefix(month, ts)}/output/{filename}"


def latest_object(filename):
    return f"{LATEST_PREFIX}/{filename}"


def processed_marker(month):
    return f"{PROCESSED_PREFIX}/{month}.done"


def report_filename(month):
    yyyy, mm = month_parts(month)
    return REPORT_FILENAME.format(mm=mm, yyyy=yyyy)


def exceptions_filename(month):
    return EXCEPTIONS_FILENAME.format(month=month)


def validation_filename(month):
    return VALIDATION_FILENAME.format(month=month)


def local_path(*parts):
    path = os.path.join(LOCAL_ROOT, *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def split_gcs_path(gcs_path):
    """'gs://bucket/a/b.xlsx' -> ('bucket', 'a/b.xlsx')"""
    if not gcs_path.startswith("gs://"):
        raise ValueError(f"Not a gs:// path: {gcs_path}")
    bucket, _, obj = gcs_path[5:].partition("/")
    return bucket, obj
