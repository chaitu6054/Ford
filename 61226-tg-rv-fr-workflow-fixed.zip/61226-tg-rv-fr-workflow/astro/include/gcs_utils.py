from google.cloud import storage

from include import exceptions as ce
from include.logging_config import get_logger

logger = get_logger(__name__)


def _client():
    return storage.Client()


def blob_exists(bucket, obj):
    try:
        return _client().bucket(bucket).blob(obj).exists()
    except Exception as e:
        logger.error(f"Failed to check gs://{bucket}/{obj}: {e}")
        raise ce.GcsOperationException(f"Failed to check gs://{bucket}/{obj}: " + str(e)) from e


def copy_blob(src_bucket, src_obj, dst_bucket, dst_obj):
    try:
        client = _client()
        src = client.bucket(src_bucket)
        src.copy_blob(src.blob(src_obj), client.bucket(dst_bucket), dst_obj)
        logger.info(f"Copied gs://{src_bucket}/{src_obj} -> gs://{dst_bucket}/{dst_obj}")
        return f"gs://{dst_bucket}/{dst_obj}"
    except Exception as e:
        logger.error(f"Failed to copy gs://{src_bucket}/{src_obj}: {e}")
        raise ce.GcsOperationException(f"Failed to copy gs://{src_bucket}/{src_obj}: " + str(e)) from e


def download_blob(bucket, obj, local_path):
    try:
        _client().bucket(bucket).blob(obj).download_to_filename(local_path)
        logger.info(f"Downloaded gs://{bucket}/{obj} -> {local_path}")
        return local_path
    except Exception as e:
        logger.error(f"Failed to download gs://{bucket}/{obj}: {e}")
        raise ce.GcsOperationException(f"Failed to download gs://{bucket}/{obj}: " + str(e)) from e


def upload_file(local_path, bucket, obj):
    try:
        _client().bucket(bucket).blob(obj).upload_from_filename(local_path)
        logger.info(f"Uploaded {local_path} -> gs://{bucket}/{obj}")
        return f"gs://{bucket}/{obj}"
    except Exception as e:
        logger.error(f"Failed to upload {local_path}: {e}")
        raise ce.GcsOperationException(f"Failed to upload {local_path}: " + str(e)) from e


def upload_text(text, bucket, obj):
    try:
        _client().bucket(bucket).blob(obj).upload_from_string(text)
        logger.info(f"Wrote gs://{bucket}/{obj}")
        return f"gs://{bucket}/{obj}"
    except Exception as e:
        logger.error(f"Failed to write gs://{bucket}/{obj}: {e}")
        raise ce.GcsOperationException(f"Failed to write gs://{bucket}/{obj}: " + str(e)) from e


def authenticated_url(bucket, obj):
    return f"https://storage.cloud.google.com/{bucket}/{obj}"
