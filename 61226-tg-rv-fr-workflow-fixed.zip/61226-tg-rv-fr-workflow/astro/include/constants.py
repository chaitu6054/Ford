import os

# ---------------------------------------------------------------- environment
ENV = os.environ.get("FR_RV_ENV", "dev")  # "dev" | "prod"

# ---------------------------------------------------------------- GCS
INPUT_BUCKET = "prj-ml-cap-rv-uk-d-tg-rv-fr-inv-input"
OUTPUT_BUCKET = "prj-ml-cap-rv-uk-d-tg-rv-fr-inv-output"
INPUT_FILE_PATTERN = "remarketing_{month}.xlsx"
PROCESSED_PREFIX = "_processed"
LATEST_PREFIX = "latest"

# ---------------------------------------------------------------- DAGs
WATCHER_DAG_ID = "fr_inventory_file_watcher"
PROCESSING_DAG_ID = "fr_inventory_monthly_processing"

# ---------------------------------------------------------------- email
EMAIL_FROM = "EURVSMTP@FORD.COM"
EMAIL_TO = {
    "dev": ["EURV_FR_OPERATIONS_DEV@FORD.COM"],
    "prod": ["EURV_FR_OPERATIONS_PROD@FORD.COM"],
}[ENV]
# FBS contacts (Soraya, 9/16): included on the warning / failure email.
FBS_CONTACTS = ["abalan7@ford.com", "pcarcass@ford.com"]
EMAIL_WARNING_CC = FBS_CONTACTS
EMAIL_SUBJECT_PREFIX = "France workbook reconciliation"  # must appear in every subject

# ---------------------------------------------------------------- workbook (French, no translation)
SHEETS = {
    "remarketing": "Remarketing",
    "repossession": "Repossession",
    "fsa": "FSA-UPDATE",        # prefix match: "FSA-UPDATE 24042026"
    "legende": "code couleur",
}

# logical name -> accepted French headers. Matched case/accent/whitespace-insensitively.
# Adjust aliases after the first run on the real file (validation lists what is missing).
COLUMNS = {
    "vin": ["VIN"],
    "restituable": ["Restituable"],
    "vendeur": ["Vendeur"],
    "statut": ["Statut"],
    "etape": ["Etape", "Étape"],
    "date_retour": ["Date de retour"],
    "date_revente": ["Date revente", "Date de revente", "date vente"],
    "mois_vente": ["Mois de Vente"],
    "annee_vente": ["Année de vente", "Annee de vente"],
    "valeur_revente": ["Valeur revente TTC", "Valeur revente"],
    "cote_argus": ["Cote ARGUS prof", "Cote argus prof"],
    "vfmg": ["VFMG"],
    "kilometrage": ["Kilométrage", "Kilometrage"],
    "couvert_par_an": ["COUVERT BLESS PAR AN"],
    "quotas": ["quotos", "quotas"],
    "montant_facturer": ["Montant à facturer le client", "Montant a facturer le client"],
    "balance_us": ["Balance US"],
}

REQUIRED_COLUMNS = {
    "remarketing": ["vin", "restituable", "vendeur", "statut", "date_retour",
                    "date_revente", "valeur_revente", "cote_argus"],
    "repossession": ["vin", "statut", "date_retour", "date_revente",
                     "valeur_revente", "balance_us"],
}

NUMERIC_COLUMNS = ["valeur_revente", "cote_argus", "vfmg", "kilometrage",
                   "couvert_par_an", "quotas", "montant_facturer", "balance_us",
                   "mois_vente", "annee_vente"]
DATE_COLUMNS = ["date_retour", "date_revente"]

# ---------------------------------------------------------------- business rules (Soraya 9/15)
RESTITUABLE_EXCLUS = {"NON"}                       # OUI and NC stay in
CANAUX = {
    "DEALER": "Franchised Dealers",
    "SICA": "Franchised Dealers",
    "VP AUTO": "Physical Auctions",
    "BCA": "Physical Auctions",
    "AUTOROLA": "Physical Auctions",
    "CONCILIAN": "Physical Auctions",
}
CANAL_AUTRE = "Autre"
CANAUX_ORDRE = ["Franchised Dealers", "Physical Auctions", CANAL_AUTRE]
STATUTS_VENDU = {"SOLDE"}                          # accents stripped before compare
STATUT_LEGAL = "L"
LEGAL_HOLD_LABEL = "statut l"                      # from code couleur legend, normalised
AGE_BUCKETS = [(0, 30), (31, 60), (61, 90), (91, 120), (121, 150),
               (151, 180), (181, 360), (361, None)]
FRAIS_RETOUR_TAUX = 0.02
DATE_MIN_YEAR = 1950

# ---------------------------------------------------------------- outputs
REPORT_FILENAME = "{mm} {yyyy} France Remarketing Report.xlsx"
EXCEPTIONS_FILENAME = "exceptions_{month}.csv"
VALIDATION_FILENAME = "validation_{month}.csv"
