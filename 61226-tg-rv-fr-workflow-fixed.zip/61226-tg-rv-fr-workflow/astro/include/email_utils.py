from airflow.utils.email import send_email

from include import exceptions as ce
from include.constants import (
    EMAIL_FROM,
    EMAIL_SUBJECT_PREFIX,
    EMAIL_TO,
    EMAIL_WARNING_CC,
    ENV,
)
from include.gcs_utils import authenticated_url
from include.logging_config import get_logger

logger = get_logger(__name__)


def build_subject(month, status):
    return f"{EMAIL_SUBJECT_PREFIX} - {month} - {status} [{ENV.upper()}]"


def _link(bucket, obj):
    if not obj:
        return "—"
    name = obj.split("/")[-1]
    return f"<a href='{authenticated_url(bucket, obj)}' style='color:#1a73e8'>{name}</a>"


def build_success_html(month, run_prefix, bucket, report_obj, exceptions_obj, summary):
    rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in (summary or {}).items())
    return f"""
    <p>France Remarketing report for <b>{month}</b> generated successfully.</p>
    <p>Run: {run_prefix}</p>
    <p>Report: {_link(bucket, report_obj)}<br/>
       Exceptions: {_link(bucket, exceptions_obj)}</p>
    <table border="1" cellpadding="4" style="border-collapse:collapse">{rows}</table>
    """


def build_failure_html(month, run_prefix, errors):
    items = "".join(
        f"<li><b>{e.get('task_id', '?')}</b> [{e.get('error_code', 'FR-999')}]: "
        f"{e.get('error_message', '')}</li>"
        for e in errors
    )
    return f"""
    <p>France Remarketing processing for <b>{month}</b>
       <span style="color:red">FAILED</span>.</p>
    <p>Run: {run_prefix}</p>
    <ul>{items}</ul>
    <p>Please correct the input file and re-upload as
       <code>remarketing_{month}.xlsx</code>; the watcher will pick it up on
       its next 2-hour cycle.</p>
    """


def send(subject, html, warning=False):
    """warning=True adds the FBS contacts (Soraya's request) in CC."""
    cc = EMAIL_WARNING_CC if warning else None
    try:
        send_email(to=EMAIL_TO, cc=cc, subject=subject, html_content=html, from_email=EMAIL_FROM)
        logger.info(f"Email sent to {EMAIL_TO} cc {cc}: {subject}")
    except Exception as e:
        logger.error(f"Failed to send email '{subject}': {e}")
        raise ce.NotificationException(f"Failed to send email '{subject}': " + str(e)) from e
