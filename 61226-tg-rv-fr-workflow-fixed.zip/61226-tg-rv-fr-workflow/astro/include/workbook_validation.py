from include import exceptions as ce
from include.constants import COLUMNS, REQUIRED_COLUMNS, SHEETS
from include.fr_workbook.core.reader import (
    find_sheet,
    match_columns,
    open_workbook,
    read_headers,
)
from include.logging_config import get_logger

logger = get_logger(__name__)


def validate_workbook(path):
    """Three levels: workbook opens -> required sheets present -> required columns present.

    Returns a summary dict. Raises WorkbookValidationException on any hard failure.
    """
    wb = open_workbook(path)  # level 1
    summary = {"sheets": {}, "missing_sheets": [], "missing_columns": {}}

    for key in ("remarketing", "repossession"):  # level 2
        ws = find_sheet(wb, SHEETS[key])
        if ws is None:
            summary["missing_sheets"].append(SHEETS[key])
            continue
        headers, header_row = read_headers(ws)  # level 3
        mapping = match_columns(headers, COLUMNS)
        missing = [c for c in REQUIRED_COLUMNS[key] if c not in mapping]
        summary["sheets"][key] = {
            "name": ws.title,
            "header_row": header_row,
            "rows": ws.max_row - header_row,
            "columns_mapped": len(mapping),
        }
        if missing:
            summary["missing_columns"][key] = [f"{c} (attendu: {COLUMNS[c][0]})" for c in missing]

    for key in ("fsa", "legende"):  # optional, logged
        ws = find_sheet(wb, SHEETS[key])
        summary["sheets"][key] = {"name": ws.title if ws else None, "present": ws is not None}

    if summary["missing_sheets"]:
        raise ce.WorkbookValidationException(
            "Onglets manquants: " + ", ".join(summary["missing_sheets"])
        )
    if summary["missing_columns"]:
        detail = "; ".join(f"{k}: {v}" for k, v in summary["missing_columns"].items())
        raise ce.WorkbookValidationException("Colonnes manquantes: " + detail)

    logger.info(f"Workbook validation passed: {summary}")
    return summary
