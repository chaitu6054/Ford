import os

from airflow.operators.python import get_current_context

from include import exceptions as ce
from include import gcs_utils as gcs
from include.constants import OUTPUT_BUCKET
from include.fr_workbook.core.report import build_report
from include.fr_workbook.targets import validate_report
from include.fr_workbook.writer import write_exceptions, write_report, write_validation
from include.logging_config import get_logger
from include.path_utils import (
    exceptions_filename,
    local_path,
    output_object,
    report_filename,
    validation_filename,
)

logger = get_logger(__name__)


def generate():
    """Build the monthly report, write xlsx + exceptions csv, upload to <run>/output/."""
    context = get_current_context()
    ti = context["ti"]
    try:
        ti.xcom_push(key="error", value=None)
        input_obj = ti.xcom_pull(task_ids="copy_input", key="input_object")
        month = ti.xcom_pull(task_ids="copy_input", key="month")
        ts = context["ts_nodash"]

        local_in = gcs.download_blob(OUTPUT_BUCKET, input_obj, local_path(month, os.path.basename(input_obj)))
        result = build_report(local_in, month)

        validation = validate_report(result)
        if len(validation):
            logger.info("Validation table vs targets:\n" + validation.to_string(index=False))

        report_local = write_report(result, local_path(month, report_filename(month)), validation)
        exc_local = write_exceptions(result, local_path(month, exceptions_filename(month)))
        uploaded = {
            "report_object": output_object(month, ts, report_filename(month)),
            "exceptions_object": output_object(month, ts, exceptions_filename(month)),
        }
        gcs.upload_file(report_local, OUTPUT_BUCKET, uploaded["report_object"])
        gcs.upload_file(exc_local, OUTPUT_BUCKET, uploaded["exceptions_object"])
        if len(validation):
            val_local = write_validation(validation, local_path(month, validation_filename(month)))
            uploaded["validation_object"] = output_object(month, ts, validation_filename(month))
            gcs.upload_file(val_local, OUTPUT_BUCKET, uploaded["validation_object"])

        for k, v in uploaded.items():
            ti.xcom_push(key=k, value=v)
        ti.xcom_push(key="summary", value=result.summary)
        logger.info(f"Report generated for {month}: {uploaded}")
        return uploaded
    except ce.BaseFRException as e:
        logger.error(f"generate_report failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"generate_report failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
