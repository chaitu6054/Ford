from airflow.exceptions import AirflowFailException
from airflow.operators.python import get_current_context

from include import email_utils as email
from include import exceptions as ce
from include.constants import OUTPUT_BUCKET
from include.logging_config import get_logger

logger = get_logger(__name__)

UPSTREAM_TASKS = ["copy_input", "validate_workbook", "generate_report", "finalize_report_run"]


def _collect_errors(ti):
    """Pull structured errors pushed by upstream tasks (from the task body or the failure callback)."""
    errors = []
    for task_id in UPSTREAM_TASKS:
        err = ti.xcom_pull(task_ids=task_id, key="error")
        if err:
            err.setdefault("task_id", task_id)
            errors.append(err)
    return errors


def notify():
    """Runs with trigger_rule=all_done. Success email, or warning email (FBS in CC) on failure."""
    context = get_current_context()
    ti = context["ti"]
    conf = (context["dag_run"].conf or {}) if context.get("dag_run") else {}
    month = ti.xcom_pull(task_ids="copy_input", key="month") or conf.get("month", "?")
    run_prefix = ti.xcom_pull(task_ids="copy_input", key="run_prefix") or context["ts_nodash"]
    try:
        errors = _collect_errors(ti)
        marker = ti.xcom_pull(task_ids="finalize_report_run", key="marker_object")

        if errors or not marker:
            if not errors:
                errors = [{"task_id": "finalize_report_run", "error_code": "FR-999",
                           "error_message": "Run did not complete; see Airflow logs."}]
            email.send(
                email.build_subject(month, "FAILURE"),
                email.build_failure_html(month, run_prefix, errors),
                warning=True,
            )
            raise AirflowFailException(f"Processing failed for {month}: {errors}")

        email.send(
            email.build_subject(month, "SUCCESS"),
            email.build_success_html(
                month, run_prefix, OUTPUT_BUCKET,
                ti.xcom_pull(task_ids="generate_report", key="report_object"),
                ti.xcom_pull(task_ids="generate_report", key="exceptions_object"),
                ti.xcom_pull(task_ids="generate_report", key="summary"),
            ),
        )
        logger.info(f"Success notification sent for {month}.")
        return {"status": "SUCCESS", "month": month}
    except AirflowFailException:
        raise
    except ce.BaseFRException as e:
        logger.error(f"notify failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"notify failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
