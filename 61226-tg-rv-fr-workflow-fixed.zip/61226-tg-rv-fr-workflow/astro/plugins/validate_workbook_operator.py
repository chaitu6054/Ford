import os

from airflow.operators.python import get_current_context

from include import exceptions as ce
from include import gcs_utils as gcs
from include.constants import OUTPUT_BUCKET
from include.logging_config import get_logger
from include.path_utils import local_path
from include.workbook_validation import validate_workbook

logger = get_logger(__name__)


def validate():
    """Download the audit copy and validate workbook / sheets / columns."""
    context = get_current_context()
    ti = context["ti"]
    try:
        ti.xcom_push(key="error", value=None)
        input_obj = ti.xcom_pull(task_ids="copy_input", key="input_object")
        month = ti.xcom_pull(task_ids="copy_input", key="month")
        if not input_obj:
            raise ce.MissingInputFileException("copy_input did not publish input_object")

        local = gcs.download_blob(OUTPUT_BUCKET, input_obj, local_path(month, os.path.basename(input_obj)))
        summary = validate_workbook(local)
        ti.xcom_push(key="validation_summary", value=summary)
        logger.info(f"Validation passed for {month}.")
        return summary
    except ce.BaseFRException as e:
        logger.error(f"validate_workbook failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"validate_workbook failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
