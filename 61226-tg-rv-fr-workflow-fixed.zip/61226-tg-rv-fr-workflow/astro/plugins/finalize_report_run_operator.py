from airflow.operators.python import get_current_context

from include import exceptions as ce
from include import gcs_utils as gcs
from include.constants import OUTPUT_BUCKET
from include.logging_config import get_logger
from include.path_utils import latest_object, processed_marker

logger = get_logger(__name__)


def finalize():
    """Copy outputs to latest/ and write the _processed/<month>.done marker.

    The marker is the last thing written: if anything before it fails, the
    watcher will retry the month on its next cycle.
    """
    context = get_current_context()
    ti = context["ti"]
    try:
        ti.xcom_push(key="error", value=None)
        month = ti.xcom_pull(task_ids="copy_input", key="month")
        run_prefix = ti.xcom_pull(task_ids="copy_input", key="run_prefix")
        report_obj = ti.xcom_pull(task_ids="generate_report", key="report_object")
        exc_obj = ti.xcom_pull(task_ids="generate_report", key="exceptions_object")
        if not report_obj:
            raise ce.ReportWriteException("generate_report did not publish report_object")

        for obj in (report_obj, exc_obj):
            gcs.copy_blob(OUTPUT_BUCKET, obj, OUTPUT_BUCKET, latest_object(obj.split("/")[-1]))
        marker = processed_marker(month)
        gcs.upload_text(f"run={run_prefix}\nreport={report_obj}\n", OUTPUT_BUCKET, marker)

        ti.xcom_push(key="marker_object", value=marker)
        logger.info(f"Run finalized for {month}: marker {marker}")
        return {"marker_object": marker}
    except ce.BaseFRException as e:
        logger.error(f"finalize_report_run failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"finalize_report_run failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
