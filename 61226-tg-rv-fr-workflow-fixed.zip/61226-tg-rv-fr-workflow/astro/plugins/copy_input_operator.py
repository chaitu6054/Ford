import os

from airflow.operators.python import get_current_context

from include import exceptions as ce
from include import gcs_utils as gcs
from include.constants import OUTPUT_BUCKET
from include.logging_config import get_logger
from include.path_utils import input_object, run_prefix, split_gcs_path

logger = get_logger(__name__)


def copy_input():
    """Copy the uploaded file to <month>/<ts>/input/ in the output bucket (audit copy).

    Every downstream task reads from that audit copy, never from the input bucket.
    """
    context = get_current_context()
    ti = context["ti"]
    try:
        ti.xcom_push(key="error", value=None)
        conf = (context["dag_run"].conf or {}) if context.get("dag_run") else {}
        gcs_path, month = conf.get("gcs_path"), conf.get("month")
        if not gcs_path or not month:
            raise ce.MissingInputFileException(
                f"dag_run.conf must contain gcs_path and month, got: {conf}"
            )
        ts = context["ts_nodash"]
        src_bucket, src_obj = split_gcs_path(gcs_path)
        if not gcs.blob_exists(src_bucket, src_obj):
            raise ce.MissingInputFileException(f"Input file no longer present: {gcs_path}")

        dst_obj = input_object(month, ts, os.path.basename(src_obj))
        gcs.copy_blob(src_bucket, src_obj, OUTPUT_BUCKET, dst_obj)

        ti.xcom_push(key="month", value=month)
        ti.xcom_push(key="run_prefix", value=run_prefix(month, ts))
        ti.xcom_push(key="input_object", value=dst_obj)
        logger.info(f"Input copied for {month}: gs://{OUTPUT_BUCKET}/{dst_obj}")
        return {"month": month, "input_object": dst_obj}
    except ce.BaseFRException as e:
        logger.error(f"copy_input failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"copy_input failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
