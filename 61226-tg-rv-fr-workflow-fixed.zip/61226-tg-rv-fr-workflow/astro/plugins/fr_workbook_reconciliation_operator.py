from datetime import date, timedelta

from airflow.exceptions import AirflowSkipException
from airflow.operators.python import get_current_context

from include import exceptions as ce
from include import gcs_utils as gcs
from include.constants import INPUT_BUCKET, INPUT_FILE_PATTERN, OUTPUT_BUCKET
from include.logging_config import get_logger
from include.path_utils import processed_marker

logger = get_logger(__name__)


def candidate_months(run_date=None):
    """[previous month, current month] as YYYY-MM."""
    today = run_date or date.today()
    current_first = today.replace(day=1)
    previous_first = (current_first - timedelta(days=1)).replace(day=1)
    return [previous_first.strftime("%Y-%m"), current_first.strftime("%Y-%m")]


def is_month_processed(month):
    """Check the _processed/<month>.done marker in the output bucket."""
    try:
        exists = gcs.blob_exists(OUTPUT_BUCKET, processed_marker(month))
        logger.info(f"Processed marker for month {month} {'found' if exists else 'not found'}.")
        return exists
    except Exception as e:
        logger.error(f"Failed to check processed marker for month {month}: {e}")
        raise ce.ProcessedMarkerCheckException(
            f"Failed to check processed marker for month {month}: " + str(e)
        ) from e


def find_input_file(month):
    """gs:// path of remarketing_<month>.xlsx in the input bucket, or None."""
    try:
        object_name = INPUT_FILE_PATTERN.format(month=month)
        if not gcs.blob_exists(INPUT_BUCKET, object_name):
            logger.info(f"Input file {object_name} not found for month {month}.")
            return None
        gcs_path = f"gs://{INPUT_BUCKET}/{object_name}"
        logger.info(f"Input file found for month {month}: {gcs_path}")
        return gcs_path
    except Exception as e:
        logger.error(f"Failed to look up input file for month {month}: {e}")
        raise ce.InputFileRetrievalException(
            f"Failed to look up input file for month {month}: " + str(e)
        ) from e


def reconcile():
    """Decide whether a France input file needs processing.

    Previous month first, then current month. Months with a .done marker are
    skipped (don't-run-twice guard). Pushes gcs_path and month to XCom so the
    trigger task can pass them as conf.
    """
    context = get_current_context()
    ti = context["ti"]
    try:
        ti.xcom_push(key="error", value=None)
        logger.info("Starting France inventory workbook reconciliation.")

        run_date = context["logical_date"].date()
        for month in candidate_months(run_date):
            if is_month_processed(month):
                logger.info(f"Month {month} already processed. Skipping.")
                continue
            gcs_path = find_input_file(month)
            if gcs_path:
                ti.xcom_push(key="gcs_path", value=gcs_path)
                ti.xcom_push(key="month", value=month)
                logger.info(f"Reconciliation passed for month {month}. Triggering monthly processing.")
                return {"gcs_path": gcs_path, "month": month}

        raise AirflowSkipException(
            "No unprocessed France input file found for "
            f"{' or '.join(candidate_months(run_date))}. No further action required."
        )

    except AirflowSkipException as e:
        raise e  # downstream tasks are skipped; valid control flow, not an error
    except ce.BaseFRException as e:
        logger.error(f"France workbook reconciliation failed: [{e.error_code}] {e.error_message}")
        ti.xcom_push(key="error", value={"error_code": e.error_code, "error_message": e.error_message})
        raise
    except Exception as e:
        logger.error(f"France workbook reconciliation failed with unexpected error: {e}")
        ti.xcom_push(key="error", value={"error_code": "FR-999", "error_message": str(e)})
        raise
