"""Run the France report locally on a real file, no Airflow / GCS needed.

    python scripts/run_local.py path/to/remarketing_2026-06.xlsx 2026-06 [out_dir]

Prints the validation table against the June 2026 targets and writes the
report xlsx + exceptions csv to out_dir (default ./out).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from include.fr_workbook.core.report import build_report  # noqa: E402
from include.fr_workbook.targets import validate_report  # noqa: E402
from include.fr_workbook.writer import write_exceptions, write_report, write_validation  # noqa: E402
from include.path_utils import exceptions_filename, report_filename, validation_filename  # noqa: E402
from include.workbook_validation import validate_workbook  # noqa: E402


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    path, month = sys.argv[1], sys.argv[2]
    out_dir = sys.argv[3] if len(sys.argv) > 3 else "out"
    os.makedirs(out_dir, exist_ok=True)

    print("== validation du classeur")
    print(validate_workbook(path))

    print("== calcul")
    result = build_report(path, month)
    for k, v in result.summary.items():
        print(f"  {k}: {v}")

    print("\n== ventes par canal")
    print(result.channels.to_string(index=False))
    print("\n== mouvements TCM")
    print(result.movements_tcm.to_string(index=False))
    print("\n== mouvements O&R")
    print(result.movements_or.to_string(index=False))
    print("\n== ageing TCM (tous)")
    print(result.ageing_tcm["tous"].to_string(index=False))

    validation = validate_report(result)
    if len(validation):
        print("\n== validation vs cibles")
        print(validation.to_string(index=False))
        write_validation(validation, os.path.join(out_dir, validation_filename(month)))

    write_report(result, os.path.join(out_dir, report_filename(month)), validation)
    write_exceptions(result, os.path.join(out_dir, exceptions_filename(month)))
    print(f"\n== fichiers écrits dans {out_dir}/")


if __name__ == "__main__":
    main()
