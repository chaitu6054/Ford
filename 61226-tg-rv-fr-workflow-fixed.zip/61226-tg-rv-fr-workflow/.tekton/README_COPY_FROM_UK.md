Copy the pipeline YAML files from cap-rv-uk-workflow/.tekton/ into this folder
and replace the repo name with 61226-tg-rv-fr-workflow. Delete this file after.
