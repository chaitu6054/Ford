from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from datetime import date, datetime

from openpyxl.styles.numbers import is_date_format
from openpyxl.utils.datetime import from_excel

from .errors import ReportDateError, SchemaValidationError
from .models import ExcelError
from .workbook import WorkbookReader

REPORT_CRITICAL_FIELDS = frozenset({
    "Contrat", "VIN", "Statut", "date vente", "Date de retour",
    "Année de Retour", "Mois de retour", "Adhesion Offensive", "Restituable",
    "Code Dealer Origine", "Dealer groupe vh restitue", "Model",
    "Engine (a remplir Risk)", "Finition Risk", "Fuel Type",
    "Kilométrage fait par le client", "Cote ARGUS prof", "Argus Personnalisé",
    "VFMG", "Valeur revente TTC", "Frais à la Vente", "2% Return Fees",
    "Perte/Profit (difference)",
    "Performance vs# Market Value (%) (Cote Argus Prof)",
    "Mois de Vente", "Année de vente", "Vendeur", "Contrat Terms (mois)",
    "COUVERT BLESS PAR AN", "Montant a facturer le client2", "FSA",
    "Sold Check 2", "Sold Check 3", "Stock Age (Sold)", "Stock Age (All)",
    "Stock Age (Unsold)", "Age Bucket (Unsold)",
})

REQUIRED_SHEETS = frozenset({
    "Remarketing", "Pivot Pierre", "Pivot Soraya", "VENTES", "Feuil2", "Feuil3", "KPIs"
})


_DATE_CLASS = date
_DATETIME_CLASS = datetime
_COORD_COL = re.compile(r"^([A-Z]+)")


@dataclass(slots=True)
class WorkbookInspection:
    """Validated workbook schema, report date, warnings, and cached errors."""

    column_by_field: dict[str, str]
    original_header_by_field: dict[str, str]
    report_as_of_date: date
    warnings: list[str]
    critical_errors: list[tuple[str, str, ExcelError]]


def _column_from_coordinate(coordinate: str) -> str:
    try:
        match = _COORD_COL.match(coordinate)
        if not match:
            raise SchemaValidationError(f"invalid cell coordinate '{coordinate}'")
        return match.group(1)
    except Exception:
        raise


def _header_maps(book) -> tuple[dict[str, str], dict[str, str], list[str]]:
    try:
        first_row = next(iter(book.iter_sheet_rows("Remarketing")))
    except StopIteration as exc:
        raise SchemaValidationError("worksheet 'Remarketing' has no header row") from exc
    columns: dict[str, str] = {}
    originals: dict[str, str] = {}
    duplicates: list[str] = []
    for cell in first_row:
        if not isinstance(cell.value, str):
            continue
        original = cell.value
        normalized = original.strip()
        if not normalized:
            continue
        if normalized in columns:
            duplicates.append(normalized)
            continue
        columns[normalized] = _column_from_coordinate(cell.coordinate)
        originals[normalized] = original
    return columns, originals, duplicates


def _resolve_report_date(book, explicit_as_of: date | None, use_system_date: bool) -> date:
    try:
        if explicit_as_of is not None:
            return explicit_as_of
        cell = book.read_cell("KPIs", "C2")
        value = cell.value
        if isinstance(value, _DATETIME_CLASS):
            return value.date()
        if isinstance(value, _DATE_CLASS):
            return value
        if isinstance(value, (int, float)):
            fmt = book.style_number_format(cell.style_id)
            if is_date_format(fmt) or (cell.formula and "TODAY" in cell.formula.upper()):
                converted = from_excel(value)
                return converted.date() if isinstance(converted, _DATETIME_CLASS) else converted
        if use_system_date:
            return date.today()
        raise ReportDateError(
            "report date could not be resolved; provide --as-of-date YYYY-MM-DD"
        )
    except Exception:
        raise


def _critical_errors(
    book,
    column_by_field: dict[str, str],
    required_fields: set[str],
) -> list[tuple[str, str, ExcelError]]:
    try:
        critical_cols = {
            column_by_field[field]
            for field in required_fields
            if field in column_by_field
        }
        errors: list[tuple[str, str, ExcelError]] = []
        for row in book.iter_sheet_rows("Remarketing", min_row=2):
            for cell in row:
                if (
                    _column_from_coordinate(cell.coordinate) in critical_cols
                    and isinstance(cell.value, ExcelError)
                ):
                    errors.append(("Remarketing", cell.coordinate, cell.value))
        return errors
    except Exception:
        raise


def inspect_workbook(
    book: WorkbookReader,
    *,
    required_fields: Iterable[str] | None = None,
    explicit_as_of: date | None = None,
    use_system_date: bool = False,
) -> WorkbookInspection:
    """Inspect required sheets, fields, dates, and cached source errors."""
    try:
        sheets = set(book.sheet_names())
        missing_sheets = sorted(REQUIRED_SHEETS - sheets)
        if missing_sheets:
            quoted = ", ".join(repr(name) for name in missing_sheets)
            raise SchemaValidationError(f"required worksheet(s) missing: {quoted}")

        column_by_field, original_header_by_field, duplicates = _header_maps(book)
        required = set(REPORT_CRITICAL_FIELDS if required_fields is None else required_fields)
        duplicate_required = sorted(required.intersection(duplicates))
        if duplicate_required:
            raise SchemaValidationError(
                "required Remarketing column(s) are duplicated after trimming: "
                + ", ".join(repr(field) for field in duplicate_required)
            )
        missing_fields = sorted(required - set(column_by_field))
        if missing_fields:
            raise SchemaValidationError(
                "required Remarketing column(s) missing: "
                + ", ".join(repr(field) for field in missing_fields)
            )

        return WorkbookInspection(
            column_by_field=column_by_field,
            original_header_by_field=original_header_by_field,
            report_as_of_date=_resolve_report_date(book, explicit_as_of, use_system_date),
            warnings=[
                "duplicate noncritical Remarketing header after trimming: "
                f"{field!r}; using first occurrence"
                for field in sorted(set(duplicates))
                if field not in required
            ],
            critical_errors=_critical_errors(book, column_by_field, required),
        )
    except Exception:
        raise


def validate_workbook_contract(
    input_path: Path | str,
    *,
    required_sheets: Iterable[str],
    explicit_as_of: date | None = None,
    use_system_date: bool = False,
) -> WorkbookInspection:
    """Validate the workbook contract and return its normalized inspection metadata."""
    try:
        with WorkbookReader(input_path) as book:
            missing = sorted(set(required_sheets) - set(book.sheet_names()))
            if missing:
                raise SchemaValidationError(f"required worksheet(s) missing: {missing}")
            return inspect_workbook(
                book,
                explicit_as_of=explicit_as_of,
                use_system_date=use_system_date,
            )
    except SchemaValidationError:
        raise
    except Exception as exc:
        raise SchemaValidationError("Unable to validate workbook contract") from exc
