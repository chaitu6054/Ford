"""Deterministic structural validation for OOXML-preserved report workbooks."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET
from defusedxml.ElementTree import fromstring as safe_fromstring

from .errors import VisualFidelityError
from .fidelity import DOC_REL_NS, MAIN_NS
from .models import VisualFidelityCheck, VisualFidelityResult
from .ooxml_package import OOXMLPackage, relationship_part_name, sha256_bytes

REL_ID_ATTR = f"{{{DOC_REL_NS}}}id"

MARKUP_COMPAT_NS = "http://schemas.openxmlformats.org/markup-compatibility/2006"

_XMLNS_PREFIX_RE = re.compile(r"xmlns:([A-Za-z_][A-Za-z0-9_.-]*)\s*=")
_IGNORABLE_RE = re.compile(r"\b(?:mc:)?Ignorable\s*=\s*\"([^\"]*)\"")
_REQUIRES_RE = re.compile(r"\bRequires\s*=\s*\"([^\"]*)\"")


def _markup_compatibility_prefixes_are_valid(
    package: OOXMLPackage,
) -> tuple[bool, str]:
    try:
        xml_text = package.read_part("xl/workbook.xml").decode(
            "utf-8",
            errors="ignore",
        )
        declared_prefixes = set(_XMLNS_PREFIX_RE.findall(xml_text))
        requested_prefixes: set[str] = set()
        for value in _IGNORABLE_RE.findall(xml_text):
            requested_prefixes.update(part for part in value.split() if part)
        for value in _REQUIRES_RE.findall(xml_text):
            requested_prefixes.update(part for part in value.split() if part)
        missing = sorted(requested_prefixes - declared_prefixes)
        detail = (
            "all markup-compatibility prefixes declared"
            if not missing
            else "undeclared_prefixes=" + ",".join(missing)
        )
        return len(missing) == 0, detail
    except VisualFidelityError:
        raise
    except Exception as exc:
        raise VisualFidelityError(
            "Unable to validate workbook markup-compatibility prefixes"
        ) from exc


@dataclass(frozen=True, slots=True)
class _SheetPart:
    name: str
    state: str
    relationship_id: str
    part_name: str


def _check(name: str, passed: bool, detail: str) -> VisualFidelityCheck:
    try:
        return VisualFidelityCheck(name, "PASS" if passed else "FAIL", detail)
    except Exception as exc:
        raise VisualFidelityError(f"Unable to create fidelity check: {name}") from exc


def _relationship_index(package: OOXMLPackage, source_part: str) -> dict[str, object]:
    try:
        return {item.rel_id: item for item in package.relationships(source_part)}
    except Exception as exc:
        raise VisualFidelityError(
            f"Unable to index relationships for {source_part}"
        ) from exc


def _sheet_parts(package: OOXMLPackage) -> tuple[_SheetPart, ...]:
    try:
        root = safe_fromstring(package.read_part("xl/workbook.xml"))
        parent = root.find(f"{{{MAIN_NS}}}sheets")
        if parent is None:
            raise VisualFidelityError("Workbook has no sheet collection")
        relationships = _relationship_index(package, "xl/workbook.xml")
        values: list[_SheetPart] = []
        for node in parent:
            rel_id = node.attrib.get(REL_ID_ATTR, "")
            relationship = relationships.get(rel_id)
            if relationship is None:
                raise VisualFidelityError(
                    f"Workbook sheet relationship is missing: {rel_id}"
                )
            part = package.resolve_target("xl/workbook.xml", relationship)
            if part is None:
                raise VisualFidelityError(
                    f"Workbook sheet relationship is external: {rel_id}"
                )
            values.append(
                _SheetPart(
                    name=node.attrib.get("name", ""),
                    state=node.attrib.get("state", "visible"),
                    relationship_id=rel_id,
                    part_name=part,
                )
            )
        return tuple(values)
    except VisualFidelityError:
        raise
    except Exception as exc:
        raise VisualFidelityError("Unable to inspect workbook sheets") from exc


def _walk_internal_parts(
    package: OOXMLPackage,
    roots: tuple[str, ...],
) -> frozenset[str]:
    try:
        visited: set[str] = set()
        pending = list(roots)
        while pending:
            part = pending.pop()
            if part in visited:
                continue
            if not package.part_exists(part):
                raise VisualFidelityError(f"Required package part is missing: {part}")
            visited.add(part)
            for relationship in package.relationships(part):
                target = package.resolve_target(part, relationship)
                if target is not None and target not in visited:
                    pending.append(target)
        return frozenset(visited)
    except VisualFidelityError:
        raise
    except Exception as exc:
        raise VisualFidelityError("Unable to traverse retained OOXML graph") from exc


def _hash_part_set(package: OOXMLPackage, parts: frozenset[str]) -> dict[str, str]:
    try:
        return {name: sha256_bytes(package.read_part(name)) for name in sorted(parts)}
    except Exception as exc:
        raise VisualFidelityError("Unable to hash retained OOXML parts") from exc


def _filtered(parts: frozenset[str], prefix: str) -> frozenset[str]:
    try:
        return frozenset(name for name in parts if name.startswith(prefix))
    except Exception as exc:
        raise VisualFidelityError(f"Unable to filter OOXML parts by {prefix}") from exc


def _compare_parts(
    name: str,
    source: OOXMLPackage,
    generated: OOXMLPackage,
    source_parts: frozenset[str],
    generated_parts: frozenset[str],
) -> VisualFidelityCheck:
    try:
        same_names = source_parts == generated_parts
        source_hashes = _hash_part_set(source, source_parts)
        generated_hashes = _hash_part_set(generated, generated_parts)
        passed = same_names and source_hashes == generated_hashes
        return _check(
            name,
            passed,
            f"source_parts={len(source_parts)} generated_parts={len(generated_parts)}",
        )
    except Exception as exc:
        raise VisualFidelityError(f"Unable to compare OOXML group: {name}") from exc


def _theme_parts(package: OOXMLPackage) -> frozenset[str]:
    try:
        return frozenset(
            name for name in package.part_names() if name.startswith("xl/theme/")
        )
    except Exception as exc:
        raise VisualFidelityError("Unable to identify workbook theme parts") from exc


def _relationship_signature(package: OOXMLPackage, part: str) -> tuple[tuple[str, ...], ...]:
    try:
        return tuple(
            (
                relationship.rel_id,
                relationship.rel_type,
                relationship.target,
                relationship.target_mode or "",
            )
            for relationship in package.relationships(part)
        )
    except Exception as exc:
        raise VisualFidelityError(
            f"Unable to inspect relationship signature for {part}"
        ) from exc


def _relationships_are_valid(
    source: OOXMLPackage,
    generated: OOXMLPackage,
    source_parts: frozenset[str],
    generated_parts: frozenset[str],
    generated_sheets: tuple[_SheetPart, ...],
) -> tuple[bool, str]:
    try:
        missing: list[str] = []
        changed: list[str] = []
        for part in sorted(generated_parts):
            for relationship in generated.relationships(part):
                target = generated.resolve_target(part, relationship)
                if target is not None and not generated.part_exists(target):
                    missing.append(f"{part}->{target}")
            if part in source_parts and _relationship_signature(source, part) != (
                _relationship_signature(generated, part)
            ):
                changed.append(part)
        workbook_relationships = generated.relationships("xl/workbook.xml")
        registered = {sheet.relationship_id for sheet in generated_sheets}
        extra_worksheets = [
            item.rel_id
            for item in workbook_relationships
            if item.rel_type.endswith("/worksheet") and item.rel_id not in registered
        ]
        passed = not missing and not changed and not extra_worksheets
        detail = (
            f"missing={len(missing)} changed={len(changed)} "
            f"extra_worksheet_relationships={len(extra_worksheets)}"
        )
        return passed, detail
    except Exception as exc:
        raise VisualFidelityError("Unable to validate relationship integrity") from exc


def _defined_names_are_valid(
    source: OOXMLPackage,
    generated: OOXMLPackage,
    generated_sheets: tuple[_SheetPart, ...],
) -> tuple[bool, str]:
    try:
        source_names = {item.name for item in _sheet_parts(source)}
        retained_names = {item.name for item in generated_sheets}
        root = safe_fromstring(generated.read_part("xl/workbook.xml"))
        parent = root.find(f"{{{MAIN_NS}}}definedNames")
        if parent is None:
            return True, "no defined names"
        invalid: list[str] = []
        for node in parent:
            local = node.attrib.get("localSheetId")
            if local is not None and not 0 <= int(local) < len(generated_sheets):
                invalid.append(node.attrib.get("name", "<unnamed>"))
                continue
            expression = node.text or ""
            for sheet_name in source_names - retained_names:
                quoted = "'" + sheet_name.replace("'", "''") + "'!"
                if quoted in expression or f"{sheet_name}!" in expression:
                    invalid.append(node.attrib.get("name", "<unnamed>"))
                    break
        return not invalid, f"invalid_defined_names={len(invalid)}"
    except Exception as exc:
        raise VisualFidelityError("Unable to validate workbook defined names") from exc


def _calc_chain_is_valid(package: OOXMLPackage) -> tuple[bool, str]:
    try:
        has_part = package.part_exists("xl/calcChain.xml")
        has_relationship = any(
            item.rel_type.endswith("/calcChain")
            for item in package.relationships("xl/workbook.xml")
        )
        content_types = package.read_part("[Content_Types].xml")
        has_override = b"/xl/calcChain.xml" in content_types
        passed = not has_part and not has_relationship and not has_override
        return passed, (
            f"part={has_part} relationship={has_relationship} content_type={has_override}"
        )
    except Exception as exc:
        raise VisualFidelityError("Unable to validate calculation-chain cleanup") from exc


def validate_visual_fidelity(
    source_path: Path | str,
    generated_path: Path | str,
    *,
    visible_sheets: tuple[str, ...],
    technical_sheets: tuple[str, ...],
) -> VisualFidelityResult:
    """Compare source and generated OOXML structures required for visual fidelity."""
    try:
        checks: list[VisualFidelityCheck] = []
        with OOXMLPackage(source_path) as source, OOXMLPackage(generated_path) as generated:
            source_sheets = _sheet_parts(source)
            generated_sheets = _sheet_parts(generated)
            generated_visible = tuple(
                item.name for item in generated_sheets if item.state == "visible"
            )
            expected_technical = set(technical_sheets)
            actual_technical = {
                item.name for item in generated_sheets if item.state == "veryHidden"
            }
            checks.append(
                _check(
                    "visible_sheet_list",
                    generated_visible == visible_sheets,
                    f"visible={generated_visible}",
                )
            )
            checks.append(
                _check(
                    "technical_sheet_state",
                    actual_technical == expected_technical,
                    f"veryHidden={tuple(sorted(actual_technical))}",
                )
            )
            checks.append(
                _check(
                    "registered_sheet_count",
                    len(generated_sheets) == len(visible_sheets) + len(technical_sheets),
                    f"registered={len(generated_sheets)}",
                )
            )
            markup_pass, markup_detail = _markup_compatibility_prefixes_are_valid(
                generated
            )
            checks.append(
                _check(
                    "markup_compatibility_prefixes",
                    markup_pass,
                    markup_detail,
                )
            )
            style_pass = (
                source.part_exists("xl/styles.xml")
                and generated.part_exists("xl/styles.xml")
                and sha256_bytes(source.read_part("xl/styles.xml"))
                == sha256_bytes(generated.read_part("xl/styles.xml"))
            )
            checks.append(_check("styles_sha256", style_pass, "source == generated"))
            checks.append(
                _compare_parts(
                    "theme_sha256",
                    source,
                    generated,
                    _theme_parts(source),
                    _theme_parts(generated),
                )
            )
            source_by_name = {item.name: item for item in source_sheets}
            generated_by_name = {item.name: item for item in generated_sheets}
            retained_names = tuple(item.name for item in generated_sheets)
            source_roots = tuple(source_by_name[name].part_name for name in retained_names)
            generated_roots = tuple(generated_by_name[name].part_name for name in retained_names)
            source_graph = _walk_internal_parts(source, source_roots)
            generated_graph = _walk_internal_parts(generated, generated_roots)
            checks.append(
                _compare_parts(
                    "worksheet_xml_sha256",
                    source,
                    generated,
                    frozenset(source_roots),
                    frozenset(generated_roots),
                )
            )
            for check_name, prefix in (
                ("pivot_parts_sha256", "xl/pivotTables/"),
                ("pivot_cache_parts_sha256", "xl/pivotCache/"),
                ("chart_parts_sha256", "xl/charts/"),
                ("drawing_parts_sha256", "xl/drawings/"),
                ("media_parts_sha256", "xl/media/"),
            ):
                checks.append(
                    _compare_parts(
                        check_name,
                        source,
                        generated,
                        _filtered(source_graph, prefix),
                        _filtered(generated_graph, prefix),
                    )
                )
            relations_pass, relations_detail = _relationships_are_valid(
                source,
                generated,
                source_graph,
                generated_graph,
                generated_sheets,
            )
            checks.append(
                _check("relationship_integrity", relations_pass, relations_detail)
            )
            defined_pass, defined_detail = _defined_names_are_valid(
                source,
                generated,
                generated_sheets,
            )
            checks.append(_check("defined_name_indexes", defined_pass, defined_detail))
            calc_pass, calc_detail = _calc_chain_is_valid(generated)
            checks.append(_check("calc_chain_integrity", calc_pass, calc_detail))
        status = "PASS" if all(item.status == "PASS" for item in checks) else "FAIL"
        return VisualFidelityResult(status=status, checks=tuple(checks), patched_cells=())
    except VisualFidelityError:
        raise
    except Exception as exc:
        raise VisualFidelityError(
            f"Unable to validate visual fidelity for {generated_path}"
        ) from exc
