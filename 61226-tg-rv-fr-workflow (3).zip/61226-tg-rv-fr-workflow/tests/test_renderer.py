from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook


CORE_SHEETS = ["Pivot Pierre", "Pivot Soraya", "VENTES", "Feuil2", "Feuil3", "KPIs"]
TEMPLATE_PATH = Path("config/report_template.xlsx")


def test_template_contains_only_core_report_sheets():
    wb = load_workbook(TEMPLATE_PATH, data_only=False, keep_links=False)
    try:
        assert wb.sheetnames == CORE_SHEETS
    finally:
        wb.close()


def test_template_has_no_external_links_or_formulas():
    wb = load_workbook(TEMPLATE_PATH, data_only=False, keep_links=False)
    try:
        assert not wb._external_links
        for ws in wb.worksheets:
            formulas = [
                cell.coordinate
                for row in ws.iter_rows()
                for cell in row
                if isinstance(cell.value, str) and cell.value.startswith("=")
            ]
            assert formulas == [], f"{ws.title} still contains formulas at {formulas[:10]}"
    finally:
        wb.close()


def test_template_has_no_preexisting_charts():
    wb = load_workbook(TEMPLATE_PATH, data_only=False, keep_links=False)
    try:
        assert sum(len(ws._charts) for ws in wb.worksheets) == 0
    finally:
        wb.close()


def _fake_pivot_spec(*, pivot_id: str = "pivot_pierre_01", sheet: str = "Pivot Pierre", start_cell: str = "A5"):
    from remarketing.calculate import PivotSpec

    return PivotSpec(
        pivot_id=pivot_id,
        sheet=sheet,
        excel_name="fake",
        reference_range="A5:B10",
        start_cell=start_cell,
        row_fields=("Statut",),
        column_fields=(),
        filters=(),
        data_fields=(),
        row_grand_totals=True,
        column_grand_totals=True,
        item_order={},
    )


def test_renderer_writes_pivot_at_manifest_anchor(tmp_path):
    from remarketing.calculate import PivotResult
    from remarketing.report import render_report_workbook

    spec = _fake_pivot_spec()
    result = PivotResult(
        pivot_id=spec.pivot_id,
        matrix=[["Statut", "Nombre de Contrat"], ["A", 2], ["Total général", 2]],
        row_keys=[],
        column_keys=[],
        logical_values={},
    )
    out = render_report_workbook(TEMPLATE_PATH, [spec], {spec.pivot_id: result}, tmp_path / "out.xlsx")
    wb = load_workbook(out, data_only=True, keep_links=False)
    try:
        assert wb["Pivot Pierre"]["A5"].value == "Statut"
        assert wb["Pivot Pierre"]["B7"].value == 2
    finally:
        wb.close()


def test_renderer_rejects_expansion_into_next_report_region_with_required_rows(tmp_path):
    from remarketing.errors import LayoutOverflowError
    from remarketing.calculate import PivotResult
    from remarketing.report import render_report_workbook
    from remarketing.calculate import PivotSpec
    import pytest

    first = PivotSpec(
        pivot_id="first",
        sheet="Pivot Pierre",
        excel_name="first",
        reference_range="A5:B6",
        start_cell="A5",
        row_fields=("Statut",),
        column_fields=(),
        filters=(),
        data_fields=(),
        row_grand_totals=True,
        column_grand_totals=True,
        item_order={},
    )
    second = PivotSpec(
        pivot_id="second",
        sheet="Pivot Pierre",
        excel_name="second",
        reference_range="A8:B10",
        start_cell="A8",
        row_fields=("Statut",),
        column_fields=(),
        filters=(),
        data_fields=(),
        row_grand_totals=True,
        column_grand_totals=True,
        item_order={},
    )
    result = PivotResult(
        pivot_id="first",
        matrix=[["h", "v"], ["a", 1], ["b", 1], ["c", 1], ["total", 3]],
        row_keys=[],
        column_keys=[],
        logical_values={},
    )
    with pytest.raises(LayoutOverflowError) as exc:
        render_report_workbook(TEMPLATE_PATH, [first, second], {"first": result}, tmp_path / "out.xlsx")
    message = str(exc.value)
    assert "first" in message and "second" in message
    assert "requires rows 5:9" in message


def test_renderer_localizes_internal_blank_label_to_analyst_french_label(tmp_path):
    from remarketing.calculate import PivotResult
    from remarketing.report import render_report_workbook

    spec = _fake_pivot_spec()
    result = PivotResult(
        pivot_id=spec.pivot_id,
        matrix=[["Statut", "Nombre de Contrat"], ["(blank)", 2], ["Total général", 2]],
        row_keys=[],
        column_keys=[],
        logical_values={},
    )
    out = render_report_workbook(TEMPLATE_PATH, [spec], {spec.pivot_id: result}, tmp_path / "out.xlsx")
    wb = load_workbook(out, data_only=True, keep_links=False)
    try:
        assert wb["Pivot Pierre"]["A6"].value == "(vide)"
    finally:
        wb.close()
