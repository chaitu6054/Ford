from pathlib import Path

from remarketing.config import load_config
from remarketing.errors import FidelityBuildError, OoxmlRelationshipError, VisualFidelityError
from remarketing.models import RunManifest, RunStatus, VisualFidelityCheck, VisualFidelityResult


def test_config_declares_six_visible_reports_and_remarketing_technical_sheet():
    config = load_config()
    assert config.report_sheets == (
        "Pivot Pierre",
        "Feuil2",
        "Pivot Soraya",
        "VENTES",
        "Feuil3",
        "KPIs",
    )
    assert config.technical_sheets == ("Remarketing",)
    assert config.fidelity_enabled is True


def test_visual_fidelity_result_pass_contract():
    result = VisualFidelityResult(
        status="PASS",
        checks=(VisualFidelityCheck("styles", "PASS", "sha256 matched"),),
    )
    assert result.is_pass is True
    assert result.patched_cells == ()


def test_manifest_serializes_both_reconciliation_verdicts():
    manifest = RunManifest(
        status=RunStatus.SUCCESS,
        processing_date="2026-09-17",
        source_file="client.xlsx",
        source_sha256="abc",
        archived_input="output/2026-09-17/input/client.xlsx",
        report="output/2026-09-17/output/report.xlsx",
        reconciliation="output/2026-09-17/output/reconciliation.xlsx",
        unexplained_mismatch_count=0,
        business_reconciliation="PASS",
        visual_fidelity="PASS",
    )
    restored = RunManifest.from_json(manifest.to_json())
    assert restored.business_reconciliation == "PASS"
    assert restored.visual_fidelity == "PASS"


def test_fidelity_errors_are_domain_errors():
    assert issubclass(FidelityBuildError, Exception)
    assert issubclass(OoxmlRelationshipError, Exception)
    assert issubclass(VisualFidelityError, Exception)
