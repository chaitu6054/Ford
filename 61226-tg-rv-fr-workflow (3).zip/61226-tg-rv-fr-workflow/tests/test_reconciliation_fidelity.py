from openpyxl import Workbook, load_workbook

from remarketing.models import VisualFidelityCheck, VisualFidelityResult
from remarketing.reconcile import append_visual_fidelity_sheet


def test_visual_fidelity_sheet_contains_required_verdicts(tmp_path):
    try:
        path = tmp_path / "reconciliation.xlsx"
        workbook = Workbook()
        workbook.save(path)
        workbook.close()
        result = VisualFidelityResult(
            status="PASS",
            checks=(
                VisualFidelityCheck("styles_sha256", "PASS", "source == generated"),
                VisualFidelityCheck(
                    "chart_parts_sha256",
                    "PASS",
                    "all retained chart parts matched",
                ),
            ),
        )
        append_visual_fidelity_sheet(
            path,
            result,
            source_name="client.xlsx",
            generated_name="report.xlsx",
        )
        workbook = load_workbook(path, data_only=False)
        try:
            sheet = workbook["Visual Fidelity"]
            assert sheet["B1"].value == "PASS"
            assert sheet["B2"].value == "client.xlsx"
            assert sheet["B3"].value == "report.xlsx"
            assert sheet["A6"].value == "styles_sha256"
            assert sheet.freeze_panes == "A6"
        finally:
            workbook.close()
    except Exception:
        raise
