from __future__ import annotations

import os
from pathlib import Path

import pytest
from openpyxl import load_workbook
from openpyxl.chart import BarChart, LineChart, PieChart

from remarketing.pipeline import generate_pivot_report
from remarketing.calculate import load_chart_definitions

REFERENCE = Path(os.environ.get("REFERENCE_WORKBOOK", "/mnt/data/REMARKETING_ET_REPOSSESSION_copy24072026.xlsx"))
TEMPLATE = Path("config/report_template.xlsx")


def test_chart_manifest_distribution_and_source_visual_metadata():
    specs = load_chart_definitions()
    assert len([x for x in specs if x.sheet == "Pivot Soraya"]) == 5
    assert len([x for x in specs if x.sheet == "VENTES"]) == 2

    line = next(x for x in specs if x.chart_id == "pivot_soraya_chart_01")
    assert line.chart_type == "lineChart"
    assert line.anchor == "L1"
    assert line.legend_position == "r"
    assert line.width_cm > 0
    assert line.height_cm > 0

    stacked = next(x for x in specs if x.chart_id == "pivot_soraya_chart_03")
    assert stacked.bar_direction == "col"
    assert stacked.grouping == "stacked"
    assert stacked.gap_width == 150
    assert stacked.overlap == 100
    assert stacked.legend_position == "b"

    seller = next(x for x in specs if x.chart_id == "ventes_chart_01")
    assert seller.bar_direction == "bar"
    assert seller.grouping == "clustered"
    assert seller.gap_width == 182
    assert len(seller.series) == 5
    assert all(series.category_offsets is None for series in seller.series)


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_renderer_creates_all_seven_charts_with_expected_types(tmp_path):
    output = generate_pivot_report(REFERENCE, TEMPLATE, tmp_path / "charts.xlsx")
    wb = load_workbook(output, data_only=False, keep_links=False)
    try:
        soraya = wb["Pivot Soraya"]._charts
        ventes = wb["VENTES"]._charts
        assert len(soraya) == 5
        assert len(ventes) == 2
        assert isinstance(soraya[0], LineChart)
        assert isinstance(soraya[1], PieChart)
        assert all(isinstance(chart, BarChart) for chart in soraya[2:])
        assert all(isinstance(chart, BarChart) for chart in ventes)
        assert ventes[0].type == "bar"
        assert ventes[1].type == "col"
    finally:
        wb.close()


def test_chart_factory_rejects_unsupported_chart_type():
    from dataclasses import replace

    from remarketing.report import create_chart
    from remarketing.errors import PivotDefinitionError
    from remarketing.calculate import load_pivot_definitions

    spec = replace(load_chart_definitions()[0], chart_type="areaChart")
    pivots = {pivot.pivot_id: pivot for pivot in load_pivot_definitions()}
    wb = load_workbook(TEMPLATE, data_only=False, keep_links=False)
    try:
        with pytest.raises(PivotDefinitionError, match="unsupported chart type"):
            create_chart(wb[spec.sheet], spec, pivots)
    finally:
        wb.close()
