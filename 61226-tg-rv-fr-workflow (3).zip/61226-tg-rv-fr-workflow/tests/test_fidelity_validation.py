from pathlib import Path
from zipfile import ZipFile

from remarketing.fidelity import build_fidelity_workbook
from remarketing.fidelity_validate import validate_visual_fidelity
from test_fidelity_builder import _write_fixture


def _replace_part(path: Path, part_name: str, value: bytes) -> None:
    try:
        replacement = path.with_suffix(".replacement.xlsx")
        with ZipFile(path, "r") as source, ZipFile(replacement, "w") as target:
            for info in source.infolist():
                target.writestr(info, value if info.filename == part_name else source.read(info.filename))
        replacement.replace(path)
    except Exception:
        raise


def test_fidelity_validation_passes_for_unmodified_retained_parts(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        result = validate_visual_fidelity(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        assert result.status == "PASS"
        assert result.is_pass is True
        assert {check.name for check in result.checks} == {
            "visible_sheet_list",
            "technical_sheet_state",
            "registered_sheet_count",
            "markup_compatibility_prefixes",
            "styles_sha256",
            "theme_sha256",
            "worksheet_xml_sha256",
            "pivot_parts_sha256",
            "pivot_cache_parts_sha256",
            "chart_parts_sha256",
            "drawing_parts_sha256",
            "media_parts_sha256",
            "relationship_integrity",
            "defined_name_indexes",
            "calc_chain_integrity",
        }
    except Exception:
        raise


def test_fidelity_validation_fails_when_style_bytes_change(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        _replace_part(output, "xl/styles.xml", b"styles-mutated")
        result = validate_visual_fidelity(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        assert result.status == "FAIL"
        check = next(item for item in result.checks if item.name == "styles_sha256")
        assert check.status == "FAIL"
    except Exception:
        raise


def test_fidelity_validation_fails_when_markup_compatibility_prefix_is_undeclared(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        with ZipFile(source) as archive:
            workbook = archive.read("xl/workbook.xml")
        workbook = workbook.replace(
            b'<workbook ',
            b'<workbook xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
            b'mc:Ignorable="x15" '
            b'xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main" ',
            1,
        ).replace(
            b'<bookViews>',
            b'<mc:AlternateContent><mc:Choice Requires="x15"/></mc:AlternateContent><bookViews>',
            1,
        )
        _replace_part(source, "xl/workbook.xml", workbook)
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        with ZipFile(output) as archive:
            generated = archive.read("xl/workbook.xml")
        generated = generated.replace(
            b' xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main"',
            b'',
            1,
        )
        _replace_part(output, "xl/workbook.xml", generated)
        result = validate_visual_fidelity(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        assert result.status == "FAIL"
        check = next(
            item for item in result.checks if item.name == "markup_compatibility_prefixes"
        )
        assert check.status == "FAIL"
        assert "x15" in check.detail
    except Exception:
        raise
