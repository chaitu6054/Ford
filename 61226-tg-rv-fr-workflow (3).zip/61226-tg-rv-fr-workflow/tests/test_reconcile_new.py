from remarketing.reconcile import compare_values

def test_compare_values_matches_equal_currency_values():
    result = compare_values(1000.0, 1000, analyst_number_format='# ##0,00 €')
    assert result.status == 'MATCH'
