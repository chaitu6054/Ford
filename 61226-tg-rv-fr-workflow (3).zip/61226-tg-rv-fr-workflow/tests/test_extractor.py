from __future__ import annotations

from datetime import date
import os
from pathlib import Path

import pytest

from remarketing.normalize import extract_remarketing, normalize_excel_value
from remarketing.validate import inspect_workbook
from remarketing.models import ExcelError
from remarketing.workbook import OOXMLCell, OOXMLWorkbook


def test_numeric_looking_contract_is_not_coerced_when_source_is_text():
    cell = OOXMLCell("A2", "000123", None, 0, "s")
    assert normalize_excel_value("Contrat", cell) == "000123"


def test_known_date_field_converts_excel_serial():
    cell = OOXMLCell("I2", 46281, None, 14, None)
    assert normalize_excel_value("Date de retour", cell) == date(2026, 9, 16)


def test_excel_error_survives_normalization():
    error = ExcelError("#N/A")
    cell = OOXMLCell("BT2", error, None, 0, "e")
    assert normalize_excel_value("FSA", cell) == error


def test_blank_cell_is_none():
    assert normalize_excel_value("Model", OOXMLCell("AI2", None, None, 0, None)) is None


def test_duplicate_rows_are_not_deduplicated(tmp_path: Path):
    from openpyxl import Workbook

    path = tmp_path / "dup.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    headers = ["Contrat ", "VIN", "Statut ", "Model "]
    ws.append(headers)
    ws.append(["0001", "VIN1", "Stock", "PUMA"])
    ws.append(["0001", "VIN1", "Stock", "PUMA"])
    for name in ("Pivot Pierre", "Pivot Soraya", "VENTES", "Feuil2", "Feuil3", "KPIs"):
        wb.create_sheet(name)
    wb["KPIs"]["C2"] = date(2026, 7, 24)
    wb.save(path)

    book = OOXMLWorkbook(path)
    inspection = inspect_workbook(book, required_fields={"Contrat", "VIN", "Statut", "Model"})
    dataset = extract_remarketing(book, inspection)
    assert len(dataset.rows) == 2
    assert dataset.rows[0]["Contrat"] == "0001"
    assert dataset.rows[1]["Contrat"] == "0001"


def test_actual_workbook_shape_when_fixture_is_available():
    value = os.environ.get("REFERENCE_WORKBOOK")
    if not value:
        pytest.skip("set REFERENCE_WORKBOOK to run client workbook extractor assertion")
    path = Path(value)
    book = OOXMLWorkbook(path)
    inspection = inspect_workbook(book)
    dataset = extract_remarketing(book, inspection)
    # Rows 1027+ in the reference workbook are formula-only template rows with no key fields.
    assert 1000 <= len(dataset.rows) <= 1100
    assert dataset.original_headers["Contrat"] == "Contrat "
    assert dataset.original_headers["Statut"] == "Statut "
    assert dataset.original_headers["Model"] == "Model "
