from pathlib import Path


def test_readme_documents_both_production_and_local_flows():
    try:
        text=Path('README.md').read_text(encoding='utf-8')
        assert 'remarketing_file_watcher_dag' in text
        assert 'remarketing_processing_dag' in text
        assert 'python local/run_local.py' in text
        assert 'output/<processing-date>/input/' in text
        assert 'output/<processing-date>/output/' in text
    except Exception:
        raise


def test_readme_documents_exact_visual_fidelity_contract():
    try:
        readme = Path("README.md").read_text(encoding="utf-8")
        runbook = Path("docs/GCS_PRODUCTION_RUNBOOK.md").read_text(encoding="utf-8")
        combined = readme + "\n" + runbook
        required = (
            "six visible analyst-facing sheets",
            "Remarketing is veryHidden",
            "final workbook is built from the uploaded XLSX OOXML package",
            "openpyxl is not used to serialize the final client workbook",
            "business reconciliation and visual fidelity must both PASS",
            "external links are never refreshed by the application",
        )
        for phrase in required:
            assert phrase in combined
    except Exception:
        raise
