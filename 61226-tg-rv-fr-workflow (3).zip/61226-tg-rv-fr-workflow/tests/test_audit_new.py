from remarketing.audit import sha256_file

def test_sha_changes(tmp_path):
    p=tmp_path/'x'; p.write_bytes(b'a'); a=sha256_file(p); p.write_bytes(b'b'); assert sha256_file(p)!=a
