from __future__ import annotations

from remarketing.models import Dataset, ExcelError
from remarketing.calculate import aggregate, run_pivot
from remarketing.calculate import DataFieldSpec, FilterSpec, PivotSpec


def ds(rows):
    headers = tuple(rows[0].keys()) if rows else ()
    return Dataset(headers, {h: h for h in headers}, rows)


def spec(*, rows=("Group",), cols=(), filters=(), data=None, row_total=True, col_total=True, order=None):
    if data is None:
        data = (DataFieldSpec("Value", "count", "Count of Value", None),)
    return PivotSpec(
        pivot_id="p1", sheet="S", excel_name="Pivot", reference_range="A1:Z99", start_cell="A1",
        row_fields=tuple(rows), column_fields=tuple(cols), filters=tuple(filters), data_fields=tuple(data),
        row_grand_totals=row_total, column_grand_totals=col_total, item_order=order or {},
    )


def test_count_counts_nonblank_source_values_only():
    assert aggregate([1, None, ExcelError("#N/A"), "x"], "count") == 3


def test_sum_ignores_blank_and_excel_error_numeric_values():
    assert aggregate([1, 2.5, None, ExcelError("#N/A"), "3", True], "sum") == 3.5


def test_average_uses_numeric_values_only():
    assert aggregate([1, 3, None, ExcelError("#N/A"), "5"], "average") == 2


def test_blank_group_label_is_excel_blank_caption():
    result = run_pivot(ds([{"Group": None, "Value": 1}]), spec())
    assert result.row_keys == [("(blank)",)]


def test_excel_error_can_be_a_group_item():
    result = run_pivot(ds([{"Group": ExcelError("#N/A"), "Value": 1}]), spec())
    assert result.row_keys == [("#N/A",)]


def test_multiselect_filter_excludes_hidden_items():
    rows = [
        {"Group": "A", "Status": "Hidden", "Value": 1},
        {"Group": "A", "Status": "Visible", "Value": 2},
        {"Group": "A", "Status": "New", "Value": 3},
    ]
    flt = FilterSpec("Status", None, ("Hidden",), True)
    result = run_pivot(ds(rows), spec(filters=(flt,)))
    assert result.logical_values[(('A',), (), 'Count of Value')] == 2


def test_saved_item_order_precedes_new_items():
    rows = [{"Group": x, "Value": 1} for x in ("A", "B", "D", "C")]
    result = run_pivot(ds(rows), spec(order={"Group": ("B", "A")}))
    assert result.row_keys == [("B",), ("A",), ("C",), ("D",)]


def test_new_items_append_after_saved_items_in_stable_text_order():
    rows = [{"Group": x, "Value": 1} for x in ("z", "A", "b")]
    result = run_pivot(ds(rows), spec(order={"Group": ("A",)}))
    assert result.row_keys == [("A",), ("b",), ("z",)]


def test_row_and_column_grand_totals_are_generated():
    rows = [
        {"Group": "A", "Month": 1, "Value": 1},
        {"Group": "A", "Month": 2, "Value": 1},
        {"Group": "B", "Month": 1, "Value": 1},
    ]
    result = run_pivot(ds(rows), spec(cols=("Month",)))
    assert result.matrix[-1][0] == "Total général"
    assert result.matrix[-1][-1] == 3
    assert result.matrix[1][-1] == "Total général"


def test_duplicate_source_rows_are_counted_separately():
    row = {"Group": "A", "Value": "x"}
    result = run_pivot(ds([row.copy(), row.copy()]), spec())
    assert result.logical_values[(('A',), (), 'Count of Value')] == 2


def test_percent_of_column_show_data_as_is_applied():
    rows = [
        {"Group": "A", "Fuel": "Petrol", "Value": 1},
        {"Group": "A", "Fuel": "Petrol", "Value": 2},
        {"Group": "B", "Fuel": "Petrol", "Value": 3},
        {"Group": "B", "Fuel": "Electric", "Value": 4},
    ]
    data = (DataFieldSpec("Value", "count", "Share", "0.00%", "percentOfCol"),)
    result = run_pivot(ds(rows), spec(cols=("Fuel",), data=data))
    assert result.logical_values[(('A',), ('Petrol',), 'Share')] == 2 / 3
    assert result.logical_values[(('B',), ('Electric',), 'Share')] == 1


def test_hierarchical_rows_include_parent_subtotal_before_children():
    rows = [
        {"Year": 2026, "Month": 1, "Value": 1},
        {"Year": 2026, "Month": 2, "Value": 1},
        {"Year": 2025, "Month": 12, "Value": 1},
    ]
    result = run_pivot(ds(rows), spec(rows=("Year", "Month"), order={"Year": ("2026", "2025"), "Month": ("1", "2", "12")}))
    assert result.row_keys == [("2026",), ("2026", "1"), ("2026", "2"), ("2025",), ("2025", "12")]
    assert result.logical_values[(('2026',), (), 'Count of Value')] == 2


def test_missing_row_column_intersection_is_blank_not_zero():
    rows = [
        {"Group": "A", "Month": 1, "Value": "x"},
        {"Group": "B", "Month": 2, "Value": "x"},
    ]
    result = run_pivot(ds(rows), spec(cols=("Month",)))
    assert result.logical_values[(("A",), ("2",), "Count of Value")] is None


def test_existing_intersection_with_blank_count_source_is_zero():
    rows = [{"Group": "A", "Month": 1, "Value": None}]
    result = run_pivot(ds(rows), spec(cols=("Month",)))
    assert result.logical_values[(("A",), ("1",), "Count of Value")] == 0


def test_existing_intersection_with_blank_sum_source_is_zero():
    rows = [{"Group": "A", "Month": 1, "Value": None}]
    data = (DataFieldSpec("Value", "sum", "Sum of Value", None),)
    result = run_pivot(ds(rows), spec(cols=("Month",), data=data))
    assert result.logical_values[(("A",), ("1",), "Sum of Value")] == 0


def test_multi_data_outer_columns_emit_three_excel_header_rows():
    rows = [
        {"Group": "A", "Fuel": "E85", "Value": 10, "Other": 1},
        {"Group": "A", "Fuel": "Electric", "Value": 20, "Other": 2},
    ]
    data = (
        DataFieldSpec("Value", "sum", "Sum of Value", None),
        DataFieldSpec("Other", "count", "Count of Other", None),
    )
    base = spec(cols=("Fuel",), data=data, order={"Fuel": ("E85", "Electric")})
    outer = PivotSpec(
        pivot_id=base.pivot_id,
        sheet=base.sheet,
        excel_name=base.excel_name,
        reference_range=base.reference_range,
        start_cell=base.start_cell,
        row_fields=base.row_fields,
        column_fields=base.column_fields,
        filters=base.filters,
        data_fields=base.data_fields,
        row_grand_totals=base.row_grand_totals,
        column_grand_totals=base.column_grand_totals,
        item_order=base.item_order,
        data_fields_outer=True,
    )
    result = run_pivot(ds(rows), outer)
    assert result.matrix[:3] == [
        [None, "Étiquettes de colonnes", None, None, None, None, None],
        [None, "Sum of Value", None, "Count of Other", None, "Total Sum of Value", "Total Count of Other"],
        ["Étiquettes de lignes", "E85", "Electric", "E85", "Electric", None, None],
    ]


def test_percent_of_column_missing_intersection_is_zero_percent_when_column_has_data():
    rows = [
        {"Group": "A", "Fuel": "E85", "Value": 1},
        {"Group": "B", "Fuel": "Electric", "Value": 2},
    ]
    data = (DataFieldSpec("Value", "count", "Share", "0.00%", "percentOfCol"),)
    result = run_pivot(ds(rows), spec(cols=("Fuel",), data=data))
    assert result.logical_values[(("A",), ("Electric",), "Share")] == 0
