from remarketing.calculate import aggregate


def test_aggregate_sum_ignores_none():
    assert aggregate([10, None, 5], 'sum') == 15


def test_aggregate_count_counts_non_empty_values():
    assert aggregate(['A', None, 'B'], 'count') == 2
