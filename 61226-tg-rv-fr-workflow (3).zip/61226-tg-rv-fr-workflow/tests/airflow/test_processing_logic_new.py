import pytest
from remarketing.errors import ConfigurationError
from dags.remarketing_processing_dag import resolve_processing_request


def test_requires_generation():
    with pytest.raises(ConfigurationError): resolve_processing_request({'bucket_name':'b','object_name':'input/a.xlsx','detection_timestamp':'x'})

def test_request_exact_identity():
    r=resolve_processing_request({'bucket_name':'b','object_name':'input/a.xlsx','generation':42,'detection_timestamp':'x'})
    assert r['generation']==42 and r['object_name']=='input/a.xlsx'


def test_processing_uses_detection_date_as_stable_processing_date(monkeypatch):
    import dags.remarketing_processing_dag as module
    from datetime import date

    captured = {}

    class Result:
        def to_dict(self):
            return {"status": "SUCCESS"}

    def fake_process_gcs_object(**kwargs):
        captured.update(kwargs)
        return Result()

    monkeypatch.setattr(module, "process_gcs_object", fake_process_gcs_object)
    request = {
        "bucket_name": "bucket",
        "object_name": "input/client.xlsx",
        "generation": 42,
        "size": 100,
        "detection_timestamp": "2026-09-17T23:59:59+00:00",
    }

    result = module.process_remarketing_workbook(request)

    assert result == {"status": "SUCCESS"}
    assert captured["processing_date"] == date(2026, 9, 17)


def test_processing_dag_does_not_implement_excel_fidelity_logic():
    from pathlib import Path

    source = Path("astro/dags/remarketing_processing_dag.py").read_text(encoding="utf-8")
    assert "process_gcs_object" in source
    assert "zipfile" not in source
    assert "openpyxl" not in source
    assert "fidelity.py" not in source
