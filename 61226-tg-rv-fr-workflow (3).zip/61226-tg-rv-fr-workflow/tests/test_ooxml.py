from __future__ import annotations

from pathlib import Path
import tempfile
import zipfile
from xml.etree import ElementTree as ET

from openpyxl import Workbook

from remarketing.models import ExcelError
from remarketing.workbook import OOXMLWorkbook

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def _rewrite_member(path: Path, member: str, transform) -> None:
    with zipfile.ZipFile(path, "r") as zin:
        items = {name: zin.read(name) for name in zin.namelist()}
    items[member] = transform(items[member])
    tmp = path.with_suffix(".tmp.xlsx")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in items.items():
            zout.writestr(name, data)
    tmp.replace(path)


def _set_cached_formula_value(path: Path, member: str, coordinate: str, value: str) -> None:
    def transform(data: bytes) -> bytes:
        root = ET.fromstring(data)
        cell = root.find(f".//m:c[@r='{coordinate}']", NS)
        assert cell is not None
        v = cell.find("m:v", NS)
        if v is None:
            v = ET.SubElement(cell, f"{{{NS['m']}}}v")
        v.text = value
        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    _rewrite_member(path, member, transform)


def _build_error_workbook(tmp_path: Path, code: str) -> Path:
    path = tmp_path / "error.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws["A1"] = code
    wb.save(path)

    def transform(data: bytes) -> bytes:
        root = ET.fromstring(data)
        cell = root.find(".//m:c[@r='A1']", NS)
        assert cell is not None
        cell.set("t", "e")
        for child in list(cell):
            cell.remove(child)
        v = ET.SubElement(cell, f"{{{NS['m']}}}v")
        v.text = code
        return ET.tostring(root, encoding="utf-8", xml_declaration=True)

    _rewrite_member(path, "xl/worksheets/sheet1.xml", transform)
    return path


def test_reader_returns_formula_text_and_cached_value(tmp_path: Path):
    path = tmp_path / "sample.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws["A1"] = "Contrat "
    ws["A2"] = "000123"
    ws["B1"] = "Calc"
    ws["B2"] = "=1+1"
    wb.save(path)

    _set_cached_formula_value(path, "xl/worksheets/sheet1.xml", "B2", "2")

    book = OOXMLWorkbook(path)
    cell = book.read_cell("Remarketing", "B2")
    assert cell.formula == "1+1"
    assert cell.value == 2


def test_reader_preserves_excel_error(tmp_path: Path):
    path = _build_error_workbook(tmp_path, code="#N/A")
    book = OOXMLWorkbook(path)
    assert book.read_cell("Remarketing", "A1").value == ExcelError("#N/A")


def test_reader_maps_sheet_names_and_iterates_rows(tmp_path: Path):
    path = tmp_path / "sheets.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws.append(["A", "B"])
    ws.append([1, 2])
    wb.create_sheet("KPIs")["C2"] = 42
    wb.save(path)

    book = OOXMLWorkbook(path)
    assert book.sheet_names() == ("Remarketing", "KPIs")
    assert book.sheet_path("KPIs").startswith("xl/worksheets/")
    rows = list(book.iter_sheet_rows("Remarketing"))
    assert [[c.value for c in row] for row in rows] == [["A", "B"], [1, 2]]


def test_style_number_format_reads_custom_and_builtin_formats(tmp_path: Path):
    path = tmp_path / "styles.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Remarketing"
    ws["A1"] = 0.25
    ws["A1"].number_format = "0.00%"
    ws["B1"] = 1234.5
    ws["B1"].number_format = '#,##0.00 "EUR"'
    wb.save(path)

    book = OOXMLWorkbook(path)
    a = book.read_cell("Remarketing", "A1")
    b = book.read_cell("Remarketing", "B1")
    assert book.style_number_format(a.style_id) == "0.00%"
    assert book.style_number_format(b.style_id) == '#,##0.00 "EUR"'
