from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

import pytest

from remarketing.errors import FidelityBuildError
from remarketing.fidelity import build_fidelity_workbook
from remarketing.ooxml_package import OOXMLPackage, sha256_bytes

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


def _write_fixture(path: Path) -> None:
    try:
        workbook = f'''<workbook xmlns="{MAIN_NS}" xmlns:r="{REL_NS}">
          <bookViews><workbookView activeTab="3" firstSheet="0"/></bookViews>
          <sheets>
            <sheet name="Report A" sheetId="1" r:id="rId1"/>
            <sheet name="Remarketing" sheetId="2" r:id="rId2"/>
            <sheet name="Discard Me" sheetId="3" r:id="rId3"/>
            <sheet name="Report B" sheetId="4" r:id="rId4"/>
          </sheets>
          <definedNames>
            <definedName name="GlobalKeep">Remarketing!$A$1:$A$10</definedName>
            <definedName name="GlobalDrop">'Discard Me'!$A$1</definedName>
            <definedName name="LocalKeep" localSheetId="0">$A$1</definedName>
            <definedName name="LocalDrop" localSheetId="2">$A$1</definedName>
            <definedName name="PlageTCD">Remarketing!$A:$Z</definedName>
            <definedName name="PlageTCD12">Remarketing!$A:$Z</definedName>
            <definedName name="TableTCD">Remarketing!$A:$Z</definedName>
          </definedNames>
        </workbook>'''.encode()
        rels = f'''<Relationships xmlns="{PKG_REL_NS}">
          <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
          <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
          <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
          <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/>
          <Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
          <Relationship Id="rId6" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
          <Relationship Id="rId7" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/calcChain" Target="calcChain.xml"/>
        </Relationships>'''.encode()
        content_types = b'''<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
          <Default Extension="xml" ContentType="application/xml"/>
          <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
          <Override PartName="/xl/calcChain.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml"/>
        </Types>'''
        with ZipFile(path, "w", ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", content_types)
            archive.writestr("xl/workbook.xml", workbook)
            archive.writestr("xl/_rels/workbook.xml.rels", rels)
            archive.writestr("xl/styles.xml", b"styles-original")
            archive.writestr("xl/theme/theme1.xml", b"theme-original")
            archive.writestr("xl/calcChain.xml", b"calc-chain")
            for index in range(1, 5):
                archive.writestr(
                    f"xl/worksheets/sheet{index}.xml",
                    f"<worksheet id='{index}'/>".encode(),
                )
    except Exception:
        raise


def _sheet_states(path: Path) -> list[tuple[str, str]]:
    try:
        with ZipFile(path) as archive:
            root = ET.fromstring(archive.read("xl/workbook.xml"))
        sheets = root.find(f"{{{MAIN_NS}}}sheets")
        assert sheets is not None
        return [(node.attrib["name"], node.attrib.get("state", "visible")) for node in sheets]
    except Exception:
        raise


def test_builder_retains_requested_sheets_and_preserves_style_bytes(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        result = build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        assert result.path == output
        assert result.retained_sheets == ("Report A", "Remarketing", "Report B")
        assert result.removed_sheet_count == 1
        assert _sheet_states(output) == [
            ("Report A", "visible"),
            ("Remarketing", "veryHidden"),
            ("Report B", "visible"),
        ]
        with OOXMLPackage(source) as original, OOXMLPackage(output) as generated:
            assert sha256_bytes(original.read_part("xl/styles.xml")) == sha256_bytes(
                generated.read_part("xl/styles.xml")
            )
            assert sha256_bytes(original.read_part("xl/theme/theme1.xml")) == sha256_bytes(
                generated.read_part("xl/theme/theme1.xml")
            )
            assert original.read_part("xl/worksheets/sheet1.xml") == generated.read_part(
                "xl/worksheets/sheet1.xml"
            )
            assert not generated.part_exists("xl/calcChain.xml")
    except Exception:
        raise


def test_builder_prunes_and_reindexes_defined_names(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        with ZipFile(output) as archive:
            root = ET.fromstring(archive.read("xl/workbook.xml"))
        parent = root.find(f"{{{MAIN_NS}}}definedNames")
        assert parent is not None
        names = {node.attrib["name"]: node for node in parent}
        assert set(names) == {"GlobalKeep", "LocalKeep", "PlageTCD", "PlageTCD12", "TableTCD"}
        assert names["LocalKeep"].attrib["localSheetId"] == "0"
    except Exception:
        raise


def test_builder_removes_discarded_sheet_and_calc_chain_relationships(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        output = tmp_path / "output.xlsx"
        _write_fixture(source)
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A", "Report B"),
            technical_sheets=("Remarketing",),
        )
        with ZipFile(output) as archive:
            rel_root = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
            rel_ids = {node.attrib["Id"] for node in rel_root}
            content_types = archive.read("[Content_Types].xml")
        assert "rId3" not in rel_ids
        assert "rId7" not in rel_ids
        assert b"calcChain" not in content_types
    except Exception:
        raise


def test_builder_rejects_missing_requested_sheet(tmp_path):
    try:
        source = tmp_path / "source.xlsx"
        _write_fixture(source)
        with pytest.raises(FidelityBuildError):
            build_fidelity_workbook(
                source,
                tmp_path / "output.xlsx",
                visible_sheets=("Missing",),
                technical_sheets=("Remarketing",),
            )
    except Exception:
        raise


def test_builder_preserves_markup_compatibility_namespace_prefixes(tmp_path):
    try:
        source = tmp_path / "source_mc.xlsx"
        output = tmp_path / "output_mc.xlsx"
        workbook = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="{MAIN_NS}" xmlns:r="{REL_NS}"
 xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
 mc:Ignorable="x15 xr"
 xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main"
 xmlns:xr="http://schemas.microsoft.com/office/spreadsheetml/2014/revision">
 <mc:AlternateContent>
   <mc:Choice Requires="x15"><x15:workbookPr/></mc:Choice>
 </mc:AlternateContent>
 <bookViews><workbookView activeTab="0"/></bookViews>
 <sheets>
   <sheet name="Report A" sheetId="1" r:id="rId1"/>
   <sheet name="Remarketing" sheetId="2" r:id="rId2"/>
 </sheets>
</workbook>'''.encode()
        rels = f'''<Relationships xmlns="{PKG_REL_NS}">
          <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
          <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
        </Relationships>'''.encode()
        with ZipFile(source, "w", ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", b'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
            archive.writestr("xl/workbook.xml", workbook)
            archive.writestr("xl/_rels/workbook.xml.rels", rels)
            archive.writestr("xl/worksheets/sheet1.xml", b"<worksheet/>")
            archive.writestr("xl/worksheets/sheet2.xml", b"<worksheet/>")
        build_fidelity_workbook(
            source,
            output,
            visible_sheets=("Report A",),
            technical_sheets=("Remarketing",),
        )
        with ZipFile(output) as archive:
            generated = archive.read("xl/workbook.xml")
        assert b'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"' in generated
        assert b'xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main"' in generated
        assert b'xmlns:xr="http://schemas.microsoft.com/office/spreadsheetml/2014/revision"' in generated
        assert b'mc:Ignorable="x15 xr"' in generated
        assert b'Requires="x15"' in generated
    except Exception:
        raise
