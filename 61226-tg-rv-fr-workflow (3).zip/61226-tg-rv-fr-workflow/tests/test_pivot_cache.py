from __future__ import annotations

import os
from pathlib import Path

import pytest

from remarketing.calculate import run_pivot
from remarketing.calculate import load_pivot_definitions


REFERENCE = Path(os.environ.get("REFERENCE_WORKBOOK", "/mnt/data/REMARKETING_ET_REPOSSESSION_copy24072026.xlsx"))


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_embedded_pivot_cache_is_the_analyst_pivot_snapshot():
    from remarketing.calculate import load_pivot_cache_dataset

    specs = {spec.pivot_id: spec for spec in load_pivot_definitions()}
    spec = specs["pivot_pierre_01"]
    dataset = load_pivot_cache_dataset(REFERENCE, spec.cache_definition)

    assert len(dataset.rows) == 1198
    assert "Contrat" in dataset.headers
    assert "Vendeur" in dataset.headers

    result = run_pivot(dataset, spec)
    assert len(result.matrix) == 30
    assert result.matrix[-1] == ["Total général", 241]


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_inactive_hidden_field_metadata_does_not_remove_saved_pivot_rows():
    from remarketing.calculate import load_pivot_cache_dataset

    spec = next(spec for spec in load_pivot_definitions() if spec.pivot_id == "pivot_pierre_03")
    dataset = load_pivot_cache_dataset(REFERENCE, spec.cache_definition)
    result = run_pivot(dataset, spec)

    assert result.matrix[-1] == ["Total général", 921]
    assert ["Dealer", 100] in result.matrix
    assert ["(blank)", 241] in result.matrix
