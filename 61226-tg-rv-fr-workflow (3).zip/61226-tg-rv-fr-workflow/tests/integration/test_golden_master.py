from __future__ import annotations

from datetime import date, datetime
import math
import os
from pathlib import Path

import pytest
from openpyxl.styles.numbers import is_date_format
from openpyxl.utils.cell import coordinate_to_tuple, range_boundaries
from openpyxl.utils.datetime import from_excel

from remarketing.models import ExcelError
from remarketing.workbook import OOXMLWorkbook
from remarketing.pipeline import build_pivot_results
from remarketing.calculate import load_pivot_definitions

REFERENCE = Path(os.environ.get("REFERENCE_WORKBOOK", "/mnt/data/REMARKETING_ET_REPOSSESSION_copy24072026.xlsx"))


def _canonical(value, *, number_format: str | None = None):
    if isinstance(value, ExcelError):
        return ("error", value.code)
    if value is None or value == "":
        return None
    if isinstance(value, (date, datetime)):
        return value.date().isoformat() if isinstance(value, datetime) else value.isoformat()
    if isinstance(value, (int, float)) and number_format and is_date_format(number_format):
        converted = from_excel(value)
        return converted.date().isoformat() if isinstance(converted, datetime) else converted.isoformat()
    if isinstance(value, str):
        text = value.rstrip()
        aliases = {
            "(vide)": "(blank)",
            "Grand Total": "Total général",
            "Row Labels": "Étiquettes de lignes",
            "Column Labels": "Étiquettes de colonnes",
        }
        return aliases.get(text, text)
    if isinstance(value, (int, float)):
        return float(value)
    return value


def _saved_block(book: OOXMLWorkbook, sheet: str, ref: str):
    min_col, min_row, max_col, max_row = range_boundaries(ref)
    values = {(r, c): (None, None) for r in range(min_row, max_row + 1) for c in range(min_col, max_col + 1)}
    for row in book.iter_sheet_rows(sheet, min_row=min_row):
        for cell in row:
            rr, cc = coordinate_to_tuple(cell.coordinate)
            if min_row <= rr <= max_row and min_col <= cc <= max_col:
                values[(rr, cc)] = (cell.value, book.style_number_format(cell.style_id))
    return [
        [values[(r, c)] for c in range(min_col, max_col + 1)]
        for r in range(min_row, max_row + 1)
    ]


def _assert_matches(spec, result, saved):
    assert len(result.matrix) == len(saved), f"{spec.pivot_id}: row count"
    generated_width = max((len(row) for row in result.matrix), default=0)
    assert generated_width == len(saved[0]), f"{spec.pivot_id}: column count"
    for r_idx, generated_row in enumerate(result.matrix):
        for c_idx in range(generated_width):
            generated = generated_row[c_idx] if c_idx < len(generated_row) else None
            saved_value, saved_fmt = saved[r_idx][c_idx]
            left = _canonical(generated)
            right = _canonical(saved_value, number_format=saved_fmt)
            if isinstance(left, str) and isinstance(right, float):
                try:
                    left = float(left)
                except ValueError:
                    pass
            if isinstance(right, str) and isinstance(left, float):
                try:
                    right = float(right)
                except ValueError:
                    pass
            if isinstance(left, float) and isinstance(right, float):
                assert math.isclose(left, right, rel_tol=1e-8, abs_tol=1e-8), (
                    spec.pivot_id, r_idx, c_idx, left, right
                )
            else:
                assert left == right, (spec.pivot_id, r_idx, c_idx, left, right)


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
@pytest.mark.parametrize("pivot_id", [spec.pivot_id for spec in load_pivot_definitions()])
def test_all_28_reference_pivots_reconcile(pivot_id):
    spec = next(spec for spec in load_pivot_definitions() if spec.pivot_id == pivot_id)
    result = build_pivot_results(REFERENCE, [spec])[pivot_id]
    with OOXMLWorkbook(REFERENCE) as book:
        saved = _saved_block(book, spec.sheet, spec.reference_range)
    _assert_matches(spec, result, saved)


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_kpi_generated_and_preserved_cells_reconcile_to_analyst_snapshot():
    from remarketing.normalize import extract_remarketing
    from remarketing.validate import inspect_workbook
    from remarketing.calculate import build_kpi_result

    with OOXMLWorkbook(REFERENCE) as book:
        inspection = inspect_workbook(book)
        dataset = extract_remarketing(book, inspection)
        result = build_kpi_result(dataset, inspection.report_as_of_date, book)
        for coordinate, generated in result.values.items():
            source = book.read_cell("KPIs", coordinate)
            left = _canonical(generated)
            right = _canonical(source.value, number_format=book.style_number_format(source.style_id))
            if isinstance(left, float) and isinstance(right, float):
                assert math.isclose(left, right, rel_tol=1e-8, abs_tol=1e-8), (coordinate, left, right)
            else:
                assert left == right, (coordinate, left, right)


def _reference_from_env() -> Path:
    value = os.environ.get("REFERENCE_WORKBOOK")
    if not value:
        pytest.skip("set REFERENCE_WORKBOOK to run golden-master tests")
    path = Path(value)
    assert path.exists()
    return path


def test_full_validate_has_zero_unexplained_mismatches_and_all_charts(tmp_path):
    import json
    from remarketing.config import load_config
    from remarketing.fidelity_validate import validate_visual_fidelity
    from remarketing.models import RunConfig
    from remarketing.pipeline import validate

    reference = _reference_from_env()
    result = validate(RunConfig.from_values(
        input_path=reference,
        output_dir=tmp_path,
        as_of_date=date(2026, 9, 16),
        use_system_date=False,
        full_fidelity=False,
    ))
    payload = json.loads(result.summary_path.read_text(encoding="utf-8"))
    assert payload["pivots_generated"] == 28
    assert payload["charts_generated"] == 7
    assert payload["mismatch_count"] == 0
    assert payload["business_reconciliation"] == "PASS"
    assert payload["visual_fidelity"] == "PASS"
    config = load_config()
    fidelity = validate_visual_fidelity(
        reference,
        result.report_path,
        visible_sheets=config.report_sheets,
        technical_sheets=config.technical_sheets,
    )
    assert fidelity.status == "PASS"


def test_explicit_date_reruns_are_semantically_deterministic(tmp_path):
    import json
    from remarketing.models import RunConfig
    from remarketing.pipeline import generate
    from remarketing.workbook import OOXMLWorkbook

    reference = _reference_from_env()
    config = RunConfig.from_values(
        input_path=reference,
        output_dir=tmp_path,
        as_of_date=date(2026, 9, 16),
        use_system_date=False,
        full_fidelity=False,
    )
    first = generate(config)
    second = generate(config)

    first_summary = json.loads(first.summary_path.read_text(encoding="utf-8"))
    second_summary = json.loads(second.summary_path.read_text(encoding="utf-8"))
    for payload in (first_summary, second_summary):
        payload.pop("output", None)
    assert first_summary == second_summary

    with OOXMLWorkbook(first.report_path) as left, OOXMLWorkbook(second.report_path) as right:
        for sheet in ("Pivot Pierre", "Pivot Soraya", "VENTES", "Feuil2", "Feuil3", "KPIs"):
            left_rows = [[(c.coordinate, c.value) for c in row] for row in left.iter_sheet_rows(sheet)]
            right_rows = [[(c.coordinate, c.value) for c in row] for row in right.iter_sheet_rows(sheet)]
            assert left_rows == right_rows
