from __future__ import annotations

from datetime import date
import json
import os
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import pytest

from remarketing.fidelity import DOC_REL_NS, MAIN_NS
from remarketing.fidelity_validate import validate_visual_fidelity
from remarketing.models import RunConfig
from remarketing.pipeline import validate

REFERENCE_VALUE = os.environ.get("REFERENCE_WORKBOOK", "")
REFERENCE = Path(REFERENCE_VALUE) if REFERENCE_VALUE else Path("/__missing_reference__.xlsx")
REL_ID_ATTR = f"{{{DOC_REL_NS}}}id"
VISIBLE = ("Pivot Pierre", "Feuil2", "Pivot Soraya", "VENTES", "Feuil3", "KPIs")


def _sheet_states(path: Path) -> tuple[tuple[str, str], ...]:
    try:
        with ZipFile(path) as archive:
            root = ET.fromstring(archive.read("xl/workbook.xml"))
        parent = root.find(f"{{{MAIN_NS}}}sheets")
        assert parent is not None
        return tuple(
            (node.attrib["name"], node.attrib.get("state", "visible")) for node in parent
        )
    except Exception:
        raise


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_real_client_workbook_is_business_and_visual_fidelity_pass(tmp_path):
    try:
        result = validate(
            RunConfig.from_values(
                input_path=REFERENCE,
                output_dir=tmp_path,
                as_of_date=date(2026, 9, 16),
                use_system_date=False,
                full_fidelity=True,
            )
        )
        summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
        assert summary["mismatch_count"] == 0
        assert summary["pivots_generated"] == 28
        assert summary["charts_generated"] == 7
        assert summary["business_reconciliation"] == "PASS"
        assert summary["visual_fidelity"] == "PASS"
        states = _sheet_states(result.report_path)
        assert tuple(name for name, state in states if state == "visible") == VISIBLE
        assert dict(states)["Remarketing"] == "veryHidden"
        assert len(states) == 7
        fidelity = validate_visual_fidelity(
            REFERENCE,
            result.report_path,
            visible_sheets=VISIBLE,
            technical_sheets=("Remarketing",),
        )
        assert fidelity.status == "PASS"
        assert all(check.status == "PASS" for check in fidelity.checks)
    except Exception:
        raise
