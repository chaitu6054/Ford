"""Diagnostic France : rejoue l'etape France seule et affiche la traceback complete.

Usage :
    python local/diag_france.py 2026-07-31 "C:\\chemin\\vers\\portefeuille.xlsx"
"""
import sys
import traceback
from datetime import date
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "astro" / "include"))

from remarketing.france_reports import generate_france_reports


def main() -> None:
    jour = date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else date.today()
    pf = Path(sys.argv[2]) if len(sys.argv) > 2 else None
    cands = sorted(
        (REPO / "local" / "input").glob("*.xls*"),
        key=lambda p: p.stat().st_mtime,
    )
    if not cands:
        print("Aucun classeur trouve dans local/input")
        return
    src = cands[-1]
    out = REPO / "local" / "output" / "diag" / "output"
    out.mkdir(parents=True, exist_ok=True)
    print("source:", src.name)
    print("portefeuille:", pf)
    try:
        res = generate_france_reports(
            input_path=src,
            output_dir=out,
            processing_date=jour,
            portefeuille_path=pf,
            taux=None,
        )
    except Exception:
        traceback.print_exc()
        return
    print("OK")
    print("ERA:", res.era_path)
    print("Portefeuille:", res.portefeuille_path)


if __name__ == "__main__":
    main()
